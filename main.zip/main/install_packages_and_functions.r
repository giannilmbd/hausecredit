# I wrote this function to speed up the process.
# NB: at the snb after installing a package (or several) you have to run the command "snbnetutils::consolidate()"
# NBNB: in R you have packages which you can either load or refer to with the :: like above)
# NBNBNB: also note the construction of functions plus assigment symbol <- that can be replaced by = (latter less confusing and universal)

instpkg<-function(pkg=NULL){
  for(cnt in pkg){
    if(!require(cnt,character.only = TRUE)){install.packages(cnt)
      snbnetutils::consolidate()
    }
    library(cnt,character.only = TRUE)
  }  
}

# following is because of the German way of typing dates etc.
Sys.setlocale("LC_TIME", "English.UTF-8") # Windows
Sys.getlocale()


inst_pk<-function(pk=NULL){if(!require(pk,character.only = TRUE)){
  install.packages(pk);
  library(pk,character.only = T)
}}

inst_pk('ggplot2')
inst_pk('dplyr')
inst_pk('rmarkdown')
inst_pk('ggfortify')
inst_pk('gridExtra')
inst_pk('tidyr')
inst_pk('zoo')
inst_pk('magrittr')
inst_pk('knitr')
inst_pk('kableExtra')
inst_pk('cowplot')
inst_pk('lubridate')
inst_pk('abind')
inst_pk('psych')
inst_pk('devtools')
inst_pk('forecast')
inst_pk("reshape2")
inst_pk("collapse")
inst_pk("future.apply")
inst_pk('pbapply')
inst_pk('latex2exp')


# devtools::install_github("bsvars/bsvarSIGNs")



if(!require("bsvars")){install.packages("bsvars")}
#if(!require('bsvars')){install.packages("~/Dropbox/SNB/BVAR/bsvars_3.2.0.9000.tar.gz", repos = NULL, type = "source")}
library(bsvars)
# remove.packages("bsvarSIGNs")
# devtools::clean_dll("~/Dropbox/SNB/bsvarSIGNs/")
# devtools::load_all("~/Dropbox/SNB/bsvarSIGNs/")
#if(!require("bsvarSIGNs"))install.packages('/home/gianni/Dropbox/SNB/bsvarSIGNs_2.0.0.9000.tar.gz', repos = NULL, type = "source")
remotes::install_github("giannilmbd/bsvarSIGNs",force=F,upgrade = "always",type='source')

library(bsvarSIGNs)
# if(!require("bsvarSIGNs")){install.packages("bsvarSIGNs")}
#  #if(!require('bsvarSIGNs')){install.packages("~/Dropbox/SNB/BVAR/bsvarSIGNs_2.0.0.9000.tar.gz", repos = NULL, type = "source")}



#  install.packages("~/Dropbox/SNB/BVAR/APRScenario_0.0.2.0.tar.gz", repos = NULL, type = "source")
#   unlink("~/Dropbox/SNB/APRScenario/src/RcppExports.cpp")
# unlink("~/Dropbox/SNB/APRScenario/R/RcppExports.R")
#  devtools::clean_dll("~/Dropbox/SNB/APRScenario")
remotes::install_github("giannilmbd/APRScenario",force=F,upgrade = "always",type='source')

# Rcpp::compileAttributes("~/Dropbox/SNB/APRScenario")
# devtools::load_all("~/Dropbox/SNB/APRScenario",recompile = TRUE)
library(APRScenario)
# source('../../../APRScenario/R/plot_bvars.r')
# source('../../../APRScenario/R/gen_mats.r')
# source("~/Dropbox/SNB/APRScenario/R/big_b_and_M.r")
# source("../../../APRScenario/R/mat_forc.r")
# source('../../../APRScenario/R/forc_h.r')
# source('../../../APRScenario/R/scenarios.r')
# source('../../../APRScenario/R/simscen.r')
# In here are all the function to produce stuff in this file
source("all_functions.r")


system('mkdir -p figures')


theme_set(theme_minimal(base_size = 18))
