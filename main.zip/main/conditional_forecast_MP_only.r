## ----Conditional Forecast MP only, include=FALSE-------------------------------------------------------------
#NB: Y contans the data n_var x T

h=4 # horizon
n_sim=200 # number of shock draws
obs=which(subvar%in%c("pi_3m")) # position of observable
pos_cond_vars=obs 
# given the path of the observables
TT=nrow(df)
T.start='2025-01-01'
T.end=as.Date(T.start)%m+%months(9)
path=df[df$year>=T.start,"pi_f_3m"][1:h]

# uncond.forc[uncond.forc$hor>0&uncond.forc$variable==subvar[pos_cond_vars],'Median']$Median#df[(TT-h+1):TT,obs]
bvarSign_path=df[(TT-h+1):TT,]
bvarSign_path[,names(bvarSign_path)!=subvar[obs]]<-NA
bvarSign_path[,names(bvarSign_path)==subvar[obs]]<-path
bvarSign_path<-bvarSign_path[,subvar]

# give the shocks that are not driving the scenario: NA if all driving
shocks=which(!c(subset_)%in%which(subvar%in%c("STR3m")))#c(1,2,3)
tmp<-scenarios(h = h,path = path,obs = obs,
               free_shocks = shocks,n_sample = n_draws,
               data_ = Z,g=NULL,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)
mu_eps<-tmp[[1]]
Sigma_eps<-tmp[[2]]
mu_y<-tmp[[3]]
Sigma_y<-tmp[[4]]
big_b<-tmp[[5]]
big_M<-tmp[[6]]

y_h_cond_MP_only<-simulate_conditional_forecasts(mu_y=mu_y_STR,
                                                 Sigma_y=Sigma_y_STR, 
                                                 varnames = subvar, n_sim = n_sim)

y_data<-t(Y) %>% as.data.frame()
y_data$hor<-dates_date
p<-plot_cond_forc(varbl2plot='LRHP',y_h_cond=y_h_cond_MP_only,
                  center=0.5,lower=0.16,upper=0.84,
                  T.start=T.start,T.end=T.end,y_data=y_data)
p[[1]]<-p[[1]]+theme_uniform_text_size(size=18)+ylab('')+xlab('')+theme(axis.text.x=element_text(angle=45))+
  coord_cartesian(xlim=as.Date(c('2023-01-01',T.end)),ylim=c(0.94,1.1))


print(p[[1]])
ggsave('cond_forc_MP.pdf',plot=p[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')

# set threshold as x% increase since last obs
threshold=last(dt_t[,subvar[varbl2plot]])*(1.01)

p<-plot_cond_histo(variable=subvar[varbl2plot],horizon=1,
                   threshold = threshold,data =y_h_cond_MP_only,above=F,size=5)+
  xlim(c(0.5,1.5))+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')

print(p)

ggsave('cond_histo_MP.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')


q0<-KL(Sigma_eps,mu_eps,h,plot_=T)
q_MP<-q0[[1]]  
p_MP<-q0[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
med_q_MP=mean(q_MP)
print(p_MP)
ggsave('KL_MP.pdf',plot=p_MP,device='pdf',path='figures',width=18,height=16,units = 'cm')
# hist(q,main='KL measure (ref value 0.5)')
