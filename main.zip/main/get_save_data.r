# Get and save data
setwd('C:/LocalPersonalData/HousePrices/BVAR/main')
library(knitr)
library(kableExtra)
library(cowplot)
library(lubridate)
library(zoo)
instpkg<-function(pkg=NULL){
  for(cnt in pkg){
    if(!require(cnt,character.only = TRUE)){install.packages(cnt)
      snbnetutils::consolidate()
    }
    library(cnt,character.only = TRUE)
  }  
}

# following is because of the German way of typing dates etc.
Sys.setlocale("LC_TIME", "English.UTF-8") # Windows
Sys.getlocale()

# This list of packages can be extended as needed
pkgs=list('MARSS','brms','shinystan','broom.mixed','gtsummary','arm','foreach','doParallel',"coda",
          'magrittr','dfms','GGally','svars',
          'readstata13','ggstatsplot','openxlsx','dplyr','ggplot2',
          'stargazer','tidyr','BVAR','BVARverse','bsvars',
          'plotly','gridExtra','e1071','latex2exp',
          'ggrepel','tidybayes','remotes',"urca","vars","tsDyn")#,'RJSDMX','rstan','rstanarm', 'rstantools','brms','bayesforecast','bsts',

# This is how you call a function (with or without output). Here load/install packages
instpkg(pkgs)

get_data<-function(key=NULL,name=NULL,begin=NULL,type_='m'){
  df.q_out<-data.frame(year=seq.Date(from=as.Date(paste0(as.character(begin),'-01-01')),to=as.Date(now()),by='quarter'))
  df<- try(snbeasy::load_long(datalocators = key,begin=begin)[[1]],silent = T)
  if(class(df)!='try-error'){head(df)}
  df$year<-as.yearqtr(df$Index)
  df.q<-switch(type_,
               m=df %>% group_by(year) %>% reframe(year=unique(year),tmp = mean(Value,na.rm=!all(is.na(Value)))) %>% as.data.frame(),#mean
               s=df %>% group_by(year) %>% reframe(year=unique(year),tmp = sum(Value,na.rm=!all(is.na(Value)))) %>% as.data.frame(),#sum
               l=df %>% group_by(year) %>% reframe(year=unique(year),tmp = last(Value,na_rm=!all(is.na(Value)))) %>% as.data.frame(),#last
  )
  names(df.q)[names(df.q)=='tmp']<-name
  # df.q$year<-as.Date(as.yearqtr(paste(df.q$anno,df.q$month,sep='-M'),'%Y-M%m')) %>% as.yearmon()
  
  head(df.q)
  df.q$year<-as.Date(df.q$year)
  df.q_out<-left_join(df.q,df.q_out,by='year')
  # df.q<-df.q[,-c(1:2)]
  return(df.q_out)
}
get_data_m<-function(key=NULL,name=NULL,begin=NULL,type_='m'){
  df.q_out<-data.frame(year=seq.Date(from=as.Date(paste0(as.character(begin),'-01-01')),to=as.Date(now()),by='month'))
  df<- try(snbeasy::load_long(datalocators = key,begin=begin)[[1]],silent = T)
  if(class(df)!='try-error'){head(df)}
  df$year<-as.yearmon(df$Index)
  df.q<-switch(type_,
               m=df %>% group_by(year) %>% reframe(year=unique(year),tmp = mean(Value,na.rm=!all(is.na(Value)))) %>% as.data.frame(),#mean
               s=df %>% group_by(year) %>% reframe(year=unique(year),tmp = sum(Value,na.rm=!all(is.na(Value)))) %>% as.data.frame(),#sum
               l=df %>% group_by(year) %>% reframe(year=unique(year),tmp = last(Value,na_rm=!all(is.na(Value)))) %>% as.data.frame(),#last
  )
  names(df.q)[names(df.q)=='tmp']<-name
  # df.q$year<-as.Date(as.yearqtr(paste(df.q$anno,df.q$month,sep='-M'),'%Y-M%m')) %>% as.yearmon()
  
  head(df.q)
  df.q$year<-as.Date(df.q$year)
  df.q_out<-left_join(df.q_out,df.q,by='year')
  # df.q<-df.q[,-c(1:2)]
  return(df.q_out)
}

## ----Data,eval=FALSE-----------------------------------------------------------------------------------------------------------------
##  sources<-c(
##    P_TRANS_EWG= 'VWK2@SNB.A.D.VWKHOUSING{A03A,A,A,B,Z,Q}',#                      'P_TRANS_EWG';
##     P_TRANS_EFH='VWK2@SNB.A.D.VWKHOUSING{A03B,A,A,B,Z,Q}',#                      'P_TRANS_EFH';
##     P_OFFER_EWG='SNB1@SNB.FA5.WP.EWG{R0,Q}',              #                      'P_OFFER_EWG';
##     P_OFFER_EFH='SNB1@SNB.FA5.WP.EFH{R0,Q}',              #                      'P_OFFER_EFH';
##     P_HOUSING='VWK2@SNB.A.D.VWKHOUSING{A03,A,A,B,Z,Q}', #                      'P_HOUSING';
##     P_POH='VWK2@SNB.A.D.VWKHOUSING{A03AB,A,A,B,Z,Q}[omega]',#              'P_POH';
##     CPI_NSA='VWF3@SNB.A.A13.VWFCPI{A,Z,A,B,Z,M}',#                           'CPI_NSA';
##    CPI= 'VWF3@SNB.A.A14.VWFCPI{A,Z,A,A,Z,Q}',#                           'CPI';
##    RENT_OFFER_RESPROP_Q= 'SNB1@SNB.FA5.WP.MWT{R0,Q}',          #                          'RENT_OFFER_RESPROP_Q';
##    RENT_CPI= 'SNB1@SNB.FA2.SNB.A{A,BA2,Z,A,I}',    #                          'RENT_CPI';
##    I_10Y_SNB= 'SNB1A@SNB.AA2.B1.AA{R10,M,ZH}',      #                          'I_10Y_SNB';
##    I_10Y_IMF= 'IFS@SNB.C146.S6.S1000ZF000{M}',      #                          'I_10Y_IMF';
##     MORTG_HH_new='MI@SNB.TC5.KC5.AV1.H{F,Z,C,I,B,A}',  #                          'MORTG_HH_new';
##     MORTG_HH_old='SNB3A@SNB.KC.Z.A{D}',                #                          'MORTG_HH_old'
##     GDP_NOM_SCA='SNB1@SNB.NA3.SNB.A{E,B,D,C,Q}[alpha]',#                         'GDP_NOM_SCA';
##     I_MORTGa='SNB1@SNB.CD1A.D.A4{BA,A,A,M,ZA}',    #                          'I_MORTGa'; %(lead 1),
##     I_MORTGb='SNB1@SNB.CD1A.D.A4{BA,C,A,M,ZA}',    #                          'I_MORTGb'; %(lead 1),
##    I_MORTGc= 'SNB1@SNB.CD1A.D.A4B{BB,D,E,VZ,D,W,ZZ}',#                        'I_MORTGc';
##    I_MORTGd= 'BSTA@SNB.ZISA_B.BIL.AKT.HYP{B,FVZ,J05,J05,AVG,A40}' #,           'I_MORTGd';
##     );
## vrbls<-names(sou)
## df<-data.frame(year=as.yearqtr(seq.Date(from=as.Date('1980-01-01'),to=Sys.time() %>% as.Date(),
##                                by='quarter')))
## for(cnt in 1:length(sources)){
##   df<-full_join(df,get_data(key=sources[cnt] %>% unname(),name=vrbls[cnt],begin=first(df$year)))
## 
## }
# ANGELA's --------
key = 'SNB1@SNB.CD1A.A.L{C03,B,M,DC}'; #LIBOR 
Libor3M<-get_data(key=key,begin = 1980,name = 'Libor3m',type_='m')  
summary(Libor3M)
head(Libor3M)
tail(Libor3M)

key = 'SNB1@SNB.CD1A.A.E{A, AON, A, Z, L, ZZ}'; #SARON
Saron3M<-get_data(key=key,begin = 1980,name = 'Saron3m',type_='m')  
summary(Saron3M)
head(Saron3M)
tail(Saron3M)

# OIS 1 Y --- as Barbara's
## linking rule link(${t0},"2021-09-15",${t0SARON})
key='SNB1@SNB.CD1A.AA.A{C01,A,L,ZZ}[omega]'
t0<-get_data(key=key,begin = 1980,name = 'ois1yB',type_='m')  
summary(t0)
head(t0)
tail(t0)
#### SARON
key='SNB1@SNB.CD1A.AA.B{C01,A,L,ZZ}[omega]'
t0SARON<-get_data(key=key,begin = 1980,name = 'saron1yB')  
head(t0SARON)
tail(t0SARON)

ois_Barbara<-full_join(t0SARON,t0,by='year')

ggplot(ois_Barbara)+
  geom_point(aes(year,ois1yB),color='red',shape=1,size=2)+
  geom_point(aes(year,saron1yB),color='blue',shape=4,size=2)

# One year (shorter sample)
key = 'SNB1@SNB.CD1A.AA.B{C01, H, L, ZZ}[omega]'
I1y<-get_data(key=key,begin = 1980,name = 'ois1y')  
head(I1y)
tail(I1y)

key = 'SNB1@SNB.CD1A.AA.B{C02, H, L, ZZ}[omega]'
I2y<-get_data(key=key,begin = 1980,name = 'ois2y')  
head(I2y)
tail(I2y)

# three years
    key='SNB1@SNB.CD1A.AA.A{C03,A,L,ZZ}[omega]'
    I3y<-get_data(key=key,begin = 1980,name = 'ois3y')  
    head(I3y)
    tail(I3y)
    
    key='SNB1@SNB.CD1A.AA.B{C03,G,L,ZZ}[omega]'
    I3yS<-get_data(key=key,begin = 1980,name = 'ois3yS')  
    head(I3yS)
    tail(I3yS)
    
# EURO OIS 1Y
key='SNB1@SNB.CD1X.AA.B{C01,A,L,ZZ}'
IEA_1y<-get_data(key=key,begin = 1980,name = 'ois1yECB')  
head(IEA_1y)
tail(IEA_1y)

# US OIS 1Y
key='SNB1@SNB.CD1B.AA.A{C01,A,L,ZZ}'
t0<-get_data(key=key,begin = 1980,name = 'ois1yFed1')  
head(t0)
tail(t0)
# US SOFR
key='SNB1@SNB.CD1B.AA.B{C01,G,L,ZZ}'
t0SOFR<-get_data(key=key,begin = 1980,name = 'ois1yFed2')  
head(t0SOFR)
tail(t0SOFR)
tall<-left_join(t0,t0SOFR,by='year')

# US LINKING link(${t0},"2021-09-15",${t0SOFR})
FED_1y<-tall
FED_1y$ois1yFed<-c(tall[tall$year<=as.Date(as.yearqtr('2021 Q3')),]$ois1yFed1,tall[tall$year>as.Date(as.yearqtr('2021 Q3')),]$ois1yFed2)

oises<-full_join(I1y,I3y,by='year')
oises<-left_join(oises,IEA_1y,by='year')
oises<-left_join(oises,FED_1y,by='year')
oises<-left_join(oises,I3yS,by='year')
oises<-left_join(oises,I2y,by='year')    
oises<-left_join(oises,ois_Barbara,by='year')
oises<-left_join(oises,Libor3M,by='year')
oises<-left_join(oises,Saron3M,by='year')
oises<-oises[order(oises$year),]
    
head(oises)
    oises$STR<-c(oises[oises$year<as.Date(as.yearqtr('1997 Q4')),]$ois3y,
                 oises[oises$year>=as.Date(as.yearqtr('1997 Q4'))&oises$year<as.Date(as.yearqtr('2009 Q3')),]$ois1yB,
                 oises[oises$year>=as.Date(as.yearqtr('2009 Q3')),]$saron1yB)
    
    oises$STR3m<-c(oises[oises$year<as.Date(as.yearqtr('1989 Q1')),]$ois3y,
                 oises[oises$year>=as.Date(as.yearqtr('1989 Q1'))&
                         oises$year<as.Date(as.yearqtr('1999 Q3')),]$Libor3m,
                 oises[oises$year>=as.Date(as.yearqtr('1999 Q3')),]$Saron3m)
    head(oises)    

p<-ggplot(oises)+
  geom_point(aes(year,y=Libor3m,color='3mLibor'),shape=24,size=3)+
  geom_line(aes(year,y=STR3m,color='STR3m'))+
  geom_point(aes(year,y=Saron3m,color='3nSaron'),shape=21,size=3)+theme_minimal()
  
ggplotly(p)
  
    
  p<-ggplot(oises)+geom_point(aes(year,y=ois3y,color='ois3y'),shape=4,size=3)+
      geom_point(aes(year,y=ois3yS,color='ois3yS'),shape=22,size=3)+
      geom_point(aes(year,y=Libor3m,color='3mLibor'),shape=24,size=3)+
      geom_point(aes(year,y=Saron3m,color='3nSaron'),shape=21,size=3)+
      geom_point(aes(year,y=ois1y,color='ois1y'),shape=7,size=3)+
      geom_point(aes(year,y=ois2y,color='ois2y'),shape=20,size=3)+
      geom_point(aes(year,y=ois1yB,color='ois1yB'),shape=6,size=3)+
      geom_point(aes(year,y=saron1yB,color='saron1yB'),shape=8,size=3)+
      scale_color_manual('',values=c("ois3y"='red',
                                     "ois3yS"='blue',
                                     "3mLibor"='brown',
                                     "3mSaron"='pink',
                                     "ois1y" ='green',
                                     "ois2y"='cyan',
                                     "ois1yB"='magenta',
                                     "saron1yB"='black'))+
      geom_line(data=oises,aes(year,y=STR),color='orange')
    
    ggplotly(p)
  
    # world gdp export weighted
    key='VWK1@SNB.A.ZZZ.VWKMACRIND{B5, H2, A, A, C, Q}[omega]'
    GDP_ROW<-get_data(key=key,begin = 1980,name = 'gdp_row',type_='s')  
    head(GDP_ROW)
    
    #FX NEER
    key='SNB20@SNB.TotIndx.NOM{TRNQ,TOT,IMF,P1M}[omega]'
    NEER<-get_data(key=key,begin = 1980,name = 'NEER')  
    head(NEER)
    
    # REER
    key='BIS@SNB.MACRO{M,QTJA,CH,02}[omega]'
    REER<-get_data(key=key,begin = 1980,name = 'REER')  
    head(REER)
    tail(REER)
    
    # USDCH
    key='SNB1@SNB.DA1.WK.US{CHF,DA,Z,A,A1,L,ZZ}'
    USDCH<-get_data(key=key,begin = 1980,name = 'usdch')  
    head(USDCH)
    # VIX
    key='SNB1@SNB.CA6.AA.VIX{A,Z,A,L}[omega]'
    VIX<-get_data(key=key,begin = 1980,name = 'vix')  
    head(VIX)
    tail(VIX)
    # swiss cape (price-dividend ratio)
    key='MI@SNB.TC6.STOCKS.CAPE{CH,P1D_L}[omega]'
    cape<-get_data(key=key,begin = 1980,name = 'cape')  
    head(cape)
    tail(cape)
    
    # saving deposits
    key='BSTA@SNB.ZISA_B.BIL.PAS.VKE.KOV{B,PHA,NUE,T,Q50,A40}[omega]'
    saveR<-get_data(key=key,begin = 1980,name = 'saveR')  
    head(saveR)
    tail(saveR)
    #
    key='CONS_ECON@SNB.CH{CPI,Y0505A,CON,Z,T3,P3M}[omega]'
    consens<-get_data(key=key,begin = 1980,name = 'consens')  
    head(consens)
    tail(consens)
    
    
    
    # us gdp real
    key='	INTDATA1@SNB.USA{NatAcc,USGDP_DT__DT__DT_D,P3M}[omega]'
    US_gdp<-get_data(key=key,begin = 1980,name = 'US_gdp',type_='s')  
    head(US_gdp)
    tail(US_gdp)
    # us 10 year yield
    key='INTDATA1@SNB.USA{IntRat,FRTCM10,P1D_L}[omega]'
    US_10y<-get_data(key=key,begin = 1980,name = 'US_10y') 
    head(US_10y)
    tail(US_10y)
    
    # CPI FORECAST (PAS)
    # key='VWF1@SNB.ZZZZQZ.MEAN.CPI{A2,UCLB,FX0,LEVEL,Q}[omega]' # interest rate lower bound
    key='VWF1@SNB.ZZZZQZ.MEAN.CPI{A2, UC, FX0, LEVEL, Q}[omega]' # interest rate free
    CPI_f<-get_data(key=key,begin = 1980,name = 'CPI_f',type_='m')
    
    head(CPI_f)
    tail(CPI_f)
    
    # CPI FORECAST (PAS) -- PREVIOUS QUARTER
    # key='VWF1@SNB.ZZZZQY.MEAN.CPI{A2, UCLB, FX0, LEVEL, Q} [omega]' # interest rate lower bound
    key='VWF1@SNB.ZZZZQY.MEAN.CPI{A2, UC, FX0, LEVEL, Q} [omega]' # interest rate free
    CPI_fpq<-get_data(key=key,begin = 1980,name = 'CPI_f',type_='m')
    
    head(CPI_fpq)
    tail(CPI_fpq)
    # POLICY Shocks
    
    key='MI@SNB.TC2.B.MPS_TEST{SNB,PC1,P1D_L}[omega]'
    MP_SNB<-get_data(key=key,begin = 1980,name = 'MP_snb',type_='s') 
    head(MP_SNB)
    tail(MP_SNB)
    
    
    key='MI@SNB.TC2.B.MPS_TEST{ECB,PC1,P1D_L}[omega]'
    MP_ECB<-get_data(key=key,begin = 1980,name = 'MP_ecb',type_='s') 
    head(MP_ECB)
    tail(MP_ECB)
    
    
    key='MI@SNB.TC2.B.MPS_TEST{FED,PC1,P1D_L}[omega]'
    MP_FED<-get_data(key=key,begin = 1980,name = 'MP_fed',type_='s') 
    head(MP_FED)
    tail(MP_FED)
    
    # create data set including horizon forecast
    
    dataHC<-data.frame(year=seq.Date(from=as.Date('1980-01-01') ,to=CPI_f$year %>% last,by='quarter'))
    dataHC<-left_join(dataHC,NEER,by='year')
    dataHC<-full_join(dataHC,oises[,c('year','STR','STR3m',"ois1yECB","ois1yFed")],by='year')
    dataHC<-full_join(dataHC,REER,by='year')
    dataHC<-full_join(dataHC,CPI_f,by='year')
    dataHC<-full_join(dataHC,CPI_fpq,by='year')
    dataHC<-left_join(dataHC,VIX,by='year')
    dataHC<-left_join(dataHC,cape,by='year')
    dataHC<-left_join(dataHC,saveR,by='year')
    dataHC<-left_join(dataHC,consens,by='year')
    dataHC<-left_join(dataHC,US_gdp,by='year')
    dataHC<-left_join(dataHC,US_10y,by='year')
    dataHC<-left_join(dataHC,USDCH,by='year')
    dataHC<-left_join(dataHC,MP_FED,by='year')
    dataHC<-left_join(dataHC,MP_ECB,by='year')
    dataHC<-left_join(dataHC,GDP_ROW,by='year')
    dataHC<-left_join(dataHC,MP_SNB,by='year')
    
    dataHC<-left_join(dataHC,I3y,by='year')
    dataHC<-left_join(dataHC,I3yS,by='year')
    # dataHC[,"ois3mrg"]<-dataHC[,"ois3y"]
    
    
    # dataHC[dataHC$year>=as.Date(as.yearqtr("2021 Q3")),"ois3mrg"]<-dataHC[dataHC$year>=as.Date(as.yearqtr("2021 Q3")),"ois3yS"]
    
    
    
    # ORIGINAL HC VECM DATA
    df<-read.table(file='../../data/TTQ_EViews.csv',sep=',',header = T,na.strings = 'NaN' )
    tail(df)
    df$year<-(as.Date(df$Time,'%d-%b-%Y'))
    df<-df[df$year>='1980-01-01'&df$year<'2024-04-01',-1]
    summary(df)
    
    # df$year<-zoo::as.yearqtr(df$year)
    
    
    dataHC<-full_join(df,dataHC,by='year')
    
    save(dataHC,file='dataHC.rds')
# monthly data
    key='SNB1@SNB.CD1A.AA.A{C01,A,L,ZZ}[omega]'
    t0<-get_data_m(key=key,begin = 1980,name = 'ois1yB',type_='m')  
    summary(t0)
    head(t0)
    tail(t0)
    #### SARON
    key='SNB1@SNB.CD1A.AA.B{C01,A,L,ZZ}[omega]'
    t0SARON<-get_data_m(key=key,begin = 1980,name = 'saron1yB')  
    head(t0SARON)
    tail(t0SARON)
    key='SNB1@SNB.CD1A.AA.A{C03,A,L,ZZ}[omega]'
    I3y<-get_data_m(key=key,begin = 1980,name = 'ois3y')  
    head(I3y)
    tail(I3y)
    oises.m<-full_join(t0,t0SARON,by='year')
    oises.m<-left_join(oises.m,I3y,by='year')
    
    oises.m$STR<-c(oises.m[oises.m$year<'2001-02-01',]$ois3y,
                 oises.m[oises.m$year>='2001-02-01'&oises.m$year<'2015-03-01',]$ois1yB,
                 oises.m[oises.m$year>='2015-03-01',]$saron1yB)
    
    p<-ggplot(oises.m)+geom_point(aes(year,y=ois3y,color='ois3y'),shape=4,size=3)+
      geom_point(aes(year,y=ois1yB,color='ois1yB'),shape=6,size=3)+
      geom_point(aes(year,y=saron1yB,color='saron1yB'),shape=8,size=3)+
      scale_color_manual('',values=c("ois3y"='red',
                                     "ois3yS"='blue',
                                     "ois1y" ='green',
                                     "ois2y"='cyan',
                                     "ois1yB"='magenta',
                                     "saron1yB"='black'))     +
     geom_line(data=oises.m,aes(year,y=STR),color='orange')
    
    ggplotly(p)
    
    
    p<-ggplot(oises.m)+geom_point(aes(year,y=ois3y-ois1yB,color='ois3y'),shape=4,size=3)+
      geom_point(aes(year,y=ois1yB-saron1yB,color='ois1yB'),shape=6,size=3)+
      scale_color_manual('',values=c("ois3y"='red',
                                     "ois3yS"='blue',
                                     "ois1y" ='green',
                                     "ois2y"='cyan',
                                     "ois1yB"='magenta',
                                     "saron1yB"='black'))
    # +
    #   geom_line(data=oises.m,aes(year,y=STR),color='orange')
    
    ggplotly(p)
    
    # USDCH
    key='SNB1@SNB.DA1.WK.US{CHF,DA,Z,A,A1,L,ZZ}'
    USDCH<-get_data_m(key=key,begin = 1980,name = 'usdch')  
    head(USDCH)
    # POLICY Shocks

    
    
    key='MI@SNB.TC2.B.MPS_TEST{SNB,PC1,P1D_L}[omega]'
    MP_SNB_m<-get_data_m(key=key,begin = 1980,name = 'MP_snb',type_='s') 
    summary(MP_SNB_m)
    head(MP_SNB_m)
    tail(MP_SNB_m)
    
    
    key='MI@SNB.TC2.B.MPS_TEST{ECB,PC1,P1D_L}[omega]'
    MP_ECB_m<-get_data_m(key=key,begin = 1980,name = 'MP_ecb',type_='s') 
    head(MP_ECB_m)
    tail(MP_ECB_m)
    
    
    key='MI@SNB.TC2.B.MPS_TEST{FED,PC1,P1D_L}[omega]'
    MP_FED_m<-get_data_m(key=key,begin = 1980,name = 'MP_fed',type_='s') 
    head(MP_FED_m)
    tail(MP_FED_m)
    
    dataMP_m<-full_join(MP_ECB_m,MP_FED_m,by='year')
    dataMP_m<-full_join(dataMP_m,MP_SNB_m,by='year')
    dataMP_m<-full_join(dataMP_m,oises.m,by='year')
    dataMP_m<-full_join(dataMP_m,USDCH,by='year')
    
    
    save(dataMP_m,file='dataMP_m.rds')
    
    