
B=posterior$posterior$B
A=posterior$posterior$A

BA<-mclapply(1:dim(B)[3],FUN =function(d){B[,,d]%*%A[,,d]}) %>% abind::abind(.,along=3)
dim(BA)

build_equation<-function(pos){
Bp<-B[pos,,,drop=F]
BAp<-BA[pos,,,drop=F]

Bp_l<-apply(Bp,MARGIN = c(1,2),FUN=function(x)quantile(x,.16))
Bp_c<-apply(Bp,MARGIN = c(1,2),FUN=function(x)quantile(x,.5))
Bp_u<-apply(Bp,MARGIN = c(1,2),FUN=function(x)quantile(x,.84))



cont<-rbind(Bp_l,Bp_c,Bp_u) %>% as.data.frame()
colnames(cont)<-paste0(varbls[subset_],"(t)")
sign_cont<-which(sign(cont[1,])==sign(cont[3,]))
cont[,2:ncol(cont)]<-cont[,2:ncol(cont)]*-1
rownames(cont)<-c("16","50","84")
tmp_cont<-knitr::kable(cont[,sign_cont],digit=2,row.names = T,format = 'latex')
print(tmp_cont)

BAp_l<-apply(BAp,MARGIN = c(1,2),FUN=function(x)quantile(x,.16))
BAp_c<-apply(BAp,MARGIN = c(1,2),FUN=function(x)quantile(x,.5))
BAp_u<-apply(BAp,MARGIN = c(1,2),FUN=function(x)quantile(x,.84))

lgd<-rbind(BAp_l,BAp_c,BAp_u) %>% as.data.frame
nms<-array(rep(NA,7),dim=c(h,7))
for(cnt in 1:h){
  nms[cnt,]<-paste(varbls[subset_],paste0("(t-",cnt,")"))
}
nms <- as.vector(t(nms))
colnames(lgd)<-c(nms,'const')
rownames(lgd)<-c("16","50","84")
sign_lgd<-which(sign(lgd[1,])==sign(lgd[3,]))

tmp_lgd<-knitr::kable(lgd[,sign_lgd],digit=2,row.names = T,format = 'latex')
print(tmp_lgd)
}
