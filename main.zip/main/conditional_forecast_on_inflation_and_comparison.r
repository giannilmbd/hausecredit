# Conditional forecast on inflation and comparison with unconditional forecast
zero_x<-'2024-01-01'
h=4 # horizon
n_sim=200 # number of shock draws
obs=which(subvar%in%c('pi_3m')) # position of observable
pos_cond_vars=obs 
# given the path of the observables
TT=nrow(df)
T.start='2025-01-01'
T.end=as.Date(T.start)%m+%months(9)
T.previous<-as.Date(T.start)%m-%months(3)
path=df[df$year>=T.start,"pi_f_3m"][1:h]
varbl2plot=which(subvar=='LRHP')
if(any(is.na(path))){
  
  stop("NA PATH")
}
#uncond.forc[uncond.forc$hor>0&uncond.forc$variable==subvar[pos_cond_vars],'Median']$Median#df[(TT-h+1):TT,obs]

y_data<-t(Y) %>% as.data.frame()
y_data$hor<-dates_date

bvarSign_path=df[df$year>=T.start&df$year<=T.end,]
bvarSign_path[,names(bvarSign_path)!=subvar[obs]]<-NA
bvarSign_path[,names(bvarSign_path)==subvar[obs]]<-path
bvarSign_path<-bvarSign_path[,subvar]

# give the shocks that are not driving the scenario: NA if all driving
shocks=NA#c(1,2,3)

# Z it the whole data stacked [Y;Z] with dates in columns
# system.time(
tmp<-scenarios(h = h,
               path = path,obs = obs,
               free_shocks = shocks,
               n_sample = n_draws,
               data_ = Z,g=NULL,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)
# )

# system.time(
# tmp_old<-scenarios_old(h,path,obs,shocks,n_draws,n_sample=n_draws,n_var,n_p,data_=Z)
# )
mu_eps<-tmp[[1]]
Sigma_eps<-tmp[[2]]
mu_y<-tmp[[3]]
Sigma_y<-tmp[[4]]
big_b<-tmp[[5]]
big_M<-tmp[[6]]

  # y_h_cf<-SimScen(mu_eps = mu_eps,Sigma_eps = Sigma_eps,mu_y = my_y,Sigma_y = Sigma_y,
                  # big_b = big_b,big_M = big_M,n_sim = n_sim,h =h,varbls = subvar,idx_sampled = 1:n_draws)

  y_h_cf<-simulate_conditional_forecasts(mu_y=mu_y, Sigma_y=Sigma_y, varnames = subvar, n_sim = n_sim)
  
# system.time(y_h_old<-SimScen_old(mu_eps = mu_eps,Sigma_eps = Sigma_eps,mu_y = my_y,Sigma_y = Sigma_y,
#                                  big_b = big_b,big_M = big_M,n_sim = n_sim,h =h,varbls = subvar,idx_sampled = 1:n_draws)
# )


p_cf<-plot_cond_forc(varbl2plot=subvar[varbl2plot],y_h_cond=y_h_cf,
                     center=0.5,lower=0.16,upper=0.84,
                     T.start=T.start,T.end=T.end,y_data=y_data)
p_cf[[1]]<-p_cf[[1]]+
  theme_uniform_text_size(size=18)+ylab('')+xlab('')+theme(axis.text.x=element_text(angle=45))+
  coord_cartesian(xlim=as.Date(c('2023-01-01',T.end)),ylim=c(0.94,1.1))
graphics.off()
print(p_cf[[1]])

p_cf.data<-ggplot_build(p_cf[[1]])$data
tmp1<-p_cf.data[[1]]
tmp1$x<-as.Date(tmp1$x)


tmp2<-p_cf.data[[2]]
tmp2$x<-as.Date(tmp2$x)
tmp2_last<-tmp2[tmp2$x==T.previous,'y']

tmp3<-p_cf.data[[3]]
tmp3$x<-as.Date(tmp3$x)

  tmp1$y<-(tmp1$y-tmp2_last)*100
  tmp2$y<-(tmp2$y-tmp2_last)*100
  tmp3$ymin<-(tmp3$ymin-tmp2_last)*100
  tmp3$ymax<-(tmp3$ymax-tmp2_last)*100

  pp<-ggplot()+
    geom_point(data=tmp1,aes(x=x,y=y,color='first'),
               alpha=1,size=3)+
    geom_ribbon(data=tmp3,aes(x=x,ymin=ymin,ymax=ymax),fill=light_green,alpha=.1)+
    
    geom_line(data=tmp2,aes(x=x,y=y,color='data'),linewidth=1.5)+
    geom_vline(xintercept=0)+
    scale_color_manual('',values=c('first'=dark_green,'second'='black','data'='blue'),
                       labels=c('first'='scenario','second'='baseline','data'='data'))+
    geom_vline(xintercept=-1,linetype='dashed')+xlab('')+ylab(subvar[varbl2plot])+
    coord_cartesian(xlim=as.Date(c(zero_x,T.end)))  +
    theme_uniform_text_size(size=15)+ylab('LRHP')+xlab('')+
    theme_minimal()+theme(legend.position = 'bottom')+
    theme(text=element_text(size=18,family = 'mono'))
  pp
  ggsave('cond_forc.pdf',plot=pp,device='pdf',path='figures',width=18,height=16,units = 'cm')
# threshold for probability distribution
threshold=0.0#last(y_data[,varbl2plot])*(.97)
LRHP_last<-y_data[y_data$hor==T.previous,"LRHP"]
y_h_cf_deviation<-(y_h_cf["LRHP.4",] - LRHP_last)*100
LRHP_cf<-y_h_cf_deviation





# Full density estimate
dens <- density(LRHP_cf)
dens_df <- data.frame(x = dens$x, y = dens$y)
dens_df$fill <- ifelse(dens_df$x <= threshold, "red", "lightgreen")

# Compute probability
prob_threshold <- mean(LRHP_cf < threshold)

# Base histogram
p <- ggplot(data.frame(value = LRHP_cf), aes(x = value)) +
  geom_histogram(aes(y = after_stat(density)), bins = 50, 
                 fill = "white", color = "black", alpha = 0.5) +
  
  # Filled areas under the curve, using same y-scale
  geom_area(data = subset(dens_df, x <= threshold),
            aes(x = x, y = y), fill = "red", alpha = 0.4) +
  geom_area(data = subset(dens_df, x > threshold),
            aes(x = x, y = y), fill = "lightgreen", alpha = 0.4) +
  
  # Outline full density
  geom_line(data = dens_df, aes(x = x, y = y), color = "darkgreen", size = 1) +
  
  # Vertical line and annotation
  # geom_vline(xintercept = threshold, linetype = 'dotted', 
  #            color = 'blue', linewidth = 1.5) +
   annotate(geom = 'text', 
           x = threshold + 0.01, y = -0.01, 
           label = paste0("P(X < 0%) = ", sprintf("%.2f", 100 * prob_threshold), "%"),
           color = 'red', hjust = 1, vjust = 1, size = 5) +
  
  # Labels and theme
  labs(title = "", x = latex2exp::TeX(paste0(' $',subvar[varbl2plot],'_{t+h} - ',subvar[varbl2plot],'_{t}$')), y = "frequency") +
  theme_uniform_text_size(size = 18)


print(p)

ggsave('cond_histo.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')





q0_cf<-KL(Sigma_eps,mu_eps,h,plot_=T)
q_cf<-q0_cf[[1]]
p_KL_cf<-q0_cf[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
graphics.off()
p_KL_cf
med_q_cf=mean(q_cf)
ggsave('KL_cf_inf_current.pdf',plot=p_KL_cf,device='pdf',path='figures',width=18,height=16,units = 'cm')

# hist(q,main='KL measure (ref value 0.5)')

## ---- Conditional forecast one period earlier----------


# Z it the whole data stacked [Y;Z] with dates in columns
T.start.m1<-as.Date(T.start)%m-%months(3)
T.end.m1<-as.Date(T.end)%m-%months(3)
T.previous<-as.Date(T.start.m1)%m-%months(3)
path=df[df$year>=T.start.m1,"pi_fpq_3m"][1:h]

tmp<-scenarios(h = h,path=path,obs = obs,
               free_shocks=shocks,
               n_sample=n_draws,
               data_ = Z[,-ncol(Z)],g=NULL,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)# minus one quarter
mu_eps<-tmp[[1]]
Sigma_eps<-tmp[[2]]
mu_y<-tmp[[3]]
Sigma_y<-tmp[[4]]
big_b<-tmp[[5]]
big_M<-tmp[[6]]

# y_h_cf_m1<-SimScen(mu_eps,Sigma_eps,mu_y,Sigma_y,big_b,big_M,n_sim,h,subvar)
y_h_cf_m1<-simulate_conditional_forecasts(mu_y=mu_y, Sigma_y=Sigma_y, varnames = subvar, n_sim = n_sim)




p_cf_m1<-plot_cond_forc(varbl2plot=subvar[varbl2plot],y_h_cond=y_h_cf_m1,
                        center=0.5,lower=0.16,upper=0.84,
                        T.start=T.start.m1	,T.end=T.end.m1,y_data=y_data)
p_cf_m1[[1]]<-p_cf_m1[[1]]+ theme_uniform_text_size(size=18)+ylab('')+xlab('')+
  coord_cartesian(xlim=as.Date(c('2023-01-01',T.end.m1)),ylim=c(0.94,1.1))
T.previous<-as.Date(T.start)%m-%months(3)
plot_cf_both<-plot_comby(p_cf[[1]],p_cf_m1[[1]],T.start = T.start,T.end=T.end,T.previous=T.previous)+
  scale_color_manual('',values=c('first'="darkgreen",'second'='black','data'='blue'),
                     label=c("first"="current forec.","second"='previous forec.','data'='data'))
# graphics.off()
print(plot_cf_both)



ggsave('cond_forc_comby.pdf',plot=plot_cf_both,device='pdf',path='figures',width=18,height=16,units = 'cm')
# threshold for probability distribution
threshold=last(y_data[,varbl2plot])*(.97)
LRHP_cf<-y_h_cf_m1["LRHP.1",]
Prob_above_threshold<-mean(LRHP_cf<threshold)
p_h_m1<-plot_cond_histo(variable=subvar[varbl2plot],horizon=1,threshold = threshold,
                        data = y_h_cf_m1,above = F,size=5)+
  theme_uniform_text_size(size=18)+ylab('')+xlab('')+
  labs(title='')+
  geom_vline(xintercept =last(y_data[,varbl2plot]),linetype='dotted',color='blue',linewidth=1.5 )+
  annotate(geom = 'text',x=last(y_data[,varbl2plot]),label='Current value',y=0,color='blue',hjust=0,vjust=1,size=5)

ggsave('cond_histo_m1.pdf',plot=p_h_m1,device='pdf',path='figures',width=18,height=16,units = 'cm')
print(p_h_m1)



q0_m1<-KL(Sigma_eps,mu_eps,h,plot_=T)
q_m1<-q0_m1[[1]]
p_m1<-q0_m1[[2]]+labs(title='')+
  theme_uniform_text_size(size=18)+ylab('')+xlab('')
graphics.off()
print(p_m1)
med_q_cf_m1=mean(q_m1)
ggsave('KL_m1.pdf',plot=p_m1,device='pdf',path='figures',width=18,height=16,units = 'cm')


# As discused by Jarocinski 2010 there can be multiple solutions when k<n*h. The APR Moore-Penrose inverse is just one of these

tmp_frc<-bsvars::forecast(
  posterior,
  horizon = 4,
  exogenous_forecast = NULL,
  conditional_forecast = as.matrix(bvarSign_path)
)

{
  f_data<-tmp_frc$forecasts
  dates_forec<-seq.Date(from=as.Date(T.start),length.out = dim(f_data)[2],by='quarter')
  rownames(f_data)<-subvar
  f_h_m<-apply(f_data,c(1,2),FUN=function(x)quantile(x,0.5)) %>% t() %>% as.data.frame()
  f_h_m$hor<-dates_forec
  f_h_l<-apply(f_data,c(1,2),FUN=function(x)quantile(x,0.16)) %>% t() %>% as.data.frame()
  f_h_l$hor<-dates_forec
  f_h_u<-apply(f_data,c(1,2),FUN=function(x)quantile(x,0.84)) %>% t() %>% as.data.frame()
  f_h_u$hor<-dates_forec
  
  f_h_m<-pivot_longer(f_h_m,cols=!"hor",names_to='variable',values_to = 'centF')
  f_h_l<-pivot_longer(f_h_l,cols=!"hor",names_to='variable',values_to = 'lowF')
  f_h_u<-pivot_longer(f_h_u,cols=!"hor",names_to='variable',values_to = 'higF')
}
f_h<-left_join(f_h_l,f_h_m,by=c('hor','variable'))
f_h<-left_join(f_h,f_h_u,by=c('hor','variable'))

#f_h
names(uncond.forc)[1:2]<-c("hor","variable")
# T.start=last(dates_date)%m+%months(3)# plus one quorter
# tmp<-3*(h-1)
# T.end=as.Date(T.start)%m+%months(tmp)
f_h$hor<-rep(seq.Date(from=as.Date(T.start),length.out=length(unique(f_h$hor)),by='quarter'),n_var) %>% sort()
# must go to - 18 months since it is the begining of the quarter
uncond.forc$hor<-rep(seq.Date(from=as.Date(T.start)%m-%months(18),length.out = length(uncond.forc$hor %>% unique()),by='quarter'),n_var) %>% sort()
test2<-left_join(p_cf[[2]],f_h,by=c('hor','variable'))
test2<-left_join(test2,uncond.forc,by=c('hor','variable'))
p<-ggplot(data=test2[test2$hor>=T.start,], aes(x=hor)) +
  ylab('')+xlab('')+labs(title='Comparison of (un-)conditional forecasts')+
  geom_point(aes(y=center, color='APR', shape='APR'),size=3) +
  geom_point(aes(y=centF, color='BVARSign', shape='BVARSign'),size=3) +
  geom_point(aes(y=Median, color='Uncond', shape='Uncond'),size=3) +
  facet_wrap(~variable, scales = 'free_y',nrow = 3) +
  scale_color_manual('', values=c('APR'='red', 'BVARSign'='blue', 'Uncond'='green')) +
  scale_shape_manual('', values=c('APR'=4, 'BVARSign'=1, 'Uncond'=6))+theme_minimal()
graphics.off()
print(p)


ggsave('cond_forc_comp.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')

