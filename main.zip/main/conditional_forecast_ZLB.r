if(F){# This is a forecast not a counterfactual
  ## ----Conditional Forecast MP only constant STR at ZLB, include=FALSE------------------------------------------------
  #NB: Y contans the data n_var x T
  colnames(Z)<-as.character(dates_date)
  data_sub<-t(Z[1:n_var,]) %>% as.data.frame()
  data_sub$year<-dates_date
  plotly::ggplotly(ggplot(data=data_sub)+geom_line(aes(x=year,y=STR3m)))
  # ZLB<-which(data_sub$STR3m<0)
  # ZLB_per<-data_sub$year[ZLB]
  # STRZLB<-data_sub$STR3m[ZLB] %>% as.data.frame()
  # rownames(STRZLB)<-ZLB_per
  
  n_sim=200 # number of shock draws
  obs=which(subvar%in%c("STR3m")) # position of observable
  pos_cond_vars=obs 
  # given the path of the observables
  TT=nrow(df)
  T.start<-'2024-01-01'
  T.end<-as.Date(T.start)%m+%months(12)
  T.previous<-as.Date(T.start)%m-%months(3)
  Z_sub<-Z[,as.Date(colnames(Z))<=as.Date(T.previous)]
  library(lubridate)
  
  path0<-df[df$year>=T.start&df$year<=T.end,'STR3m']
  periods<-dates_date[dates_date>=T.start&dates_date<=T.end]
  
  # path<-path0
  # path[path<df[df$year==T.previous,'STR3m']&!is.na(path)]<-df[df$year==T.previous,'STR3m']
  h=length(periods)+1     
  path<-rep(df[df$year==T.previous,'STR3m'],h)
  
  # uncond.forc[uncond.forc$hor>0&uncond.forc$variable==subvar[pos_cond_vars],'Median']$Median#df[(TT-h+1):TT,obs]
  bvarSign_path=df[(TT-h+1):TT,]
  bvarSign_path[,names(bvarSign_path)!=subvar[obs]]<-NA
  bvarSign_path[,names(bvarSign_path)==subvar[obs]]<-path
  bvarSign_path<-bvarSign_path[,subvar]
  
  # give the shocks that are not drivi  ng the scenario: NA if all driving
  shocks=which(!c(subset_)%in%which(subvar%in%c("STR3m")))#c(1,2,3)
  {
    if(file.exists('scenarios1_ZLB.RDS')){
      
      tmp_ZLB<-readRDS('scenarios1_ZLB.RDS')
    }else{
      start.time <- Sys.time()
      tmp_ZLB<-scenarios(h = h,path = path,obs = obs,
                         shocks = shocks,n_draws = n_draws,n_var = n_var,n_p = n_p,
                         data_ =Z_sub ,n_sample=50)
      end.time <- Sys.time()
      taken.time<-end.time-start.time
      print('time taken')
      print(taken.time)
      saveRDS(tmp_ZLB,file = 'scenarios1_ZLB.RDS')
    }
  }
  mu_eps<-tmp_ZLB[[1]]
  Sigma_eps<-tmp_ZLB[[2]]
  mu_y<-tmp_ZLB[[3]]
  Sigma_y<-tmp_ZLB[[4]]
  big_b<-tmp_ZLB[[5]]
  big_M<-tmp_ZLB[[6]]
  idx_sampled<-tmp_ZLB[[7]]
  # Actgual scenario simulation
  if(file.exists('scenarios2_ZLB.RDS')){
    readRDS('scenarios2_ZLB.RDS')
  }else{
    start.time <- Sys.time()
    y_h_cond<-SimScen(mu_eps = mu_eps,Sigma_eps = Sigma_eps,mu_y=mu_y,
                      Sigma_y=Sigma_y,
                      big_b=big_b,
                      big_M=big_M,n_sim=n_sim,h=h,
                      varbls = subvar,idx_sampled =idx_sampled )
    end.time <- Sys.time()
    taken.time<-end.time-start.time
    print('time taken')
    print(taken.time)
    saveRDS(y_h_cond,file='scenarios2_ZLB.RDS')
  }
  
  y_data<-t(Y) %>% as.data.frame()
  y_data$hor<-dates_date
  p<-plot_cond_forc(varbl2plot='pi_3m',y_h_cond=y_h_cond,
                    center=0.5,lower=0.16,upper=0.84,
                    T.start=T.start,T.end=T.end,y_data=y_data)
  
  p[[1]]<-p[[1]]+coord_cartesian(xlim=as.Date(c('2014-01-01','2025-01-01')))+theme(axis.text.x=element_text(angle=45))+
    geom_vline(xintercept = as.Date('2022-07-01'),linetype='dotted',color='red')
  print(p[[1]])
  
  y_data<-t(Y) %>% as.data.frame()
  y_data$hor<-dates_date
  p<-plot_cond_forc(varbl2plot='STR3m',y_h_cond=y_h_cond,
                    center=0.5,lower=0.16,upper=0.84,
                    T.start=T.start,T.end=T.end,y_data=y_data)
  
  p[[1]]<-p[[1]]+coord_cartesian(xlim=as.Date(c('2014-01-01','2025-01-01')))+
    geom_vline(xintercept = as.Date('2022-07-01'),linetype='dotted',color='red')
  print(p[[1]])
  
  
  y_data<-t(Y) %>% as.data.frame()
  y_data$hor<-dates_date
  p<-plot_cond_forc(varbl2plot='LRHP',y_h_cond=y_h_cond,
                    center=0.5,lower=0.16,upper=0.84,
                    T.start=T.start,T.end=T.end,y_data=y_data)
  
  p[[1]]<-p[[1]]+coord_cartesian(xlim=as.Date(c('2014-01-01','2025-01-01')))+
    geom_vline(xintercept = as.Date('2022-07-01'),linetype='dotted',color='red')
  
  
  print(p[[1]])
  ggsave('cond_forc_MP_const_rate.pdf',plot=p[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')
  
  # set threshold as x% increase since last obs
  threshold=last(dt_t[,subvar[varbl2plot]])*(0.97)
  y_h_df <- as.data.frame(t(y_h_cond))
  LRHP_cf<-y_h_df[["LRHP.1"]]
  med_<-median(LRHP_cf)
  Prob_above_threshold<-mean(LRHP_cf<threshold)
  p<-plot_cond_histo(variable=subvar[varbl2plot],horizon=1,
                     threshold = threshold,data =y_h_cond,above=F,size=5 )+xlim(c(0.75,1.5))+
    labs(title='')+
    geom_vline(xintercept =last(dt_t[,varbl2plot]),linetype='dotted',color='blue',linewidth=1.5 )+
    annotate(geom = 'text',x=last(dt_t[,varbl2plot]),label='Current value',y=0,color='blue',hjust=0,vjust=1,size=5)+
    theme_minimal(base_size = 16)
  
  
  print(p)
  
  ggsave('cond_histo_MP_const_rate.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')
  
  
  
  q0<-KL(Sigma_eps,mu_eps,h,plot_=T)
  q_MP<-q0[[1]]  
  p_MP<-q0[[2]]+labs(title='')
  med_q=mean(q_MP)
  p_MP
  ggsave('KL_MP_const_rate.pdf',plot=p_MP,device='pdf',path='figures',width=18,height=16,units = 'cm')
  # hist(q,main='KL measure (ref value 0.5)')
  
}
