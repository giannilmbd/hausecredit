# Scenario for VGP
# Scenario based on PAS projections compared to the unconditional forecast

 
  h=4
  T.start='2025-04-01'
  T.end=as.Date(T.start)%m+%months(3*(h-1))
  T.past=as.Date(T.start)%m-%months(15)
  T.previous<-as.Date(T.start)%m-%months(3)
  T.all<-seq.Date(from=as.Date(T.past),to=T.end,by='quarter')
  zero_x<-'2024-01-01'
  
  
  n_sim=500 # number of shock draws
  # fill missing GDP using growth rates and generate the forecast of GDP the same way
  
  df[df$year==T.previous,'LRGDP']<-df[df$year==T.previous%m-%months(3),'LRGDP']+
    (df[df$year==T.previous,'LRGDP_f']-df[df$year==T.previous%m-%months(3),'LRGDP_f'])
  df$LRGDP_ff<-df$LRGDP
  ggplot(df)+geom_line(aes(x=year,LRGDP_ff),color='blue')+geom_line(aes(x=year,LRGDP),color='red')
  remdates<-seq.Date(from=as.Date(T.start),to=as.Date(last(df$year)),by='quarter')
  for(cnt in 1:length(remdates) ){
    df[df$year==remdates[cnt],'LRGDP_ff']<-df[df$year==remdates[cnt]%m-%months(3),'LRGDP_ff']+
      (df[df$year==remdates[cnt],'LRGDP_f']-df[df$year==remdates[cnt]%m-%months(3),'LRGDP_f'])
  }
  
  data_0<-df[df$year>=dates_date[1]%m-%months(n_p*3)&df$year<=T.previous,c('year',subvar)]
  rownames(data_0)<-as.numeric(as.yearqtr(data_0$year))
  data_1<-data_0[,names(data_0)!='year']
  newZ<-data_companion_form(t(data_1%>% as.matrix()))[["Z"]]
  
  
  dates_date<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix1[(specification$p+1):nrow(data_matrix1),]))))
  y_data<-df[df$year>=dates_date[1]&df$year<T.start,c('year',subvar)]
  names(y_data)[names(y_data)=='year']<-'hor'
  
  summary(y_data)
  
  
  ## UNCONDITIONAL FORECAST ------------
  
  y_h_all<-forc_h(h,n_sim=n_sim,data_=newZ,posterior=posterior,matrices=matrices)
  y_h<-y_h_all[[1]]
  hist_h<-y_h_all[[3]]
  b_h<-y_h_all[[4]]
  {# extract quantiles

    
    y_h_m<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.5))
    y_h_l<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.16))
    y_h_u<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.84))
    
    
    hist_h_l<-apply(hist_h,c(1,2),FUN=function(x)quantile(x,0.16))
    hist_h_u<-apply(hist_h,c(1,2),FUN=function(x)quantile(x,0.84))
    
  }
  # convert to data frame for better manipulation
  {
    y_h_m<-as.data.frame(t(y_h_m))
    y_h_u<-as.data.frame(t(y_h_u))
    y_h_l<-as.data.frame(t(y_h_l))
    
    hist_h_u<-as.data.frame(t(hist_h_u))
    hist_h_l<-as.data.frame(t(hist_h_l))
    
    
    names(y_h_m)<-subvar
    y_h_m$hor<-1:nrow(y_h_m)
    y_h_tot<-pivot_longer(y_h_m,cols=all_of(subvar),names_to='variable',values_to='Median')
    names(y_h_l)<-subvar
    y_h_l$hor<-1:nrow(y_h_l)
    y_h_tot<-left_join(y_h_tot,
                       pivot_longer(y_h_l,cols=all_of(subvar),names_to='variable',values_to='LB'),
                       by=c('hor','variable'))
    
    names(y_h_u)<-subvar
    y_h_u$hor<-1:nrow(y_h_u)
    y_h_tot<-left_join(y_h_tot,
                       pivot_longer(y_h_u,cols=all_of(subvar),names_to='variable',values_to='UB'),
                       by=c('hor','variable'))
    
    names(hist_h_l)<-subvar
    hist_h_l$hor<-1:nrow(hist_h_l)
    hist_h_tot<- pivot_longer(hist_h_l,cols=all_of(subvar),names_to='variable',values_to='LB_s')
    
    names(hist_h_u)<-subvar
    hist_h_u$hor<-1:nrow(hist_h_u)
    hist_h_tot<-left_join(hist_h_tot,
                          pivot_longer(hist_h_u,cols=all_of(subvar),names_to='variable',values_to='UB_s'),
                          by=c('hor','variable'))
    
    
    y_h_tot<-left_join(y_h_tot,hist_h_tot,by=c('hor','variable'))
    
  }
  # inspect result
  dt_t<-as.data.frame(t(newZ[1:n_var,]))
  dt_t$hor=1:nrow(dt_t)
  y_data<-pivot_longer(dt_t,cols =all_of(1:n_var),values_to =names(y_h_tot)[3],names_to = "variable" )
  y_data<-y_data[y_data$hor>=last(y_data$hor)-4,]  
  
  y_data$hor<-y_data$hor-max(y_data$hor)
  y_data$LB<-NA
  y_data$UB<-NA
  y_data$LB_s<-NA
  y_data$UB_s<-NA
  
  y_h_tot<-rbind(y_data,y_h_tot)
  y_h_tot<-y_h_tot[order(y_h_tot$hor),]
  head(y_h_tot)
  
  uncond.forc<-y_h_tot
  # plot 
  # which variable to plot 
  varbl2plot=which(subvar%in%c("LNEER"));
  data2plot<-uncond.forc[uncond.forc$variable == subvar[varbl2plot], ]%>% as.data.frame()
  data2plot1<-data2plot %>% mutate(Median=ifelse(hor>0,NA,Median)) %>% as.data.frame()
  data2plot2<-data2plot %>% mutate(Median=ifelse(hor<=0,NA,Median))%>% as.data.frame()
  
  # >>>>> UNCONDITIONAL FORECAST PLOT ------------  
  p <- ggplot(data=data2plot1,aes(x = hor)) +
    # Median line (solid line)
    geom_line(aes(y = Median, color = "med", group = variable), linewidth = 1, show.legend = F)+
    theme(text=element_text(size=18,family = 'mono')) +theme_uniform_text_size(size=18)+
    geom_line(data=data2plot2,aes(y = Median, color = "med", group = variable), linewidth = 1, show.legend = TRUE) +
    
    # Shaded area for 68% HDI
    geom_ribbon(aes(ymin = LB, ymax = UB, group = variable), fill = "pink", 
                alpha = 0.5, show.legend = F) +
    
    # Dashed lines for 68% high credibility band of history
    geom_line(aes(y = LB_s, color = "hist"), 
              linetype = "dashed", linewidth = 0.8, show.legend = F) +
    geom_line(aes(y = UB_s, color = "hist"), 
              linetype = "dashed", linewidth = 0.8, show.legend = FALSE) +
    
    # Labels and theme
    # labs(title = "Unconditional Forecast", x = "h", y = subvar[varbl2plot]) +
    theme_minimal() +
    
    # Custom legend for colors
    scale_color_manual(
      name = "",
      labels=c('med'="Median",'hist'="no shock uncertainty."),
      values = c("med" = "blue",  'hist'= "red")
    ) +
    # labs(caption="HPD = 1 stdev (68%)")+
    ylab("")+
    theme(plot.caption.position = 'panel',plot.caption = element_text(hjust=0),
          legend.position = 'bottom',axis.text.x=element_text(angle=45))+
    scale_x_continuous(
      breaks = seq(-4, 4, by = 1),
      labels = format(T.all, "%Y-%m") # e.g., "Jan 2024"
    )+xlab('')+ylab('')+theme_uniform_text_size(size=18)
  

print(p)
pbuilt<-ggplot_build(p)
y_limits <- pbuilt$layout$panel_params[[1]]$y.range

system('mkdir -p VGP2025Q2')
ggsave('uncond_forc.pdf',plot=p,device='pdf',path='VGP2025Q2',width=18,height=16,units = 'cm')

###############################################################################
# Scenario based on PAS projections compared to the unconditional forecast ------------

dates_date<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix1[(specification$p+1):nrow(data_matrix1),]))))
y_data<-df[df$year>=dates_date[1]&df$year<T.start,c('year',subvar)]
names(y_data)[names(y_data)=='year']<-'hor'
y_data[y_data$hor==T.previous,'LRGDP']
summary(y_data)

# given the path of the observables
TT=nrow(df)

path_baseline<-rbind(df[df$year>=T.start,"STR3m_f"][1:h],
                     df[df$year>=T.start,"pi_f_3m"][1:h],
                     df[df$year>=T.start,"LRGDP_ff"][1:h],
                     df[df$year>=T.start,"spread_f"][1:h])
path<-path_baseline[c(1),] 
obs=which(subvar%in%c('STR3m')) #'pi_3m','LRGDP','spread' position of observable
pos_cond_vars=obs 

if(any(is.na(path))){
  
  stop("NA PATH")
}


# give the shocks that are not driving the scenario: NA if all driving
free_shocks=which(!1:n_var%in%obs)
data_<-newZ[rownames(newZ)!='intercept',]


tmp<-scenarios(h = h,
               path = path,
               obs = obs,
               free_shocks =free_shocks,n_sample = n_draws,
               data_ = data_,g=NULL,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)


mu_eps_STR<-tmp[[1]]
Sigma_eps_STR<-tmp[[2]]
mu_y_STR<-tmp[[3]]
Sigma_y_STR<-tmp[[4]]
big_b_STR<-tmp[[5]]
big_M_STR<-tmp[[6]]

# simulate PAS scenario with all uncertainty
y_h_cf_STR <- simulate_conditional_forecasts(mu_y=mu_y_STR,
                                             Sigma_y=Sigma_y_STR, 
                                             varnames = subvar, n_sim = n_sim)


varbl2plot<-which(subvar=="LNEER")
p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                         y_h_cond=y_h_cf_STR,
                         center=0.5,lower=0.16,upper=0.84,
                         T.start=T.start,
                         T.end=T.end,
                         before = 8,
                         y_data=y_data)
print(p_cf_STR[[1]]+xlab('')+ylab(subvar[varbl2plot])+
        coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )


varbl2plot<-which(subvar=="LRGDP")
p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                         y_h_cond=y_h_cf_STR,
                         center=0.5,lower=0.16,upper=0.84,
                         T.start=T.start,
                         T.end=T.end,
                         before = 8,
                         y_data=y_data)
print(p_cf_STR[[1]]+xlab('')+ylab(subvar[varbl2plot])+
        coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )

varbl2plot<-which(subvar=="LRMORT")
p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                         y_h_cond=y_h_cf_STR,
                         center=0.5,lower=0.16,upper=0.84,
                         T.start=T.start,
                         T.end=T.end,
                         before = 8,
                         y_data=y_data)
print(p_cf_STR[[1]]+xlab('')+ylab(subvar[varbl2plot])+
        coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )


##
data_cf<-p_cf_STR[[2]]

get_df<-function(y_h_m,ext=NULL){y_h_m.df<-y_h_m
y_h_m.df$hor<-seq.Date(as.Date(T.start),length.out=h,by='quarter')
y_h_m.df%<>%pivot_longer(.,
                         cols=all_of(subvar),
                         names_to='variable',
                         values_to=ext)
return(y_h_m.df)
}

data_uf_m<-get_df(y_h_m,'uncond_m')
data_uf_l<-get_df(y_h_l,'uncond_l')
data_uf_u<-get_df(y_h_u,'uncond_u')

data_uf<-left_join(data_uf_m,data_uf_l,by=c('hor','variable'))
data_uf<-left_join(data_uf,data_uf_u,by=c('hor','variable')) %>% as.data.frame()


data_all<-left_join(data_cf,data_uf,by=c('hor','variable'))
data_all %>% tail()
#normalize
data_all<-data_all %>% group_by(variable) %>% 
  mutate(
nval=data_all[data_all$hor==T.previous&data_all$variable==variable[1],"data"],
data=(data-nval[1])*100,
center=(center-nval[1])*100,
lower=(lower-nval[1])*100,
upper=(upper-nval[1])*100,
uncond_m=(uncond_m-nval[1])*100,
uncond_l=(uncond_l-nval[1])*100,
uncond_u=(uncond_u-nval[1])*100) %>% 
  ungroup()

## plot

plotme<-function(varbl2plot){
  p<-ggplot(data_all[data_all$hor>=zero_x&data_all$variable==subvar[varbl2plot],],aes(x=hor))+
  geom_line(aes(y=data,color='data',linetype='data'),linewidth=1)+
  geom_line(aes(y=center,color='cf_m',linetype='cf_m'),linewidth=1)+
  geom_line(aes(y=uncond_m,color='uf_m',linetype='uf_m'),linewidth=1)+
  geom_ribbon(aes(ymin=lower,ymax=upper,fill='cf'),alpha=0.2,show.legend = F)+
  geom_ribbon(aes(ymin=uncond_l,ymax=uncond_u,fill='uf'),alpha=0.2,show.legend = F)+
  scale_color_manual(name='',
                     values=c('data'='black','cf_m'='blue','uf_m'='red'),
                     labels=c('data'='data','cf_m'='cond. forec.',
                              'uf_m'='uncond. forec.'),
                     guide = guide_legend(override.aes = list(linetype = c("solid", "dashed", "dotted")))
  )+
  scale_linetype_manual(name='',
                         values=c('data'='solid','cf_m'='dashed','uf_m'='dotted'),
                         labels=c('data'='data','cf_m'='cond. forec. ',
                                  'uf_m'='uncond. forec.'),
                        guide='none')+
  scale_fill_manual(name='',
                    values=c('cf'='blue','uf'='red'),
                    labels=c('cf'='cond. forec. 68% HDI',
                             'uf'='uncond. forec. 68% HDI'))+
  theme_minimal(base_size = 16)+theme(legend.position = 'bottom',
                                      axis.text.x=element_text(angle=45))+
  theme_uniform_text_size(size=18)+xlab('')+ylab(subvar[varbl2plot])+
  scale_y_continuous(labels = function(x) paste0(x, "%"))
  
  # if(subvar[varbl2plot]=="STR3m") {
    data_range <- data_all[data_all$hor>=as.Date(zero_x)&data_all$variable==subvar[varbl2plot],]
    p <- p + annotate("text", x = min(data_range$hor), y = Inf, label = "p.p.", vjust = 1.2, hjust = -0.1)
  # }

return(p) }
######## PLOTS #############
varbl2plot<-which(subvar%in%c("LRMORT"))
p<-plotme(varbl2plot)
print(p)
ggsave(filename='cond_forc_LRMORT.pdf',plot=p,device='pdf',path='VGP2025Q2',units='cm',width=18,height=16)

varbl2plot<-which(subvar%in%c("LRHP"))
p<-plotme(varbl2plot)
print(p)
ggsave(filename='cond_forc_LRHP.pdf',plot=p,device='pdf',path='VGP2025Q2',units='cm',width=18,height=16)


varbl2plot<-which(subvar%in%c("STR3m"))
p<-plotme(varbl2plot)
print(p)
ggsave(filename='cond_forc_STR3m.pdf',plot=p,device='pdf',path='VGP2025Q2',units='cm',width=18,height=16)

# save data
saveRDS(data_all,file='VGP2025Q2/data_cond_forc.RDS')

varbl2plot<-which(subvar%in%c("spread"))
p<-plotme(varbl2plot)
print(p)
ggsave(filename='cond_forc_spread.pdf',plot=p,device='pdf',path='VGP2025Q2',units='cm',width=18,height=16)
varbl2plot<-which(subvar%in%c("LNEER"))
p<-plotme(varbl2plot)
print(p)

# save data
saveRDS(data_all,file='VGP2025Q2/data_cond_forc.RDS')
# Value at risk -------


q0_cf_STR<-KL(Sigma_eps_STR,mu_eps_STR,h,plot_=T)
q_cf_STR<-q0_cf_STR[[1]]
p_KL_cf_STR<-q0_cf_STR[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
p_KL_cf_STR
med_q_cf_STR=mean(q_cf_STR)
ggsave('KL_cf_inf_current_STR.pdf',plot=p_KL_cf_STR,device='pdf',path='VGP2025Q2',width=18,height=16,units = 'cm')



data_VaR_cf_STR<-compute_VaR(
  forecast_matrix = y_h_cf_STR,
  variables = c("pi_3m", "LRGDP", "LRHP", "LRMORT"),
  horizon = 4,
  data_frame = y_data,
  scale = c(FALSE, TRUE, TRUE, TRUE)
)
data_VaR_cf_STR['KL']<-med_q_cf_STR
data_VaR_cf_STR<-data_VaR_cf_STR[c(5,1:4)]

print(data_VaR_cf_STR)


var_html_STR<-knitr::kable(data_VaR_cf_STR,
                            format='latex',digits = 2,
                            align = "c",row.names =T,
                            col.names = c("KL","Log-real GDP %",
                                          "Infl. %",
                                          "Log-real HP %","Log-real Mortg."),booktabs=T)
# Save the HTML table to a file
cat(as.character(var_html_STR), file = "VGP2025Q2/var_html_STR.tex")
print(var_html_STR)


## VaR for unconditional 
# transform unconditional simulation first
y_h_uncond<-flatten3D(y_h)#matrix(aperm(y_h, c(2, 1, 3)), nrow = n_var * h)
rownames(y_h_uncond)<-rownames(y_h_cf_STR)
# probabilities of contraction -------------

prob_cf<-probabilities_contraction(y_h_cf_STR,y_data=y_data)[c("LRHP","LRMORT"),4]
# probabilities of contraction for unconditional
prob_uf<-probabilities_contraction(forecast_matrix = y_h_uncond,y_data=y_data)[c("LRHP","LRMORT"),4]

prob_all<-rbind(prob_cf,prob_uf)
rownames(prob_all)<-c("Scenario","Unconditional")
probs<-knitr::kable(prob_all,
                           format='latex',digits = 2,
                           align = "c",row.names =T,
                           col.names = c("Foreacast",
                                         "Log-real HP %","Log-real Mortg."),
                           booktabs=T,
                           row.nams = T)
# Save the HTML table to a file
cat(as.character(probs), file = "VGP2025Q2/probs.tex")
print(probs)


data_VaR_uncond<-compute_VaR(
  forecast_matrix = y_h_uncond,
  variables = c("pi_3m", "LRGDP", "LRHP", "LRMORT"),
  horizon = 4,
  data_frame = y_data,
  scale = c(FALSE, TRUE, TRUE, TRUE)
)
data_VaR_uncond['KL']<-c(0.5)
data_VaR_uncond<-data_VaR_uncond[c(5,1:4)]
data_VaR<-rbind(data_VaR_cf_STR,data_VaR_uncond)
rownames(data_VaR)<-c("Scenario","Unconditional")
var_html_STR<-knitr::kable(data_VaR,
                           format='latex',digits = 2,
                           align = "c",row.names =T,
                           col.names = c("Foreacast","KL","Log-real GDP %",
                                         "Infl. %",
                                         "Log-real HP %","Log-real Mortg."),
                           booktabs=T,
                           row.nams = T)
# Save the HTML table to a file
cat(as.character(var_html_STR), file = "VGP2025Q2/var_html_STR.tex")
print(var_html_STR)
