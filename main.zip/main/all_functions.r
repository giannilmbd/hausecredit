## ----Functions-----------------------------------------------------------------------------------------------
dark_green <- "#145a32" 
light_green<- "#229954" 

theme_uniform_text_size <- function(size = 12) {
  theme(text=element_text(size=size,family = 'mono')
    # plot.title      = element_text(size = size + 2),
    # plot.subtitle   = element_text(size = size + 1),
    # plot.caption    = element_text(size = size - 2),
    # axis.title.x    = element_text(size = size),
    # axis.title.y    = element_text(size = size),
    # axis.text.x     = element_text(size = size - 1),
    # axis.text.y     = element_text(size = size - 1),
    # legend.title    = element_text(size = size),
    # legend.text     = element_text(size = size - 1),
    # strip.text      = element_text(size = size)
  )
}
data_companion_form<-function(data_){
  # data_ is T x N
  # p is number of lags
  p<-specification$p
  nvar<-nrow(data_)
  nT<-ncol(data_)
  X <- do.call(rbind, lapply(1:p, function(lag) data_[, (p + 1 - lag):(nT - lag)]))
  # Add intercept row
  X <- rbind(X, rep(1, ncol(X)))
  rownames(X)[nrow(X)] <- "intercept"
  # Align Y to match X columns (drop first p columns)
  Y <- data_[, (p + 1):nT]
  # Z
  Z<- rbind(Y, X)
  # Now X is (N*p+1) x (T-p), matching the usual VAR convention
  return(list(Y=Y,X=X,Z=Z))
}

extract_shocks<-function(posterior,specification,data_=NULL){
  # In principle can extract shocks from any sample of the data
  # if use the sample used for estimation, then data_=specification $get_data_matrices()$Y
  # In this case data_ is not needed
  A<-posterior$posterior$A
  B<-posterior$posterior$B
    if (is.null(data_)){
    Y <- specification$get_data_matrices()$Y
    X <- specification$get_data_matrices()$X
  } else {
    Y <- data_
    # Assume p is defined in your environment or passed as an argument
#     nvar <- nrow(Y)
#     nT <- ncol(Y)
#     p <-specification$p
    
# X <- do.call(rbind, lapply(1:p, function(lag) Y[, (p + 1 - lag):(nT - lag)]))
# # Add intercept row
# X <- rbind(X, rep(1, ncol(X)))
# # Align Y to match X columns (drop first p columns)
# Y <- Y[, (p + 1):nT]
#     # Now X is (N*p+1) x (T-p), matching the usual VAR convention
  tmp<-data_companion_form(Y)
  Y<-tmp$Y
  X<-tmp$X
  }
  

  nvar<-dim(Y)[1]
  nT<-dim(Y)[2]
  ndraw<-dim(A)[3]
  
  shocks<-parallel::mclapply(1:ndraw, FUN = function(i) {
    eps<-B[,,i]%*%(Y-(A[,,i]%*%X))
    return(eps)
  }, mc.cores = parallel::detectCores() - 1) %>% simplify2array()
  return(shocks)
}
#' Build companion matrices and shock impact matrices from posterior draws
#' @param A_array 3D array: n_var x (n_var * p + 1) x n_draws
#' @param B_array 3D array: n_var x n_var x n_draws (bsvars B matrix: structural shocks = B * residuals)
#' @param p Number of lags in the VAR
#' @param thinning Thinning interval (default 10)
#'
#' @return A list with Btilde_list, M_full_list, intercept_list, draw_indices
build_companion_matrices <- function(A_array, B_array, p, thinning = 10) {
  n <- dim(A_array)[1]
  all_draws <- dim(A_array)[3]
  nK <- n * p
  if (all_draws < thinning) thinning <- 1
  draw_indices <- seq(1, all_draws, by = thinning)
  
  Btilde_list <- list()
  M_full_list <- list()
  intercept_list <- list()
  
  for (d in seq_along(draw_indices)) {
    draw <- draw_indices[d]
    
    A_matrix <- A_array[, , draw]
    Bmat <- A_matrix[, 1:(n * p)]
    intercept <- A_matrix[, n * p + 1]  # n x 1
    
    # Build Btilde (nK x nK)
    Btilde <- matrix(0, nK, nK)
    Btilde[1:n, 1:(n * p)] <- Bmat
    
    # Identity shift block
    if (p > 1) {
      for (k in 1:(p - 1)) {
        row_start <- k * n + 1
        row_end   <- (k + 1) * n
        col_start <- (k - 1) * n + 1
        col_end   <- k * n
        Btilde[row_start:row_end, col_start:col_end] <- diag(n)
      }
    }
    
    # Build M_full using inverse of B_array (nK x n)
    M_full <- matrix(0, nK, n)
    M_full[1:n, ] <- solve(B_array[, , draw])
    
    # Intercept (nK x 1)
    intercept_full <- rep(0, nK)
    intercept_full[1:n] <- intercept
    
    # Store
    Btilde_list[[d]] <- Btilde
    M_full_list[[d]] <- M_full
    intercept_list[[d]] <- intercept_full
  }
  
  return(list(
    Btilde = Btilde_list,
    M_full = M_full_list,
    intercept = intercept_list,
    draw_indices = draw_indices
  ))
}

#' Matrix power utility
matrix_power <- function(mat, pow) {
  if (!is.numeric(pow) || length(pow) != 1 || pow != floor(pow) || pow < 0)
    stop("Exponent 'pow' must be a non-negative integer scalar.")
  if (pow == 0) return(diag(nrow(mat)))
  if (pow == 1) return(mat)
  result <- mat
  for (i in 2:pow) result <- result %*% mat
  return(result)
}

#' Historical decomposition generator
#'
#' @param data_ Original data (T x n_var)
#' @param p Lag order
#' @param Btilde_list Companion matrices
#' @param M_full_list Shock matrices
#' @param intercept_list Intercepts
#' @param shocks Structural shocks (n_var x T x n_draws)
#' @param T0 Start time to suppress shocks
#' @param T1 End time to suppress shocks
#'
#' @return Array of shape n_var x n_var x T x n_draws
historical_decomposition <- function(data_, p, Btilde_list,
                                     M_full_list, intercept_list,
                                     shocks, T0, T1) {
  data_ <- t(data_)  # n x T_full
  n <- nrow(data_)
  T_full <- ncol(data_)
  T <- T_full - p
  nK <- n * p
  n_draws <- length(Btilde_list)
  
  # Adjusted indices (apply to VAR-shrunk time base)
  T0_adj <- T0 - p
  T1_adj <- T1 - p
  H <- T1_adj - T0_adj + 1  # Length of interval
  
  hd_array <- array(0, dim = c(n, n, H, n_draws))
  
  # Construct Z0 from Y_{T0 - 1}, ..., Y_{T0 - p}
  Z0 <- as.vector(sapply(1:p, function(x) data_[, T0 - x]))
  
  myfunction <- function(d) {
    Btilde <- Btilde_list[[d]]
    M_full <- M_full_list[[d]]
    intercept <- intercept_list[[d]]
    
    Z_baseline <- matrix(0, nK, H)
    Z_cf <- matrix(0, nK, H)
    
    for (t in 1:H) {
      t_full <- T0_adj + t - 1  # Actual time index in shocks
      Bt_Z0 <- matrix_power(Btilde, t) %*% Z0
      shock_sum_base <- rep(0, nK)
      shock_sum_cf <- rep(0, nK)
      intercept_sum <- rep(0, nK)
      
      for (i in 0:(t - 1)) {
        Bi <- matrix_power(Btilde, i)
        eps_ti <- shocks[, t_full - i, d]
        eps_cf <- eps_ti
        if ((t_full - i + p) >= T0 && (t_full - i + p) <= T1) {
          eps_cf[shock_idx] <- 0
        }
        
        shock_sum_base <- shock_sum_base + Bi %*% M_full %*% eps_ti
        shock_sum_cf <- shock_sum_cf + Bi %*% M_full %*% eps_cf
        intercept_sum <- intercept_sum + Bi %*% intercept
      }
      
      Z_baseline[, t] <- Bt_Z0 + shock_sum_base + intercept_sum
      Z_cf[, t] <- Bt_Z0 + shock_sum_cf + intercept_sum
    }
    
    # Difference in top block (Y_t)
    Y_diff <- Z_cf[1:n, , drop = FALSE]
    return(Y_diff)
  }
  
  for (shock_idx in 1:n) {
    Z_diff_list <- parallel::mclapply(
      seq_len(n_draws),
      FUN = function(d) myfunction(d),
      mc.cores = min(n_draws, parallel::detectCores() - 1)
    )
    for (d in seq_len(n_draws)) {
      hd_array[, shock_idx, , d] <- Z_diff_list[[d]]
    }
  }
  
  return(hd_array)
}

#' Plot historical decomposition panels per variable
#'
#' @param hd_array Output from historical_decomposition (n_var x n_var x T x n_draws)
#' @param data_ Original data (T x n_var)
#' @param T0, T1 Time range to show
#' @param variable_names Optional names of variables
#' @param shock_names Optional names of shocks
#'
#' @return ggplot panels, one per variable
plot_historical_decomposition <- function(hd_array, T0, T1,
                                          variable_names = NULL,
                                          shock_names = NULL) {
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  
  n_var <- dim(hd_array)[1]
  n_shock <- dim(hd_array)[2]
  T <- dim(hd_array)[3]
  n_draws <- dim(hd_array)[4]
  
  if (is.null(variable_names)) variable_names <- paste0("Var", seq_len(n_var))
  if (is.null(shock_names)) shock_names <- paste0("Shock", seq_len(n_shock))
  
  # Median over draws
  HD_median <- apply(hd_array, c(1, 2, 3), median)
  
  # Build tidy data frame
  df_list <- vector("list", length = n_var)
  time_axis <- T0:T1
  
  for (i in 1:n_var) {
    df <- data.frame(time = time_axis, variable = variable_names[i])
    for (j in 1:n_shock) {
      df[[shock_names[j]]] <- HD_median[i, j, ]
    }
    df_long <- pivot_longer(df, cols = all_of(shock_names),
                            names_to = "shock", values_to = "contrib")
    df_list[[i]] <- df_long
  }
  
  df_all <- bind_rows(df_list)
  df_all$variable <- factor(df_all$variable, levels = variable_names)
  
  ggplot(df_all, aes(x = time)) +
    geom_col(aes(y = contrib, fill = shock), position = "dodge", color = 'gray') +
    facet_wrap(~variable, scales = "free_y") +
    scale_fill_brewer(palette = "Paired") +
    geom_vline(xintercept = seq(T0 + 0.5, T1 - 0.5, by = 1),
               color = "black", linetype = "dashed", linewidth = 0.3) +
    theme_minimal() +
    xlab("") + ylab("") +
    theme(legend.position = "bottom",
          axis.text.x = element_text(angle = 45))
}


generate_Z_from_shocks <- function(data_, p, Btilde_list,
                                   M_full_list, intercept_list, shocks) {
  data_ <- t(data_)  # shape: n x T
  n <- nrow(data_)
  T_full <- ncol(data_)
  T <- T_full - p
  nK <- n * p
  n_draws <- length(Btilde_list)
  
  stopifnot(dim(shocks)[1] == n, dim(shocks)[2] == T, dim(shocks)[3] == n_draws)
  
  # Z0: correct stacking: [Y_{t-1}; Y_{t-2}; ... Y_{t-p}]
  Z0 <- as.vector(sapply(1:p, function(lag) data_[, p - lag + 1]))
  
  # Parallel simulation over draws
  Z_sim_list <- parallel::mclapply(seq_len(n_draws), function(d) {
    Btilde <- Btilde_list[[d]]
    M_full <- M_full_list[[d]]
    intercept <- intercept_list[[d]]
    Z_sim <- matrix(0, nK, T)
    
    for (t in 1:T) {
      Bt_Z0 <- matrix_power(Btilde, t) %*% Z0
      shock_sum <- rep(0, nK)
      intercept_sum <- rep(0, nK)
      
      for (i in 0:(t - 1)) {
        Bi <- matrix_power(Btilde, i)
        shock_sum <- shock_sum + Bi %*% M_full %*% shocks[, t - i, d]
        intercept_sum <- intercept_sum + Bi %*% intercept
      }
      
      Z_sim[, t] <- Bt_Z0 + shock_sum + intercept_sum
    }
    
    return(Z_sim)
  }, mc.cores = parallel::detectCores() - 1)
  
  Z_sim_all <- simplify2array(Z_sim_list)  # shape: nK x T x n_draws
  return(Z_sim_all)
}
#' Generate Z from Custom Initial State Z0
#'
#' Simulates the VAR path using a custom initial Z0 vector, shock path, and posterior draw components.
#' Aligns shocks and X by date, and constructs Z paths using the VMA representation.
#'
#' @param X Matrix of stacked lags (nK x T), with colnames as dates
#' @param Btilde_list List of companion matrices (length = n_draws)
#' @param M_full_list List of structural impact matrices (length = n_draws)
#' @param intercept_list List of intercept vectors (length = n_draws)
#' @param shocks Full array of structural shocks (n_vars x T_shock x n_draws)
#' @param T0 Index in X corresponding to the *first* counterfactual period. Z0 is taken as X[, T0].
#'
#' @return Array of shape nK x T_cf x n_draws with simulated Z paths
#' @export
generate_Z_from_shocks_Z0 <- function(X, Btilde_list, M_full_list, intercept_list, shocks, T0) {
  nK <- nrow(X)
  n_vars <- dim(shocks)[1]
  T_shock <- dim(shocks)[2]
  n_draws <- dim(shocks)[3]
  
  Z0 <- X[, T0]  # Initial condition is now X[, T0] (X already lagged)
  T_cf <- T_shock - T0 +1 # Number of periods simulated from T0+1 onward
  
  stopifnot(T_cf > 0)
  stopifnot(dim(shocks)[3] == length(Btilde_list))
  stopifnot(all(c(length(M_full_list), length(intercept_list)) == n_draws))
  
  Z_sim_list <- parallel::mclapply(seq_len(n_draws), function(d) {
    Btilde <- Btilde_list[[d]]
    M_full <- M_full_list[[d]]
    intercept <- intercept_list[[d]]
    
    Z_sim <- matrix(0, nK, T_cf)
    
    # Precompute Btilde powers
    B_powers <- list(diag(nK))
    for (i in 1:T_cf) {
      B_powers[[i + 1]] <- Btilde %*% B_powers[[i]]
    }
    
    for (t in 1:T_cf) {
      Bt_Z0 <- B_powers[[t + 1]] %*% Z0
      shock_sum <- rep(0, nK)
      intercept_sum <- rep(0, nK)
      
      for (i in 0:(t - 1)) {
        Bi <- B_powers[[i + 1]]
        shock_sum <- shock_sum + Bi %*% M_full %*% shocks[, T0 + t - 1 - i, d]
        intercept_sum <- intercept_sum + Bi %*% intercept
      }
      
      Z_sim[, t] <- Bt_Z0 + shock_sum + intercept_sum
    }
    
    return(Z_sim)
  }, mc.cores = parallel::detectCores() - 1)
  
  Z_sim_all <- simplify2array(Z_sim_list)
  return(Z_sim_all)
}


check_iid_shocks <- function(stsh_m) {
  library(tseries)  # For Ljung-Box test
  library(stats)    # For Shapiro-Wilk test
  if(dim(stsh_m)[1]>dim(stsh_m)[2])stsh_m<-t(stsh_m)
  n_shocks <- dim(stsh_m)[1]  # Number of shocks (variables)
  n_periods <- dim(stsh_m)[2]  # Number of time periods
  
  results <- data.frame(
    Shock = character(n_shocks),
    ACF_Lag1 = numeric(n_shocks),
    BoxTest_pval = numeric(n_shocks),
    Shapiro_pval = numeric(n_shocks),
    IID = logical(n_shocks),
    stringsAsFactors = FALSE
  )
  
  for (i in 1:n_shocks) {
    shock_series <- stsh_m[i, ]  # Extract time series of shock i
    
    # Compute autocorrelation at lag 1
    acf_lag1 <- acf(shock_series, plot = FALSE, lag.max = 1)$acf[2]
    
    # Box-Pierce / Ljung-Box test for serial correlation (H0: No autocorrelation)
    box_test <- Box.test(shock_series, lag = 10, type = "Ljung-Box")  # 10 lags
    
    # Shapiro-Wilk test for normality (H0: Normal distribution)
    shapiro_test <- shapiro.test(shock_series)
    
    # Determine if IID (no autocorrelation & normality)
    iid_status <- (box_test$p.value > 0.05)# & (shapiro_test$p.value > 0.05)
    
    # Store results
    results[i, ] <- list(
      Shock = paste0("Shock_", i),
      ACF_Lag1 = round(acf_lag1, 3),
      BoxTest_pval = round(box_test$p.value, 3),
      Shapiro_pval = round(shapiro_test$p.value, 3),
      IID = iid_status
    )
  }
  
  return(results)
}
#' Construct the companion form of a VECM from a VAR(p)
#'
#' The model is expressed as:
#'   ΔY_t = Γ ΔY_{t-1} + Π (Y_{t-1} + const) + B^{-1} ε_t
#'
#' @param A VAR coefficient matrix (N x (N*p + 1)), last column is the intercept
#' @param B Matrix from bsvars: U = B * E, where E = reduced form residuals
#' @param p Lag order of the VAR
#'
#' @return A list with components:
#'   - G: State transition matrix for the companion form
#'   - C: Constant term vector
#'   - R: Impact matrix for structural shocks ε (R = inv(B) padded in top block)
#'   - Pi: Long-run matrix
#'   - Gamma: Array of short-run matrices
#'   - const: Intercept from levels equation
construct_VECM_companion <- function(A, B, p) {
  N <- dim(A)[1]
  K <- dim(A)[2]
  
  if (K != p * N + 1) stop("A must be of dimension N x (N*p + 1)")
  if (!all(dim(B) == c(N, N))) stop("B must be of dimension N x N")
  
  # Extract constant (last column)
  const <- A[, K, drop = FALSE]
  
  # Extract Phi_1 to Phi_p (VAR coefficient matrices)
  Phi <- array(0, dim = c(N, N, p))
  for (i in 1:p) {
    Phi[, , i] <- A[, ((i - 1) * N + 1):(i * N), drop = FALSE]
  }
  
  # Compute long-run matrix Pi and short-run matrices Gamma
  Pi <- apply(Phi, c(1, 2), sum) - diag(N)
  Gamma <- array(0, dim = c(N, N, p - 1))
  for (i in 1:(p - 1)) {
    Gamma[, , i] <- -apply(Phi[, , (i + 1):p, drop = FALSE], c(1, 2), sum)
  }
  
  # Build companion matrices
  k <- p - 1
  dim_Z <- N * k + N  # Z_t = [ΔY_{t-1}; ... ; ΔY_{t-(p-2)}; Y_{t-1}]
  
  # Transition matrix G
  G <- matrix(0, nrow = dim_Z, ncol = dim_Z)
  if (k > 0) {
    for (i in 1:k) {
      G[1:N, ((i - 1) * N + 1):(i * N)] <- Gamma[, , i]
    }
  }
  G[1:N, (N * k + 1):(N * k + N)] <- Pi
  
  # Fill identity shift for ΔY lags
  if (k > 1) {
    G[(N + 1):(N * k), 1:(N * (k - 1))] <- diag(N * (k - 1))
  }
  
  # Constant term (contribution from levels intercept through Pi)
  C <- matrix(0, nrow = dim_Z, ncol = 1)
  C[1:N, 1] <- Pi %*% const
  
  # Structural shocks: reduced-form E = B^{-1} ε → impact = inv(B)
  R <- matrix(0, nrow = dim_Z, ncol = N)
  R[1:N, ] <- solve(B)
  
  return(list(
    G = G,
    C = C,
    R = R,
    Pi = Pi,
    Gamma = Gamma,
    const = const
  ))
}

#' Historical decomposition of ΔY using VECM, auto-constructing Z0 from data
#'
#' The model is:
#'   ΔY_t = Γ ΔY_{t-1} + Π (Y_{t-1} + const) + B^{-1} ε_t
#'
#' @param G VECM companion transition matrix
#' @param C Constant vector in the companion form
#' @param R Shock impact matrix (R = inv(B) padded)
#' @param data_ Matrix of observed data (N x T_total), must include p lags
#' @param shocks Matrix of structural shocks (N x T_total - p)
#' @param T0 Index for start of simulation (≥ p + 1, 1-based)
#' @param T1 Index for end of simulation (inclusive)
#' @param p Lag order of the original VAR
#'
#' @return Array of shape (N, N, T1 - T0 + 1) with contributions of each shock to ΔY
hd_VECM_decomp_from_data <- function(G, C, R, data_, shocks, T0, T1, p) {
  if(dim(data_)[1]>dim(data_)[2])data_<-t(data_)
  if(dim(shocks)[1]>dim(shocks)[2])shocks<-t(shocks)
  N <- nrow(data_)
  T_data <- ncol(data_)
  T_shocks <- ncol(shocks)
  H <- T1 - T0 + 1
  
  if (T1 > T_shocks) stop("T1 exceeds shock matrix dimension")
  if (T0 <= p) stop("T0 must be > p because of lag construction")
  
  # Construct Z0: [ΔY_{t-1}; ... ; ΔY_{t-(p-1)}; Y_{t-1}]
  dY_lags <- matrix(0, nrow = N * (p - 1), ncol = 1)
  for (i in 1:(p - 1)) {
    dY_lags[((i - 1) * N + 1):(i * N), 1] <- data_[, T0 - i] - data_[, T0 - i - 1]
  }
  Y_lag <- data_[, T0 - 1, drop = FALSE]
  Z0 <- rbind(dY_lags, Y_lag)
  
  # Helper to simulate path of ΔY from shocks
  simulate_path <- function(Z0, shocks_sub) {
    T_len <- ncol(shocks_sub)
    Z <- matrix(0, nrow = length(Z0), ncol = T_len + 1)
    Z[, 1] <- Z0
    dY <- matrix(0, nrow = N, ncol = T_len)
    for (t in 1:T_len) {
      Z[, t + 1] <- C + G %*% Z[, t] + R %*% shocks_sub[, t]
      dY[, t] <- Z[1:N, t + 1]
      # Update Y_{t} = Y_{t-1} + ΔY_{t}
      Z[(N * (p - 1) + 1):(N * p), t + 1] <- Z[(N * (p - 1) + 1):(N * p), t] + dY[, t]
    }
    return(dY)
  }
  
  # Baseline ΔY path with all shocks
  dY_true <- simulate_path(Z0, shocks[, T0:T1, drop = FALSE])
  
  # Contribution of each shock
  contrib <- array(0, dim = c(N, N, H))
  
  for (j in 1:N) {
    shocks_muted <- shocks[, T0:T1, drop = FALSE]
    shocks_muted[j, ] <- 0  # zero out shock j
    dY_muted <- simulate_path(Z0, shocks_muted)
    contrib[, j, ] <- dY_true - dY_muted
  }
  
  return(contrib)
}

#' Construct VECM companion systems for all posterior draws
#'
#' @param A_array Array of shape (N x (N*p + 1) x draws)
#' @param B_array Array of shape (N x N x draws)
#' @param p Lag order of VAR
#' @param mc.cores Number of cores for parallel processing
#'
#' @return List of length draws, each with a VECM companion system
construct_VECM_companion_posterior <- function(A_array, B_array, p, mc.cores = 2) {
  draws <- dim(A_array)[3]
  
  parallel::mclapply(1:draws, function(d) {
    A_draw <- A_array[, , d]
    B_draw <- B_array[, , d]
    construct_VECM_companion(A_draw, B_draw, p)
  }, mc.cores = mc.cores)
}

#' Perform historical decomposition for all draws
#'
#' @param vecm_list List of VECM companion systems (from previous function)
#' @param data_ Original data (N x T_total), must have p extra obs for lags
#' @param shocks_array Array (N x T x draws) of structural shocks
#' @param T0, T1 Time window for HD
#' @param p Lag order
#' @param mc.cores Number of cores for parallel processing
#'
#' @return Array of shape (N, N, T1 - T0 + 1, draws)



hd_VECM_decomp_posterior <- function(vecm_list, data_, shocks_array, T0, T1, p, mc.cores = 2) {
  if(dim(data_)[1]>dim(data_)[2])data_<-t(data_)
  draws <- length(vecm_list)
  N <- dim(data_)[1]
  H <- T1 - T0 + 1
 
  results <- parallel::mclapply(1:draws, function(d) {
    vecm <- vecm_list[[d]]
    shocks_d <- shocks_array[, , d]
    hd_VECM_decomp_from_data(vecm$G, vecm$C, vecm$R, data_, shocks_d, T0, T1, p)
  }, mc.cores = mc.cores)
  
  # Combine to array: N x N x T x draws
  result_array <- array(unlist(results), dim = c(N, N, H, draws))
  return(result_array)
}

library(parallel)

#' Parallel quantile reduction over draws using mclapply
#' @param hd_array_all Array (N x N x T x D)
#' @param prob Quantile to compute (e.g. 0.5)
#' @param mc.cores Number of parallel cores
#'
#' @return Array of shape (N, N, T) with requested quantile
mclapply_quantile_over_draws <- function(hd_array_all, prob = 0.5, mc.cores = 4) {
  dims <- dim(hd_array_all)
  N1 <- dims[1]
  N2 <- dims[2]
  T <- dims[3]
  D <- dims[4]
  
  # Index all positions
  idx_list <- expand.grid(i = 1:N1, j = 1:N2, t = 1:T)
  
  # Compute quantile across draws for each (i, j, t)
  q_vals <- parallel::mclapply(1:nrow(idx_list), function(n) {
    idx <- idx_list[n, ]
    vec <- hd_array_all[idx$i, idx$j, idx$t, ]
    quantile(vec, probs = prob)
  }, mc.cores = mc.cores)
  
  # Convert to array
  result <- array(unlist(q_vals), dim = c(N1, N2, T))
  return(result)
}

plot_hd_vecm_dodged <- function(hd_array,
                                variable_names = NULL,
                                shock_names = NULL,
                                T_start = NULL,T_end=NULL) {
  N <- dim(hd_array)[1]
  T_len <- dim(hd_array)[3]
  
  if (is.null(variable_names)) variable_names <- paste0("Var", 1:N)
  if (is.null(shock_names)) shock_names <- paste0("Shock", 1:N)
  
  time_vec <- T_start:(T_start + T_len - 1)  # Explicit time index
  
  df_list <- vector("list", length = N)
  for (i in 1:N) {
    df <- as.data.frame(t(hd_array[i, , ]))  # T x N_shocks
    colnames(df) <- shock_names
    df$time <- time_vec
    df$variable <- variable_names[i]
    
    df_long <- tidyr::pivot_longer(df, cols = all_of(shock_names),
                                   names_to = "shock", values_to = "contrib") %>%
      dplyr::mutate(time = as.numeric(time))  # Ensure numeric for x-axis
    
    df_list[[i]] <- df_long
  }
  
  df_all <- dplyr::bind_rows(df_list)
  df_all$variable <- factor(df_all$variable, levels = variable_names)
  
  gg <- ggplot(df_all, aes(x = time)) +
    geom_col(
      aes(y = contrib, fill = shock, group = shock),
      position = "dodge",
      color = "gray"
    ) +
    facet_wrap(~variable, scales = "free_y") +
    scale_fill_brewer(palette = "Paired") +
    theme_minimal() +
    xlab("") + ylab("")+  geom_vline(
      xintercept = seq(T_start + 0.5, T_end - 0.5, by = 1),  # lines between time steps
      color = "black", linetype = "dashed", linewidth = 0.3
    )
  
  return(gg)
}

plot_cumulative_hd_vecm <- function(hd_array, T0, T1,
                                    variable_names = NULL,
                                    shock_names = NULL) {

  
  n_var <- dim(hd_array)[1]
  n_shock <- dim(hd_array)[2]
  T <- dim(hd_array)[3]
  
  if (is.null(variable_names)) variable_names <- paste0("Var", seq_len(n_var))
  if (is.null(shock_names)) shock_names <- paste0("Shock", seq_len(n_shock))
  
  
  # Cumulative sum over time for each (i, j)
  HD_cum <- apply(hd_array, c(1, 2), cumsum)  # returns N x N x T
  HD_cum <- aperm(HD_cum, c(2, 3, 1)) # when returning same dims as input have to permute them
  # Build tidy dataframe
  df_list <- vector("list", length = n_var)
  time_axis <- T0:T1
  
  for (i in 1:n_var) {
    df <- data.frame(time = time_axis, variable = variable_names[i])
    for (j in 1:n_shock) {
      df[[shock_names[j]]] <- HD_cum[i, j, ]
    }
    df_long <- pivot_longer(df, cols = all_of(shock_names),
                            names_to = "shock", values_to = "contrib")
    df_list[[i]] <- df_long
  }
  
  df_all <- bind_rows(df_list)
  df_all$variable <- factor(df_all$variable, levels = variable_names)
  
  gg<-ggplot(df_all, aes(x = time)) +
    geom_col(aes(y = contrib, fill = shock), position = "dodge", color = 'gray') +
    facet_wrap(~variable, scales = "free_y") +
    scale_fill_brewer(palette = "Paired") +
    geom_vline(xintercept = seq(T0 + 0.5, T1 - 0.5, by = 1),
               color = "black", linetype = "dashed", linewidth = 0.3) +
    theme_minimal() +
    xlab("") + ylab("Cumulative contribution to level") +
    theme(legend.position = "bottom",
          axis.text.x = element_text(angle = 45)) +
    labs(subtitle = "Cumulative historical decomposition (VECM)")
  return(gg)
}

library(urca)

test_stationarity_PiY <- function(Pi, Y) {
  N <- dim(Pi)[1]
  T_total <- dim(Y)[2]
  
  Pi_Y_lagged <- matrix(0, nrow = N, ncol = T_total - 1)
  for (t in 2:T_total) {
    Pi_Y_lagged[, t - 1] <- Pi %*% Y[, t - 1]
  }
  
  stationarity_results <- data.frame(
    Variable = character(N),
    Test_Type = character(N),
    ADF_stat = numeric(N),
    CV_5pct = numeric(N),
    Stationary = logical(N),
    stringsAsFactors = FALSE
  )
  
  for (i in 1:N) {
    adf_test <- ur.df(Pi_Y_lagged[i, ], type = "drift", selectlags = "AIC")
    
    available_tests <- colnames(adf_test@teststat)
    available_cvals <- rownames(adf_test@cval)
    
    # Choose the first common test from the standard priority order
    test_type <- intersect(c("tau2", "tau3", "tau1"), available_tests)[1]
    
    if (!is.na(test_type) && test_type %in% available_cvals) {
      stat <- adf_test@teststat["statistic", test_type]
      cv <- adf_test@cval[test_type, "5pct"]
      is_stationary <- stat < cv
    } else {
      stat <- NA
      cv <- NA
      is_stationary <- NA
      test_type <- "none"
      warning(paste("No suitable ADF test statistic found for Var", i))
    }
    
    stationarity_results[i, ] <- list(
      Variable = paste0("Var_", i),
      Test_Type = test_type,
      ADF_stat = round(stat, 3),
      CV_5pct = round(cv, 3),
      Stationary = is_stationary
    )
  }
  
  return(stationarity_results)
}





bayes_bands<-function(fit=NULL,obj=NULL){
  mu_a_sims<-try(as.matrix(fit, 
                           pars = obj),silent = T)#
  
  # draws for 73 schools' school-level error
  obj2=gsub(pattern = '\\(',replacement='\\\\(',x=obj)
  obj2=gsub(pattern = '\\)',replacement='\\\\)',x=obj2)
  u_sims <- as.matrix(fit, 
                      regex_pars = paste0("b\\[",obj2," cc\\:"))
  # draws for 73 schools' varying intercepts               
  a_sims <- as.numeric(mu_a_sims) + u_sims 
  
  a_quant <- apply(X = a_sims, 
                   MARGIN = 2, 
                   FUN = quantile, 
                   probs = c(0.025, 0.50, 0.975))
  a_quant <- data.frame(t(a_quant))
  names(a_quant) <- c("Q2.5", "Q50", "Q97.5")
  a_quant$cc<-gsub(pattern=paste0("b|\\[|",obj2,"| cc|\\:|\\]|\\s*"),replacement = '',x=rownames(a_quant))
  rownames(a_quant)<-a_quant$cc
  return(a_quant)
}



# FUNCTION TO RETRIEVE DATA FROM EASY R IN A FORMAT USEFUL FOR THIS PROJECT
get_data<-function(key=NULL,name=NULL,begin=NULL){
  df<- try(snbeasy::load_long(datalocators = key,begin=begin)[[1]],silent = T)
  if(class(df)!='try-error'){head(df)}
  df$anno<-lubridate::year(df$Index)
  df$quarter<-lubridate::quarter(df$Index) 
  df.q<- df %>% group_by(anno,quarter) %>% reframe(tmp = mean(Value,na.rm=T)) %>% as.data.frame
  names(df.q)[names(df.q)=='tmp']<-name
  df.q$year<-as.Date(as.yearqtr(paste(df.q$anno,df.q$quarter,sep='-Q'),'%Y-Q%q')) %>% as.yearqtr()
  head(df.q)
  df.q<-df.q[,-c(1:2)]
  return(df.q)
}

# FUNCTION TO PLOT IRFS. For plotting I use the package ggplot2
plt_irf<-function(model=NULL){
  model<-irf(model)
  qnt<-model$quants
  vrb<-model$variables
  h<-dim(qnt)[3] 
  nvar<-dim(qnt)[2]
  nsh<-dim(qnt)[4]
  plst<-list()
  zcnt<-1
  for(cnt1 in 1:nvar){
    for (cnt2 in 1:nsh){
      
      plst[[zcnt]]<-ggplot(data=t(qnt[,cnt1,,cnt2]),aes(x=1:h))+
        geom_line(aes(y=`50%`))+
        geom_line(aes(y=`16%`),color='blue',linetype='dotted')+
        geom_line(aes(y=`84%`),color='blue',linetype='dotted')+
        geom_ribbon(aes(ymin=`16%`,ymax=`84%`),fill='pink',alpha=0.2)+
        ylab('')+xlab('')+labs(title=paste0(vrb[cnt2],' => ',vrb[cnt1]))+theme(title=element_text(size=8,family='mono'))+geom_hline(yintercept=0,color='red',linetype='dashed')
      zcnt<-zcnt+1
    }
  }
  p<-grid.arrange(grobs=plst,nrow=nvar,ncol=nvar)
  return(p) # use grid::grid.draw(p)
}

# Function to return sample/model info

rt_smpl<-function(model1=NULL,model2=NULL){
  lng<-length(model1)
  nms<-c('beta','sigma','hyper')
  for(cnt0 in nms){
    vrb_b<-model1[[1]][[cnt0]]
    
    for(cnt in 2:lng){
      
      vrb_b<-abind::abind(vrb_b,model1[[cnt]][[cnt0]],along = 1)
    }
    tmp<-sample(1:dim(vrb_b)[1],dim(model2[[cnt0]])[1])
    if(vrb_b%>% dim() %>% length()<3){
      model2[[cnt0]]<-vrb_b[tmp,]
    }else{
      model2[[cnt0]]<-vrb_b[tmp,,]
    }
  }
  return(model2)
}





# FUNCTION TO PRODUCE IRFS WITH BVAR --------------
# I've collected all steps into this function. Need to give the data, subset and sign restriction (see use below)
irf_bvar<-function(X=NULL,subset_=NULL,sr=NULL){
  strt<-Sys.time()
  
  X<-X[,subset_] %>% na.exclude()
  sr<-sr[subset_,subset_]
  varbls<-colnames(X)
  tmp<-sr
  rownames(tmp)<-varbls
  colnames(tmp)<-varbls
  print(kable(tmp))
  summary(X)
  print(nrow(X))
  
  
  
  # Set up Minnesota prior
  # Priors for Psi: These are typically set as inverse gammas calibrated on the square root of the data innovation variance (eg after fitting an AR(p) process)
  # The function apply applies the "FUN" to the matrix X along the 2-nd dimension.
  res_arima<-apply(X,2,FUN=function(x){fit<-forecast::auto.arima(x);y=fit$sigma2 %>% sqrt();return(y)})
  
  # Set BVAR with standard parameters. I'm calibrating the stdev on the data using an ARIMA (see above)
  mn <- bv_minnesota(
    lambda = bv_lambda(mode = 0.2, sd = 0.4, min = 0.0001, max = 5),
    alpha = bv_alpha(mode = 2),
    psi=bv_psi(mode=c(res_arima),min=c(res_arima)/100,max=c(res_arima)*100),var = 1e07)
  
  # Set up sum of coefficients and single unit root prior (see documentation)
  soc <- bv_soc(mode = 1, sd = 1, min = 1e-04, max = 50)
  sur <- bv_sur(mode = 1, sd = 1, min = 1e-04, max = 50)
  
  # all priors
  priors <- bv_priors(hyper = "auto" #c("lambda", "alpha", "psi") but then have to give all hyper parameters
                      , mn = mn, soc = soc, sur = sur)
  # Metropolis algorithm
  mh <- bv_metropolis(scale_hess = c(0.05, 0.0001, 0.0001),
                      adjust_acc = TRUE, acc_lower = 0.25, acc_upper = 0.35)
  # actual estimation
  run <- bvar(X, lags = 2, n_draw = 55000, n_burn = 5000, n_thin = 2,
              priors = priors, mh = mh, verbose = TRUE)
  
  
  
  
  
  
  print(sr)
  opt_signs<-bv_irf(horizon=16,fevd=TRUE,identification = T,sign_restr=sr,sign_lim=20000)
  print(opt_signs)
  varbls[subset_]
  irf(run)<-irf(run,opt_signs)
  p<-plot(irf(run))
  end_<-Sys.time()
  print(end_-strt)
  return(run)
} # END FUNCTION TO ESTIMATE THE BVAR

# turn conditional forcast moments into data frames

#' Pure Counterfactual Generator (VMA-based)
#'
#' This function simulates a counterfactual history where one or more observable variables are
#' treated as exogenous (their paths are imposed), and specific corresponding shocks are inferred,
#' while all other shocks are fixed to their historical realizations.
#'
#' @param data_ Original data (T x n_var), with rownames as dates (character or Date)
#' @param p Lag order
#' @param Btilde_list Companion form transition matrices (list)
#' @param M_full_list Structural impact matrices (list)
#' @param intercept_list Intercept vectors (list)
#' @param shocks Structural shocks (n_var x T x n_draws) with dimnames[[2]] as dates
#' @param target_vars Integer vector of variables (1-based) to impose
#' @param shock_vars Integer vector of shocks (1-based) used to support the imposed variables
#' @param T0 Date string or Date object representing first period to impose the path
#' @param T1 Date string or Date object representing last period to impose the path
#' @param imposed_path A matrix (T1 - T0 + 1 x n_targets) or vector (if single target) with imposed paths (will be expanded over draws)
#'
#' @return A list with:
#'   - Z_cf_cube: simulated VAR paths (n_vars x T_cf x valid_draws)
#'   - valid_draws: index vector of draws where imposed paths were respected
#' @export
pure_counterfactual <- function(data_, p, Btilde_list, M_full_list, intercept_list, shocks,
                                target_vars, shock_vars, T0, T1, imposed_path) {
  data_ <- t(data_)
  n_vars <- nrow(data_)
  n_draws <- length(Btilde_list)
  T0 <- as.character(T0)
  T1 <- as.character(T1)
  time_index <- colnames(data_)
  
  T0_idx <- which(time_index == T0)
  T1_idx <- which(time_index == T1)
  T_cf <- T1_idx - T0_idx + 1
  nK <- n_vars * p
  
  stopifnot(length(target_vars) == length(shock_vars))
  n_targets <- length(target_vars)
  
  if (is.null(dim(imposed_path))) {
    stopifnot(length(imposed_path) == T_cf)
    imposed_path <- array(imposed_path, dim = c(T_cf, 1, n_draws))
  } else if (length(dim(imposed_path)) == 2) {
    stopifnot(dim(imposed_path)[1] == T_cf)
    stopifnot(dim(imposed_path)[2] == n_targets)
    imposed_path <- array(rep(imposed_path, n_draws), dim = c(T_cf, n_targets, n_draws))
  }
  
  stopifnot(dim(imposed_path)[3] == n_draws)
  stopifnot(dim(shocks)[1] == n_vars)
  stopifnot(dim(shocks)[3] == n_draws)
  
  shock_index <- dimnames(shocks)[[2]]
  shock_T0_idx <- which(shock_index == T0)
  shock_T1_idx <- which(shock_index == T1)
  T_shock_cf <- shock_T1_idx - shock_T0_idx + 1
  
  X <- sapply((p + 1):ncol(data_), function(t) as.vector(data_[, (t - 1):(t - p)]))
  colnames(X) <- colnames(data_)[(p):(ncol(data_) - 1)]
  
  X_index <- colnames(X)
  X_T0_idx <- which(X_index == T0)
  
  shocks_cf <- shocks
  valid_draws <- logical(n_draws)
  
  for (d in seq_len(n_draws)) {
    Btilde <- Btilde_list[[d]]
    M_full <- M_full_list[[d]]
    intercept <- intercept_list[[d]]
    eps_cf <- shocks[,,d]
    
    for (t in 1:T_shock_cf) {
      t_idx <- shock_T0_idx + t - 1
      for (i in seq_along(target_vars)) {
        v <- target_vars[i]
        s <- shock_vars[i]
        
        # Compute Z0
        Z0 <- X[, X_T0_idx - 1]
        
        # Compute Btilde^0 to Btilde^{t-1}
        B_pows <- lapply(0:(t - 1), function(j) matrix_power(Btilde, j))
        
        # Total contribution from other shocks and intercepts
        Z_contrib <- rep(0, nK)
        for (j in 1:t) {
          lag_idx <- t_idx - (j - 1)
          eps_j <- eps_cf[, lag_idx]
          eps_j[s] <- 0
          Z_contrib <- Z_contrib + B_pows[[j]] %*% (M_full %*% eps_j + intercept)
        }
        
        # Contribution from past values of the same shock
        past_contrib <- rep(0, nK)
        if (t > 1) {
          for (j in 1:(t - 1)) {
            lag_idx <- t_idx - j
            eps_past <- rep(0, n_vars)
            eps_past[s] <- eps_cf[s, lag_idx]
            past_contrib <- past_contrib + B_pows[[j + 1]] %*% M_full %*% eps_past
          }
        }
        
        Z_pred <- matrix_power(Btilde, t) %*% Z0 + Z_contrib
        residual <- imposed_path[t, i, d] - Z_pred[v] - past_contrib[v]
        
        if (abs(M_full[v, s]) < 1e-8) {
          eps_cf[s, t_idx] <- NA_real_
        } else {
          eps_cf[s, t_idx] <- residual / M_full[v, s]
        }
      }
    }
    
    Z_check <- generate_Z_from_shocks_Z0(X, Btilde_list[d], M_full_list[d], intercept_list[d],
                                         array(eps_cf, dim = c(dim(eps_cf), 1)), T0 = X_T0_idx - 1)
    
    ok <- TRUE
    for (i in seq_along(target_vars)) {
      v <- target_vars[i]
      diff <- abs(Z_check[v, , 1] - imposed_path[, i, d])
      if (any(is.na(diff)) || any(diff > 1e-8)) {
        ok <- FALSE
        break
      }
    }
    
    valid_draws[d] <- ok
    shocks_cf[, , d] <- eps_cf
  }
  
  Z_cf_cube_all <- generate_Z_from_shocks_Z0(X, Btilde_list, M_full_list, intercept_list,
                                             shocks_cf, X_T0_idx - 1)
  
  return(list(
    Z_cf_cube = Z_cf_cube_all[1:n_vars, , valid_draws, drop = FALSE],
    valid_draws = which(valid_draws)
  ))
}


plot_counterf<-function(Y_counterf,var2plot_s,varnames,true_data,seq_cont,bands=TRUE){
  var2plot<-which(varnames==var2plot_s)
  
  yc_m<-apply(Y_counterf[var2plot,,],MARGIN=1,FUN=function(x)median(x))
  yc_l<-apply(Y_counterf[var2plot,,],MARGIN=1,FUN=function(x)quantile(x,.16))
  yc_u<-apply(Y_counterf[var2plot,,],MARGIN=1,FUN=function(x)quantile(x,.84))
  
  Y_c<-data.frame(year=seq_cont,center=yc_m,upper=yc_u,lower=yc_l)
  
  
  all_count<-full_join(true_data,Y_c,by='year')
  # plot counterfactual
  p<-ggplot(data=all_count,aes(x=year))+geom_line(aes(y=!!sym(var2plot_s)))+
    geom_line(aes(y=center),linetype='dashed',linewidth=2,color='blue')+
    theme_minimal()+ylab('')+xlab('')
  if(bands){
    p<-p+geom_ribbon(aes(ymin=lower,ymax=upper),alpha=0.5,fill='pink')
  }
  return(p)
}


#' Function to get data from a scenario matrix
get_data_from_scenario<-function(scenario_=NULL,T0=NULL,T1=NULL,freq_='quarter'){
  # Step 1: Get rownames and split into variable and horizon
names_split <- do.call(rbind, strsplit(rownames(scenario_), split = "\\."))
colnames(names_split) <- c("variable", "hor")

# Step 2: Compute medians across draws
medians <- apply(scenario_, MARGIN = 1, FUN = median)

# Step 3: Combine variable info with medians
df_long <- data.frame(
  variable = names_split[, "variable"],
  hor = as.integer(names_split[, "hor"]),
  median = medians
)

# Step 4: Reshape to wide format: rows = horizons, columns = variables
library(tidyr)
df_wide <- pivot_wider(df_long, names_from = "variable", values_from = "median")

# Optional: Arrange by horizon
df_wide0 <- df_wide[order(df_wide$hor), ] 
df_wide<-df_wide0 %>% as.data.frame()
# Set rownames as horizon (optional)
df_wide[,'hor'] <- seq.Date(as.Date(T0), as.Date(T1), by = freq_)
rownames(df_wide) <- df_wide$hor%>%as.yearqtr()%>%as.numeric()

return(df_wide )
}

# FUNCTION TO GET QUANTILES FROM A NxTxdraws ARRAY
get_quantile_df <- function(Y_counterf) {
  stopifnot(length(dim(Y_counterf)) == 3)

  # Extract dimensions and names
  n_var <- dim(Y_counterf)[1]
  time_labels <- dimnames(Y_counterf)[[2]]
  var_names <- dimnames(Y_counterf)[[1]]

  # Compute quantiles across draws
  LB <- apply(Y_counterf, c(1, 2), function(x) quantile(x, 0.16))
  center <- apply(Y_counterf, c(1, 2), function(x) quantile(x, 0.50))
  UB <- apply(Y_counterf, c(1, 2), function(x) quantile(x, 0.84))

  # Build data frames
  make_df <- function(mat, name) {
    df <- as.data.frame(mat)
    colnames(df) <- time_labels
    df$variable <- var_names
    tidyr::pivot_longer(df, cols = -variable, names_to = "year", values_to = name)
  }

  df_LB <- make_df(LB, "LB")
  df_center <- make_df(center, "center")
  df_UB <- make_df(UB, "UB")

  # Join all three
  df_out <- df_LB %>%
    dplyr::left_join(df_center, by = c("variable", "year")) %>%
    dplyr::left_join(df_UB, by = c("variable", "year"))

  return(df_out)
}
#' conditional_on_shock_scenario
#'
#' Simulates a counterfactual scenario using restrictions on observables and optionally on shocks.
#' It computes the conditional distribution of shocks \eqn{\mu_\varepsilon, \Sigma_\varepsilon} as in Antol\'in-D\'iaz et al. (2021),
#' treating both imposed variable paths and restricted shock paths jointly in a unified system.
#'
#' @param data_         Data matrix (variables x time)
#' @param p             Number of lags
#' @param Btilde_list   List of VAR companion matrices per draw
#' @param M_full_list   List of structural impact matrices per draw
#' @param intercept_list List of intercept vectors per draw
#' @param shocks        Array of shocks (n_vars x T x n_draws), used only for dimensioning
#' @param target_vars   Indices of variables whose path is imposed
#' @param shock_vars    Indices of structural shocks that are restricted (NA if unrestricted)
#' @param T0            Start date of the counterfactual
#' @param T1            End date of the counterfactual
#' @param imposed_path  Array of dimension (T_cf x n_targets) or (T_cf x n_targets x n_draws)
#'
#' @return A list with:
#'   - Z_cf_cube: counterfactual paths [n_vars x T_cf x valid_draws]
#'   - valid_draws: indices of draws where the match was numerically successful
#'   - mu_eps_list: list of conditional means of shocks \eqn{\mu_\varepsilon} (per draw)
#'   - Sigma_eps_list: list of conditional covariances \eqn{\Sigma_\varepsilon} (per draw)
#'
conditional_on_shock_scenario <- function(data_, p, Btilde_list, M_full_list, intercept_list, shocks,
                                          target_vars, shock_vars, T0, T1, imposed_path) {
  library(MASS)  # for ginv

  data_ <- t(data_)
  n_vars <- nrow(data_)
  n_draws <- length(Btilde_list)
  T0 <- as.character(T0)
  T1 <- as.character(T1)
  time_index <- colnames(data_)

  T0_idx <- which(time_index == T0)
  T1_idx <- which(time_index == T1)
  T_cf <- T1_idx - T0_idx + 1
  nK <- n_vars * p
  nh <- n_vars * T_cf

  stopifnot(length(target_vars) == length(shock_vars))
  n_targets <- length(target_vars)

  if (is.null(dim(imposed_path))) {
    imposed_path <- array(imposed_path, dim = c(T_cf, 1, n_draws))
  } else if (length(dim(imposed_path)) == 2) {
    imposed_path <- array(rep(imposed_path, n_draws), dim = c(T_cf, n_targets, n_draws))
  }

  shock_index <- dimnames(shocks)[[2]]
  shock_T0_idx <- which(shock_index == T0)
  T <- dim(shocks)[2]

  X <- sapply((p + 1):ncol(data_), function(t) as.vector(data_[, (t - 1):(t - p)]))
  colnames(X) <- colnames(data_)[(p):(ncol(data_) - 1)]
  X_T0_idx <- which(colnames(X) == T0)

  shocks_cf <- array(NA_real_, dim = dim(shocks))
  valid_draws <- logical(n_draws)
  mu_eps_list <- vector("list", n_draws)
  Sigma_eps_list <- vector("list", n_draws)

  for (d in seq_len(n_draws)) {
    Btilde <- Btilde_list[[d]]
    M_full <- M_full_list[[d]]
    intercept <- intercept_list[[d]]
    eps_cf <- matrix(rnorm(n_vars * T), nrow = n_vars)

    for (t in 1:T_cf) {
      t_idx <- shock_T0_idx + t - 1
      for (i in seq_along(target_vars)) {
        v <- target_vars[i]
        s <- shock_vars[i]
        Z0 <- X[, X_T0_idx - 1]
        B_pows <- lapply(0:(t - 1), function(j) matrix_power(Btilde, j))
        Z_contrib <- rep(0, nK)
        for (j in 1:t) {
          lag_idx <- t_idx - (j - 1)
          eps_j <- eps_cf[, lag_idx]
          eps_j[s] <- 0
          Z_contrib <- Z_contrib + B_pows[[j]] %*% (M_full %*% eps_j + intercept)
        }
        past_contrib <- rep(0, nK)
        if (t > 1) {
          for (j in 1:(t - 1)) {
            lag_idx <- t_idx - j
            eps_past <- rep(0, n_vars)
            eps_past[s] <- eps_cf[s, lag_idx]
            past_contrib <- past_contrib + B_pows[[j + 1]] %*% M_full %*% eps_past
          }
        }
        Z_pred <- matrix_power(Btilde, t) %*% Z0 + Z_contrib
        residual <- imposed_path[t, i, d] - Z_pred[v] - past_contrib[v]
        if (abs(M_full[v, s]) < 1e-8) {
          eps_cf[s, t_idx] <- NA_real_
        } else {
          eps_cf[s, t_idx] <- residual / M_full[v, s]
        }
      }
    }

    # Build C_h: observable restrictions
    k0 <- n_targets * T_cf
    C_h <- matrix(0, nrow = k0, ncol = nh)
    for (i in seq_along(target_vars)) {
      for (t in 1:T_cf) {
        row <- (i - 1) * T_cf + t
        col <- (target_vars[i] - 1) * T_cf + t
        C_h[row, col] <- 1
      }
    }

    # Build C_l: optional shock restrictions
    has_shocks <- all(!is.na(shock_vars))
    ks <- if (has_shocks) length(shock_vars) * T_cf else 0
    Xi <- matrix(0, nrow = ks, ncol = nh)
    if (has_shocks) {
      for (j in seq_along(shock_vars)) {
        for (t in 1:T_cf) {
          row <- (j - 1) * T_cf + t
          col <- (shock_vars[j] - 1) * T_cf + t
          Xi[row, col] <- 1
        }
      }
    }

    # C_hat and f
    C_hat <- if (has_shocks) rbind(C_h, Xi %*% ginv(t(M_full))) else C_h
    f <- matrix(0, nrow = k0 + ks, ncol = 1)
    f[1:k0, 1] <- as.vector(imposed_path[1:T_cf, , d])
    if (has_shocks) {
      b <- X[, X_T0_idx - 1]
      for (i in 1:(T_cf - 1)) {
        b <- Btilde %*% b + intercept
      }
      f[(k0 + 1):(k0 + ks), 1] <- (Xi %*% ginv(t(M_full))) %*% b
    }

    # Compute conditional moments
    D <- C_hat %*% t(M_full)
    D_star <- ginv(D)
    b_vec <- as.vector(C_hat %*% as.vector(generate_Z_from_shocks_Z0(X, list(Btilde), list(M_full), list(intercept),
                                                                     array(eps_cf, dim = c(n_vars, T, 1)), T0 = X_T0_idx - 1)[, , 1]))
    mu_eps <- D_star %*% (f - b_vec)
    Sigma_eps <- D_star %*% t(D_star) + (diag(ncol(D_star)) - D_star %*% D)

    mu_eps_list[[d]] <- mu_eps
    Sigma_eps_list[[d]] <- Sigma_eps

    Z_check <- generate_Z_from_shocks_Z0(X, Btilde_list[d], M_full_list[d], intercept_list[d],
                                         array(eps_cf, dim = c(dim(eps_cf), 1)), T0 = X_T0_idx - 1)

    ok <- TRUE
    for (i in seq_along(target_vars)) {
      v <- target_vars[i]
      diff <- abs(Z_check[v, , 1] - imposed_path[, i, d])
      if (any(is.na(diff)) || any(diff > 1e-8)) {
        ok <- FALSE
        break
      }
    }

    valid_draws[d] <- ok
    shocks_cf[, , d] <- eps_cf
  }

  Z_cf_cube_all <- generate_Z_from_shocks_Z0(X, Btilde_list, M_full_list, intercept_list,
                                             shocks_cf, X_T0_idx - 1)

  return(list(
    Z_cf_cube = Z_cf_cube_all[1:n_vars, , valid_draws, drop = FALSE],
    valid_draws = which(valid_draws),
    mu_eps_list = mu_eps_list,
    Sigma_eps_list = Sigma_eps_list
  ))
}

#' Compute Value-at-Risk from conditional forecast draws
#'
#' @param forecast_matrix Matrix of simulated forecasts (rows = variables with horizon suffix, cols = draws)
#' @param variables Character vector of variable names (e.g. "LRGDP", "pi_3m")
#' @param horizon Integer horizon to extract (e.g. 4 for ".4")
#' @param data_frame Data frame or tibble with actual observed time series (same var names as in `variables`)
#' @param level Quantile level for the VaR (default 0.10)
#' @param scale Logical vector same length as `variables`: multiply result by 100 if TRUE (for logs or %)
#'
#' @return Named numeric vector of VaRs, one per variable
compute_VaR <- function(forecast_matrix, variables, horizon, data_frame, level = 0.10, scale = rep(TRUE, length(variables))) {
  stopifnot(length(variables) == length(scale))
  
  var_names_h <- paste0(variables, ".", horizon)
  var_values <- numeric(length(variables))
  
  for (i in seq_along(variables)) {
    q_forecast <- quantile(forecast_matrix[var_names_h[i], ], probs = level, na.rm = TRUE)
    last_obs <- tail(data_frame[[variables[i]]], 1)
    var_values[i] <- (q_forecast - last_obs) * if (scale[i]) 100 else 1
  }
  
  names(var_values) <- paste0("VaR_", variables)
  return(var_values)
}

# combined two plots of scenarios
plot_comby<-function(plot1,plot2,islog=TRUE,T.previous=NULL,T.end=NULL,T.start=NULL){

  p_cf_STR2.data<-ggplot_build(plot1)$data
  
  date_seq_STR2<-seq.Date(from=as.Date(T.start),by='quarter',length.out = 10)
  
  tmp1<-p_cf_STR2.data[[1]]
  tmp1$x<-as.Date(tmp1$x)
  
  
  tmp2<-p_cf_STR2.data[[2]]
  tmp2$x<-as.Date(tmp2$x)
  tmp2_last<-tmp2[tmp2$x==T.previous,'y']
  
  tmp3<-p_cf_STR2.data[[3]]
  tmp3$x<-as.Date(tmp3$x)
  if(islog){
  tmp1$y<-(tmp1$y-tmp2_last)*100
  tmp2$y<-(tmp2$y-tmp2_last)*100
  tmp3$ymin<-(tmp3$ymin-tmp2_last)*100
  tmp3$ymax<-(tmp3$ymax-tmp2_last)*100
  }else{
    tmp1$y<-(tmp1$y/tmp2_last-1)*100
    tmp2$y<-(tmp2$y/tmp2_last-1)*100
    tmp3$ymin<-(tmp3$ymin/tmp2_last-1)*100
    tmp3$ymax<-(tmp3$ymax/tmp2_last-1)*100
  }
  
  #############
  p_cf_STR.data<-ggplot_build(plot2)$data
  
  date_seq_STR<-seq.Date(from=as.Date(T.start),by='quarter',length.out = 10)
  
  pmt1<-p_cf_STR.data[[1]]
  pmt1$x<-as.Date(pmt1$x)
  
  pmt2<-p_cf_STR.data[[2]]
  pmt2$x<-as.Date(pmt2$x)
  pmt2_last<-pmt2[pmt2$x==T.previous,'y']
  
  pmt3<-p_cf_STR.data[[3]]
  pmt3$x<-as.Date(pmt3$x)
  
  
  if(islog){
    pmt1$y<-(pmt1$y-pmt2_last)*100
    pmt2$y<-(pmt2$y-pmt2_last)*100
    pmt3$ymin<-(pmt3$ymin-pmt2_last)*100
    pmt3$ymax<-(pmt3$ymax-pmt2_last)*100
  }else{
    pmt1$y<-(pmt1$y/pmt2_last-1)*100
    pmt2$y<-(pmt2$y/pmt2_last-1)*100
    pmt3$ymin<-(pmt3$ymin/pmt2_last-1)*100
    pmt3$ymax<-(pmt3$ymax/pmt2_last-1)*100
  }
  
  ########
  
  
  
  p_cf_comby<-ggplot()+
    geom_point(data=tmp1,aes(x=x,y=y,color='first'),
               alpha=1,size=3)+
    geom_ribbon(data=tmp3,aes(x=x,ymin=ymin,ymax=ymax),fill=light_green,alpha=.1)+
    geom_point(data=pmt1,aes(x=x,y=y,color='second'),shape=22,
               alpha=1,size=3)+
    geom_ribbon(data=pmt3,aes(x=x,ymin=ymin,ymax=ymax),fill='pink',alpha=.5)+
    geom_line(data=tmp2,aes(x=x,y=y,color='data'),linewidth=1.5)+
    geom_vline(xintercept=0)+
    scale_color_manual('',values=c('first'=dark_green,'second'='black','data'='blue'),
                       labels=c('first'='counterfactual','second'='baseline','data'='data'))+
    geom_vline(xintercept=-1,linetype='dashed')+xlab('')+ylab(subvar[varbl2plot])+
    coord_cartesian(xlim=as.Date(c(zero_x,T.end)))  +
    theme_uniform_text_size(size=15)+ylab('')+xlab('')+
    theme_minimal()+theme(legend.position = 'bottom')+
    theme(text=element_text(size=18,family = 'mono'))
  
  print(p_cf_comby)
  return(p_cf_comby)
}


dens_var<-function(variable=NULL,threshold=0.1){
  # Compute probability
  prob_threshold<-quantile(variable,p=threshold)
   
  dens <- density(variable)
  dens_df <- data.frame(x = dens$x, y = dens$y)
  dens_df$fillo <- ifelse(dens_df$x <= prob_threshold, "red", "lightgreen")
  
  
  
  # Base histogram
  p <- ggplot(data.frame(value = variable), aes(x = value)) +
    geom_histogram(aes(y = after_stat(density)), bins = 50, 
                   fill = "white", color = "black", alpha = 0.5) +
    
    # Filled areas under the curve, using same y-scale
    geom_area(data = dens_df[dens_df$x<= prob_threshold,],
              aes(x = x, y = y, fill = fillo), alpha = 0.4) +
    geom_area(data = dens_df[dens_df$x> prob_threshold,],
              aes(x = x, y = y, fill = fillo), alpha = 0.4) +
    scale_fill_manual('',values = c("red"="red","lightgreen"="lightgreen"))+
    theme(legend.position = 'none')+
    # Outline full density
    geom_line(data = dens_df, aes(x = x, y = y), color = "darkgreen", size = 1) +
    
    # Vertical line and annotation
    # geom_vline(xintercept = threshold, linetype = 'dotted', 
    #            color = 'blue', linewidth = 1.5) +
    annotate(geom = 'text', 
             x =prob_threshold+0.01, y = -0.01, 
             label = latex2exp::TeX(paste0("$P(X<",sprintf("%.3f",prob_threshold*100),"\\%)=",threshold*100 ,"\\%")),
             color = 'red', hjust = 0.5, vjust = 1, size = 5) +
    
    # Labels and theme
    labs(title = "", x = latex2exp::TeX(paste0(' $',subvar[varbl2plot],'_{t+h} - ',subvar[varbl2plot],'_{t}$')), y = "") +
    theme_uniform_text_size(size = 18)
  return(p)
}


probabilities_contraction <- function(forecast_matrix = y_h_cf_STR, y_data = NULL) {
  var_h <- rownames(forecast_matrix)
  varnames <- sub("\\.\\d+$", "", var_h)
  horizons <- as.integer(sub("^.*\\.", "", var_h))
  
  unique_vars <- unique(varnames)
  h <- max(horizons)
  
  # Get reference values safely
  ref_row <- which(y_data$hor == T.previous)
  ref_vals <- lapply(unique_vars, function(v) y_data[ref_row, v, drop = TRUE])
  names(ref_vals) <- unique_vars
  
  prob_below <- matrix(NA_real_, nrow = length(unique_vars), ncol = h,
                       dimnames = list(unique_vars, paste0("h+", 1:h)))
  
  for (v in unique_vars) {
    for (t in 1:h) {
      idx <- paste0(v, ".", t)
      draws <- forecast_matrix[idx, ]
      prob_below[v, t] <- mean(draws < ref_vals[[v]]) * 100
    }
  }
  return(prob_below)
}


trim_rows <- function(y, lower = 0.01, upper = 0.99) {
  tmp <- function(x) {
    qnt <- quantile(x, probs = c(lower, upper), na.rm = TRUE)
    x[x < qnt[1] | x > qnt[2]] <- NA
    return(x)
  }
  y_trimmed <- t(apply(y, 1, tmp))
  return(y_trimmed)
}

flatten3D<-function(y){
  h<-dim(y)[2]
  n_var<-dim(y)[1]
  out<- do.call(abind::abind, c(lapply(1:h, function(t) y[, t, , drop = T]), along = 1))
return(out)
}


