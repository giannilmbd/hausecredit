
## ----BVAR FORECASTS -----------------------------------------------------------------------------

f_bvar<-bsvars::forecast(
  posterior,
  horizon = 3,
  exogenous_forecast = NULL,
  conditional_forecast = NULL
)
{# run all block 
  T.start='2025-01-01'
  T.end=as.Date(T.start)%m+%months(9)
  T.past=as.Date(T.start)%m-%months(15)
  T.all<-seq.Date(from=as.Date(T.past),to=T.end,by='quarter')
  h=4
  y_h_all<-forc_h(h,n_sim=200,data_=Z,posterior=posterior,matrices=matrices)
  y_h<-y_h_all[[1]]
  hist_h<-y_h_all[[3]]
  b_h<-y_h_all[[4]]
  {# extract quantiles
    y_h_m<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.5))
    y_h_l<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.16))
    y_h_u<-apply(y_h,c(1,2),FUN=function(x)quantile(x,0.84))
    
    
    hist_h_l<-apply(hist_h,c(1,2),FUN=function(x)quantile(x,0.16))
    hist_h_u<-apply(hist_h,c(1,2),FUN=function(x)quantile(x,0.84))
    
  }
  # convert to data frame for better manipulation
  {
    y_h_m<-as.data.frame(t(y_h_m))
    y_h_u<-as.data.frame(t(y_h_u))
    y_h_l<-as.data.frame(t(y_h_l))
    
    hist_h_u<-as.data.frame(t(hist_h_u))
    hist_h_l<-as.data.frame(t(hist_h_l))
    
    
    names(y_h_m)<-subvar
    y_h_m$hor<-1:nrow(y_h_m)
    y_h_tot<-pivot_longer(y_h_m,cols=all_of(subvar),names_to='variable',values_to='Median')
    names(y_h_l)<-subvar
    y_h_l$hor<-1:nrow(y_h_l)
    y_h_tot<-left_join(y_h_tot,
                       pivot_longer(y_h_l,cols=all_of(subvar),names_to='variable',values_to='LB'),
                       by=c('hor','variable'))
    
    names(y_h_u)<-subvar
    y_h_u$hor<-1:nrow(y_h_u)
    y_h_tot<-left_join(y_h_tot,
                       pivot_longer(y_h_u,cols=all_of(subvar),names_to='variable',values_to='UB'),
                       by=c('hor','variable'))
    
    names(hist_h_l)<-subvar
    hist_h_l$hor<-1:nrow(hist_h_l)
    hist_h_tot<- pivot_longer(hist_h_l,cols=all_of(subvar),names_to='variable',values_to='LB_s')
    
    names(hist_h_u)<-subvar
    hist_h_u$hor<-1:nrow(hist_h_u)
    hist_h_tot<-left_join(hist_h_tot,
                          pivot_longer(hist_h_u,cols=all_of(subvar),names_to='variable',values_to='UB_s'),
                          by=c('hor','variable'))
    
    
    y_h_tot<-left_join(y_h_tot,hist_h_tot,by=c('hor','variable'))
    
  }
  # inspect result
  dt_t<-as.data.frame(t(Y))
  dt_t$hor=1:nrow(dt_t)
  y_data<-pivot_longer(dt_t,cols =all_of(1:n_var),values_to =names(y_h_tot)[3],names_to = "variable" )
  y_data<-y_data[y_data$hor>=last(y_data$hor)-4,]  
  
  y_data$hor<-y_data$hor-max(y_data$hor)
  y_data$LB<-NA
  y_data$UB<-NA
  y_data$LB_s<-NA
  y_data$UB_s<-NA
  
  y_h_tot<-rbind(y_data,y_h_tot)
  y_h_tot<-y_h_tot[order(y_h_tot$hor),]
  head(y_h_tot)
  
  uncond.forc<-y_h_tot
  # plot 
  # which variable to plot 
  varbl2plot=which(subvar%in%c("LRHP"));
  data2plot<-uncond.forc[uncond.forc$variable == subvar[varbl2plot], ]%>% as.data.frame()
  data2plot1<-data2plot %>% mutate(Median=ifelse(hor>0,NA,Median)) %>% as.data.frame()
  data2plot2<-data2plot %>% mutate(Median=ifelse(hor<=0,NA,Median))%>% as.data.frame()
  
  # >>>>> UNCONDITIONAL FORECAST PLOT ------------  
  p <- ggplot(data=data2plot1,aes(x = hor)) +
    # Median line (solid line)
    geom_line(aes(y = Median, color = "med", group = variable), linewidth = 1, show.legend = F)+
    theme(text=element_text(size=18,family = 'mono')) +theme_uniform_text_size(size=18)+
    geom_line(data=data2plot2,aes(y = Median, color = "med", group = variable), linewidth = 1, show.legend = TRUE) +
    
    # Shaded area for 68% HDI
    geom_ribbon(aes(ymin = LB, ymax = UB, group = variable), fill = "pink", 
                alpha = 0.5, show.legend = F) +
    
    # Dashed lines for 68% high credibility band of history
    geom_line(aes(y = LB_s, color = "hist"), 
              linetype = "dashed", linewidth = 0.8, show.legend = F) +
    geom_line(aes(y = UB_s, color = "hist"), 
              linetype = "dashed", linewidth = 0.8, show.legend = FALSE) +
    
    # Labels and theme
    # labs(title = "Unconditional Forecast", x = "h", y = subvar[varbl2plot]) +
    theme_minimal() +
    
    # Custom legend for colors
    scale_color_manual(
      name = "",
      labels=c('med'="Median",'hist'="no shock uncertainty."),
      values = c("med" = "blue",  'hist'= "red")
    ) +
    # labs(caption="HPD = 1 stdev (68%)")+
    ylab("")+
    theme(plot.caption.position = 'panel',plot.caption = element_text(hjust=0),
          legend.position = 'bottom',axis.text.x=element_text(angle=45))+
    scale_x_continuous(
      breaks = seq(-4, 4, by = 1),
      labels = format(T.all, "%Y-%m") # e.g., "Jan 2024"
    )+xlab('')+ylab('')+theme_uniform_text_size(size=18)+ylim(c(0.94,1.1))
  p
} # end run all block
graphics.off()
print(p)
pbuilt<-ggplot_build(p)
y_limits <- pbuilt$layout$panel_params[[1]]$y.range

ggsave('uncond_forc.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')

