varbls <- c("STR3m",
            "LRHP",
            "pi_3m",
            "LRGDP",
            'LNEER',
            'spread',
            'LRMORT',
            'LRM3',
            'vix',
            'LGDP_ROW',
            'US_10y',
            'STR')#,"NM2"

varbls%in%names(df)

# SUBSET AND DIMS -------------
subset_<-c(1:6,7) # start with subsets of variables
subvar<-varbls[subset_] 
mxv<-length(subset_)

# NB: a vector in R is constructed with c(values separated by commas)
# Elements of an array are selected using eg X[1:10, c(1:10)] or X[c(1:10),list of header names] etc

X0<-na.exclude(df[df$year<='2024-10-01', c('year',varbls)] )
dates<-as.numeric(as.yearqtr(X0$year))
date_seq<-as.yearqtr(dates) %>% as.Date()
#>>>> plot data --------
data_series<-X0[,varbls]
p<-autoplot(data_series %>% ts(.,frequency=4,start=1981),facets=T)+ylab("")+xlab("")

ggsave('data.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')
p
# ############# Subset of variables
# 1. Baseline VAR --------
# Start from small VAR (mxv=number of variables: change the order in varbls if needed)



n_var=length(varbls)

data_matrix<-as.matrix(data_series,n_var,n_var) 
rownames(data_matrix)<-dates
# sr <- matrix(NA, nrow = length(varbls), ncol = length(varbls))

# Fill the matrix with sign restrictions as per the previous setup
# SET SIGN RESTRICTIONS --------------------------

# diagonal NA/1
sr<-array(NA,dim=c(n_var,n_var))
for(cnt in 1:n_var){
  sr[cnt,cnt]<-1
}
rownames(sr)<-varbls
colnames(sr)<-varbls
varb<-"STR3m"
# "STR3m"         "LRHP"        "pi_"         "LRGDP"       "LREER"       "I_MORTG"   "LRMORT"  "LGDP_ROW"     "US_10y" 
sr[2,varb]<- NA # LRHP 
sr[3,varb]<- -1 # CPI

sr[4,varb]<- -1 # GDP
sr[5,varb]<- 1 # ,'LREER'
sr[6,varb]<- -1 # 'spread'
sr[7,varb]<- -1 #'LNMORT'
# sr[8,varb]<- 0 #'vix'
# sr[9,varb]<- 0 # LGDP_ROW
# sr[10,varb]<-0 # US_10y

varb<-"pi_3m"
# ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
sr[3,varb]<- 1 # CPI
sr[4,varb]<- -1 # GDP
sr[5,varb]<- NA # ,'LREER'
sr[6,varb]<- 1 # 'I_MORTG'
sr[7,varb]<- NA #'LNMORT'
# sr[8,varb]<- 0 #'vix'
# sr[9,varb]<- 0 # LGDP_ROW
# sr[10,varb]<-0 # US_10y

varb<-"LRGDP"
# ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
sr[1,varb]<- NA # STR3m 
sr[3,varb]<- 1 # CPI
sr[4,varb]<- 1 # GDP
sr[5,varb]<- NA # ,'LREER'
sr[6,varb]<- 1 # 'I_MORTG'
sr[7,varb]<- 1 #'LNMORT'
# sr[8,varb]<- 0 #'vix'
# sr[9,varb]<- 0 # LGDP_ROW
# sr[10,varb]<-0 # US_10y

varb<-"LNEER" #credit supply shock
# ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
sr[1,varb]<- NA # STR3m 
# sr[2,varb]<- -1 # LNHP 
sr[3,varb]<- -1 # CPI
sr[4,varb]<- NA # GDP

sr[5,varb]<- 1 # ,'LREER'
sr[6,varb]<- NA # 'I_MORTG'
sr[7,varb]<- NA #'LNMORT'
# sr[8,varb]<- 0 # LGDP_ROW
# sr[9,varb]<- 0 # US_10y


varb<-"spread" #credit supply shock
# ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
# sr[1,varb]<- 1 # STR3m 
sr[3,varb]<- NA # CPI
sr[4,varb]<- NA # GDP
sr[2,varb]<- -1 # LNHP 
sr[5,varb]<- NA # ,'LNEER'
sr[6,varb]<- 1 # 'spread'
sr[7,varb]<- -1 #'LNMORT'
# sr[8,varb]<- 0 # LGDP_ROW
# sr[9,varb]<- 0 # US_10y



varb<-"LRMORT" # credit demand shock
# ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
# sr[1,varb]<- 1 # STR3m 
# sr[3,varb]<- -1 # CPI
# sr[4,varb]<- -1 # GDP
sr[2,varb]<- 1 # LNHP 
sr[5,varb]<- NA # ,'LREER'
sr[6,varb]<- 1 # 'I_MORTG'
sr[7,varb]<- 1 #'LRMORT'
# sr[8,varb]<- 0 # LGDP_ROW
# sr[9,varb]<- 0 # US_10y

varb<-'LRM3'
sr[varb,varb]<-1
# sr[3,varb,4]<- 1 # delayed response of inflation


if(T==F){
  
  
  varb<-"US_10y"
  # ("STR3m","LNHP","pi_","LNGDP",'LREER','I_MORTG','LNMORT','LGDP_ROW','US_10y'
  sr[1,varb]<- 1 # STR3m 
  sr[3,varb]<- -1 # CPI
  sr[4,varb]<- -1 # GDP
  sr[5,varb]<- -1 # ,'LREER'
  sr[6,varb]<- NA # 'I_MORTG'
  sr[7,varb]<- NA #'LNMORT'
  sr[8,varb]<- -1 # LGDP_ROW
  sr[9,varb]<-1 # US_10y
  
  
}
sr_<-sr
rownames(sr_)<-varbls
colnames(sr_)<-varbls
knitr::kable(sr_,format = 'pipe',row.names = T,col.names = colnames(sr_))
# sr<-sr[subset_,subset_] %>% array(,dim=c(n_var,n_var,2))
# sr[, ,2]<-sr2



sr1<-sr[subset_,subset_]
# contemporaneous structural restriction


sr_c<-sr1
sr_c[1:length(subset_),1:length(subset_)]<-NA

for(cnt in 1:length(subset_)){
  sr_c[cnt,cnt]<-1 # 
}

### NARRATIVE ------------------
# exchange rate shock

# narrative_MP=list();
# num_nar=length(narrative_gen[narrative_gen<=last(X0$year)])
# 
# for (cnt in 1:num_nar){
# narrative_MP[[cnt]]<-bsvarSIGNs::specify_narrative(start =which(dates==as.numeric(as.yearqtr(narrative_gen[cnt]))),
#                                           periods = 1,
#                                           type = 'S',
#                                           shock = 1,
#                                           sign = sign(rate_resp$yhat[rate_resp$narr][cnt]),
#                                           var=1)
# }

# narrative1.a<-bsvarSIGNs::specify_narrative(start =which(dates==2010.500),
#                                           periods = 1,
#                                           type = 'S',
#                                           shock = 6,
#                                           sign = 1,
#                                           var = 6)
# 
# narrative1.b<-bsvarSIGNs::specify_narrative(start =which(dates==2010.500),
#                                           periods = 1,
#                                           type = 'B',
#                                           shock = 6,
#                                           sign = 1,
#                                           var = 6)


narrative1.c<-bsvarSIGNs::specify_narrative(start =which(dates==2015.0),
                                            periods = 1,
                                            type = 'S',
                                            shock = 5,
                                            sign = 1,
                                            var = 5)
# MP shock
# narrative2.a<-bsvarSIGNs::specify_narrative(start =which(dates==2022.0),
#                                           periods = 1,
#                                           type = 'S',
#                                           shock = 1,
#                                           sign = 1,
#                                           var = 1)
# 
# narrative2.b<-bsvarSIGNs::specify_narrative(start =which(dates==2024.0),
#                                           periods = 1,
#                                           type = 'S',
#                                           shock =1,
#                                           sign = 1,
#                                           var = 1)



narratives<-list(narrative1.c)
# narratives<-c(narratives,narrative_MP)
# narratives<-c(narratives,narrative_MP)


# SAVE SIGN RESTRICTIONS -------------

sr_to_print<-sr[subset_,subset_] %>% as.data.frame()

rownames(sr_to_print)<-subvar 
names(sr_to_print)<-subvar 
# sr2<-kable(sr_to_print,row.names = T,format = 'latex',booktabs=T)
# 
# sr2 %>% cat(file='figures/sr_bvars.tex')

sr1_html <-kable(sr_to_print, row.names = TRUE,
                 col.names = c('policy','HP','supply','demand','FX','credit supply','credit demand','money supply')
                 ,format = 'latex',booktabs=T) 
# Save the HTML table to a file
cat(as.character(sr1_html), file = "figures/sr_bvars.tex")

