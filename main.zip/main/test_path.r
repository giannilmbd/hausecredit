#test path

# Step 1: Simulate a known structural shock path
n_shocks=n_var
shock_index=1
shocks_test <- matrix(0, nrow = n_shocks, ncol = h) # h = horizon
shocks_test[shock_index, ] <- c(1, 2, -1, 5) # known path for one shock
BM<- build_companion_matrices(
  A_array = posterior$posterior$A,
  B_array = posterior$posterior$B,
  p = lags,
  thinning = 1
)
# Step 2: Generate the scenario data Y from shocks
sks<-shocks_array <- array(rep(shocks_test, times = n_draws),
                           dim = c(nrow(shocks_test), ncol(shocks_test), n_draws))

dta<-matrix(0,nrow=specification$p*2,ncol=n_var)

Z_sim <- generate_Z_from_shocks(
  data_ =dta,
  p = lags,
  Btilde_list = list(BM$Btilde[[1]]),
  M_full_list = list(BM$M_full[[1]]),
  intercept_list = list(BM$intercept[[1]]*0),
  shocks = sks[,,1,drop=F]  # repeated for each draw
)



# Extract the observable path from Z_sim
Y_scenario <- Z_sim[1:n_var, ,1,drop=F]  # assuming Z = [Y; X]
M_impact<-BM$M_full[[1]]
print('discrepancy of simulated vs shocks')
M_impact[1:n_var,]%*%sks[,1,1]-Y_scenario[,1,1] # should be close to the shock path``
# Step 3: Run full_scenarios_core
# - obs: which variables were affected (only the one corresponding to shock_index)
# - path: Y_scenario as a vector
# - shocks: 1:n_shocks (allow all to adjust)
tmp <- big_b_and_M(h, n_draws, n_var, n_p, data_ = Z*0)
big_b <- tmp[[1]]
big_M <- tmp[[2]]
big_b_sub <- array(big_b[,,1]*0, dim = c(nrow(big_b), ncol(big_b), 1))
big_M_sub <- array(big_M[,,1], dim = c(nrow(big_M), ncol(big_M), 1))
obs<-1:7

res <-
  full_scenarios_core(big_b_sub, big_M_sub,
                      as.integer(obs),
                      as.numeric((Y_scenario[,,1])),
                      NA_integer_,
                      h = h,
                      n_var = n_var,
                      g_ = NULL,
                      Sigma_g_ = NULL)


res[["mu_y"]]
# Step 4: Compare
mu_eps_est <- res$mu_eps[[1]]  # choose draw that matches the B/M used
true_eps <- as.vector(shocks_test)

# Plot / check error
plot(mu_eps_est, type = "l", col = "blue")
lines(true_eps, col = "red", lty = 2)
max(abs(mu_eps_est - true_eps))
