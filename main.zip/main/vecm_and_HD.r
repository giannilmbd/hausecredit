# Model in VECM form  -------------
# NB: This part (VECM) is just for checking if something useful comes out
# Theory does not recommend it: We have checked that errors are I(0) and they typically are
# as lags and other possibly cointegrated variables mop up the unit root.
# In small sample the tests below are weak and (as Uhlig and Sims point out can be misleading and useless in a Bayesian context)
# One advantage of this representation is that we are doing the HD in differences (growth rates of variables) and this could complement
# the HD in levels --- problematic with drifting variables. 
# Finally note that we work with the mean of the estimated distribution. This makes the tests and the HD less reliable.

# Convert a VAR(p) to a VECM
p <- lags  # VAR order
## Check VMA
if(F){#For debugging only: It takes very long
  BM<- build_companion_matrices(
    A_array = posterior$posterior$A,
    B_array = posterior$posterior$B,
    p = lags,
    thinning = 1
  )
  Z_sim_all <- generate_Z_from_shocks(
    data_ = data_matrix1,
    p = lags,
    Btilde_list = BM$Btilde,
    M_full_list = BM$M_full,
    intercept_list = BM$intercept,
    shocks = stsh
  )
  # THIS IS A PROPER COUNTERFACTUAL ------
  if(F){
    # counterfactural  ZLB ------------------------------
    
    T.start<-'2024-01-01' %>% as.Date()
    T.end<-as.yearqtr(as.Date(T.start)+months(11)) %>% as.Date()
    T.previous<-T.start%m-%months(3)
    true_data<-data_matrix1 %>% as.data.frame()
    true_data$year<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix1))),'%Y Q%q',frac=0)
    BM<- build_companion_matrices(
      A_array = posterior$posterior$A,
      B_array = posterior$posterior$B,
      p = lags,
      thinning = 1
    )
    
    target_var<-which('STR3m'%in%varbls[subset_])
    seq_cont<-seq.Date(from=T.start,to=T.end,by='quarter')
    path0<-true_data[true_data$year>=T.start&true_data$year<=T.end,'STR3m']
    # periods<-dates_date[dates_date>=T.start&dates_date<=T.end]
    path<-path0
    path[path<true_data[true_data$year==T.previous,'STR3m']&!is.na(path)]<-true_data[true_data$year==T.previous,'STR3m']
    path
    imposed_path=path # FOR DEBUGGING # true_data[true_data$year>=T.start&true_data$year<=T.end,'STR3m']
    dim(stsh)
    dim(Y)
    # check counterfactual data ---------
    X<-specification$get_data_matrices()$X
    X<-X[-nrow(X),]
    # imposed_path=true_data[true_data$year>=T.start&true_data$year<=T.end,'STR3m']
    # ser0<-generate_Z_from_shocks_Z0(X,stsh,T0 = which(dates_date==T.start),
    #                                 Btilde_list=BM$Btilde,
    #                              M_full_list=BM$M_full,
    #                              intercept_list=BM$intercept)
    # print('residual reconstruction')
    # print(max(ser0[1,,1]-t(Y[1,(which(dates_date==T.start)):(which(dates_date==T.end))])))
    # print(max(ser0[1,,1]-imposed_path))
    imposed_path=path
    data_matrix2<-data_matrix1
    rownames(data_matrix2)<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix2)))) %>% as.character()
    # rownames(data_matrix2)
    dimnames(stsh)[[2]]<-rownames(data_matrix2)[(lags+1):nrow(data_matrix2)]
    undebug(pure_counterfactual)
    Y_counterf<-pure_counterfactual(data_=data_matrix2, p=lags,
                                    Btilde_list=BM$Btilde,
                                    M_full_list=BM$M_full,
                                    intercept_list=BM$intercept,
                                    shocks=stsh,
                                    target_var=target_var,
                                    T0=T.start,
                                    shock_vars = target_var,
                                    T1=T.end,
                                    imposed_path=imposed_path)
    Y_counterf<-Y_counterf[[1]]
    dimnames(Y_counterf)[[1]]<-varbls[subset_]
    draw_count<-dim(Y_counterf)[3]
    tmp<-sapply(1:draw_count,FUN = function(x){
      chk<-Y_counterf[1,1:length(which(dates_date==T.start):which(dates_date==T.end)),x]  
      max(abs(chk-imposed_path))})
    plot(x=1:draw_count,y=tmp)
    
    
    
    
    
    p<-plot_counterf(Y_counterf = Y_counterf,var2plot = "STR3m",varnames = varbls[subset_],
                     true_data = true_data,seq_cont = seq_cont,bands=T)+theme_uniform_text_size(size=18)
    
    p
    
    p<-plot_counterf(Y_counterf = Y_counterf,var2plot = "LRHP",varnames = varbls[subset_],
                     true_data = true_data,seq_cont = seq_cont,bands=T)+theme_uniform_text_size(size=18)
    
    p<-p+coord_cartesian(xlim=as.Date(c('2014-01-01','2025-01-01')),ylim=c(0.5,1.1))+
      geom_vline(xintercept=as.Date(2015-01-01),color='red',linetype='dotted',linewidth=2)
    print(p)
    ggsave(filename = 'ZLB_counterf.pdf',plot=p,device='pdf',path='figures',units='cm',width = 16,height = 16)
  } # End debugging part
  
}


# Historical decompositions -------------------
dates<-rownames(data_matrix1[(lags+1):nrow(data_matrix1),])
T_start <-which(dates==2023.5)# Start time for counterfactual scenario
T_end<-which(dates==2024.75)
BM<- build_companion_matrices(
  A_array = posterior$posterior$A,
  B_array = posterior$posterior$B,
  p = lags,
  thinning = floor(2000/parallel::detectCores())
)
length(BM$Btilde)

stsh_m<-stsh # %>% apply(.,c(1,2),function(x)quantile(x,.5)) %>% array(.,dim=c(dim(stsh)[1],dim(stsh)[2],1))

HD_array<-historical_decomposition(  data_ = data_matrix1,
                                     p = lags,
                                     Btilde_list = BM$Btilde,
                                     M_full_list = BM$M_full,
                                     intercept_list =BM$intercept,
                                     shocks = stsh_m,
                                     T0=T_start, T1=T_end) 


dates_date<-as.Date(as.yearqtr(as.numeric(dates)))
pp<-plot_historical_decomposition(HD_array, T0=T_start, T1=T_end,
                                  variable_names = variable_names , 
                                  shock_names = shock_names )+theme_uniform_text_size(size=18)+
  scale_x_continuous(
    breaks = seq(T_start, T_end, by = 1),
    labels = format(dates_date[T_start:T_end], "%b %Y") # e.g., "Jan 2024"
  )+theme(legend.position = 'bottom',axis.text.x = element_text(angle=45))+xlab('')+ylab('')+labs(subtitle="Share of total")

print(pp)
ggsave(filename="HD_counterf.pdf",plot=pp,device='pdf',path='figures',units = 'cm',width=18,height=16)



# Step 1: Build VECM systems per draw
A_array<-posterior$posterior$A
B_array<-posterior$posterior$B

vecm_list <- construct_VECM_companion_posterior(A_array, B_array, p = lags, mc.cores = 4)

# Step 2: Run historical decomposition across posterior
undebug(hd_VECM_decomp_posterior)
hd_array_all <- hd_VECM_decomp_posterior(vecm_list, data_matrix1, stsh,
                                         T0 = T_start, T1 = T_end, p = lags, mc.cores = 4)

hd_array <- mclapply_quantile_over_draws(hd_array_all, prob = 0.5, mc.cores = 4)

pp_vecm<-plot_hd_vecm_dodged(hd_array,
                             variable_names = varbls[subset_],
                             shock_names = varbls[subset_],
                             T_start = T_start,
                             T_end = T_end
)+theme_uniform_text_size(size=18)+
  scale_x_continuous(
    breaks = seq(T_start, T_end, by = 1),
    labels = format(dates_date[T_start:T_end], "%b %Y") # e.g., "Jan 2024"
  )+theme(legend.position = 'bottom',axis.text.x = element_text(angle=45))+
  xlab('')+ylab('')+labs(title='',subtitle="")
pp_vecm
ggsave(filename="HD_counterf_vecm.pdf",plot=pp_vecm,device='pdf',path='figures',units = 'cm',width=18,height=16)


pp_vecm_cum<-plot_cumulative_hd_vecm(hd_array,
                                     variable_names = varbls[subset_],
                                     shock_names = varbls[subset_],
                                     T0 = T_start,
                                     T1 = T_end
)+theme_uniform_text_size(size=18)+
  scale_x_continuous(
    breaks = seq(T_start, T_end, by = 1),
    labels = format(dates_date[T_start:T_end], "%b %Y") # e.g., "Jan 2024"
  )+theme(legend.position = 'bottom',axis.text.x = element_text(angle=45))+
  xlab('')+ylab('')+labs(title="",subtitle="")
graphics.off()
print(pp_vecm_cum)
ggsave(filename="HD_counterf_vecm_cum.pdf",plot=pp_vecm_cum,device='pdf',path='figures',units = 'cm',width=18,height=16)
