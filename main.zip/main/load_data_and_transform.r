
load('../data/dataHC.rds')
names(dataHC)
summary(dataHC)
dataHC$YCslope<-dataHC$I_10Y-dataHC$STR3m
dataHC%<>%mutate(LNGDP=log(GDP_NOM_SCA),
                 LNRENT=log(RENT_CPI),
                 LNHP=log(P_POH_EXT),
                 LNMORT=log(MORTG_HH),
                 LRM3=log(M3/CPI),
                 LRGDP=log(GDP_NOM_SCA/CPI),
                 LRRENT=log(RENT_CPI/CPI),
                 LRHP=log(P_POH_EXT/CPI),
                 LRMORT=log(MORTG_HH/CPI),
                 NoMortCred=NA,#(cred_unsec+cred_sec2),
                 LNoMortCred=log(NoMortCred),
                 LNoMort_GDP=LNoMortCred-LNGDP,
                 LCPI=log(CPI),
                 spread=I_MORTG-STR3m,
                 pi_=100*(LCPI-dplyr::lag(LCPI,4)),
                 LRGDP_f=(log(GDP_f)-log(CPI_f)),
                 spread_f=I_MORTG_f-STR3m_f,
                 pi_f=100*(log(CPI_f)-dplyr::lag(log(CPI_f),4)),
                 pi_fpq=100*(log(CPI_fpq)-dplyr::lag(log(CPI_fpq),4)),
                 pi_3m=100*(LCPI-dplyr::lag(LCPI,1)),
                 pi_f_3m=100*(log(CPI_f)-dplyr::lag(log(CPI_f),1)),
                 pi_fpq_3m=100*(log(CPI_fpq)-dplyr::lag(log(CPI_fpq),1)),
                 LMORT_GDP=LNMORT-LNGDP,
                 DLMORT=(LNMORT-dplyr::lag(LNMORT))*100,
                 LUS_gdp=log(US_gdp),
                 LNEER=log(NEER),
                 LREER=log(REER),
                 LGDP_ROW=log(gdp_row),
                 Lusdch=log(usdch),
                 Lcape=log(cape)) 

df<-dataHC     

## HP and mortgates
ggplot(df)+geom_line(aes(year,LRHP,color='LRHP'))+geom_line(aes(year,LRMORT,color='LRMORT'))+
  scale_color_manual('', values=c('LRHP'='blue','LRMORT'='red'))+theme_minimal()

fit.hp<-lm(data=df,formula=LRHP~index(year)+LRMORT+lag(LRMORT,1)+lag(LRHP,1))
summary(fit.hp)

df.d<-sapply(X=c("year","LRHP","LRMORT"),FUN=function(x){
  
  if(x=="year"){
    tmp<-df[[x]]
  }else{
    tmp<-df[[x]]-dplyr::lag(df[[x]],4)
}
}) %>% as.data.frame()


# df.d$year<-df$year[-(1:4)]
fit.hp.d<-lm(data=df.d,formula=LRHP~LRMORT+lag(LRMORT,1)+lag(LRHP,1))
summary(fit.hp.d)

ggplot(df.d)+geom_line(aes(year,LRHP,color='LRHP'))+geom_line(aes(year,LRMORT,color='LRMORT'))+
  scale_color_manual('', values=c('LRHP'='blue','LRMORT'='red'))+theme_minimal()
