
## ----Conditional Forecast Inflation at x% MP shocks only, -------------------------------------------------------------
#NB: Y contans the data n_var x T

zero_x<-'2024-01-01'
h=4 # horizon
varbl2plot<-which(subvar=='LRHP')
n_sim=500 # number of shock draws
obs=which(subvar%in%c("pi_3m")) # position of observable
pos_cond_vars=obs 
# given the path of the observables
TT=nrow(df)
T.start='2025-01-01'
T.end=as.Date(T.start)%m+%months(9)
path_pif=df[df$year>=T.start,"pi_f_3m"][1:h] %>% tibble(pi=.,period=seq.Date(as.Date(T.start),length.out = 4,by='quarter'))

pathSTR=df[df$year>=T.start,"STR3m"][1:h]
path<-c(.2,0.5,.6,.7)

# uncond.forc[uncond.forc$hor>0&uncond.forc$variable==subvar[pos_cond_vars],'Median']$Median#df[(TT-h+1):TT,obs]
bvarSign_path=df[(TT-h+1):TT,]
bvarSign_path[,names(bvarSign_path)!=subvar[obs]]<-NA
bvarSign_path[,names(bvarSign_path)==subvar[obs]]<-path
bvarSign_path<-bvarSign_path[,subvar]

# give the shocks that are not driving the scenario: NA if all driving
shocks=which(!c(subset_)%in%which(subvar%in%c("STR3m")))#c(1,2,3)
tmp<-scenarios(h = h,path = path,obs = obs,
               free_shocks = shocks,n_sample = n_draws,
               data_ = Z,g=NULL,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)
mu_eps<-tmp[[1]]
Sigma_eps<-tmp[[2]]
mu_y<-tmp[[3]]
Sigma_y<-tmp[[4]]
big_b<-tmp[[5]]
big_M<-tmp[[6]]

# y_h_cond_MP_only<-SimScen(mu_eps = mu_eps,
#                           Sigma_eps = Sigma_eps,
#                           mu_y = mu_y,
#                           Sigma_y = Sigma_y,big_b = big_b,
#                           big_M = big_M,
#                           n_sim = n_sim,
#                           h = h,varbls = subvar)
y_h_cond_MP_only<-simulate_conditional_forecasts(mu_y=mu_y, Sigma_y=Sigma_y, varnames = subvar, n_sim = n_sim)


y_data<-t(Y) %>% as.data.frame()
y_data$hor<-dates_date

# conditional on forecasts from PAS
tmp_pas<-scenarios(h = h,path =path_pif$pi ,obs = obs,
                   free_shocks = shocks,n_sample = n_draws,
                   data_ = Z,g=NULL,Sigma_g=NULL,
                   posterior=posterior,matrices=matrices)
mu_eps_pas<-tmp_pas[[1]]
Sigma_eps_pas<-tmp_pas[[2]]
mu_y_pas<-tmp_pas[[3]]
Sigma_y_pas<-tmp_pas[[4]]
big_b_pas<-tmp_pas[[5]]
big_M_pas<-tmp_pas[[6]]

y_h_cond_MP_only_pas<-simulate_conditional_forecasts(mu_y=mu_y_pas, Sigma_y=Sigma_y_pas, varnames = subvar, n_sim = n_sim)



# first plot the scenario
p_sce<-plot_cond_forc(varbl2plot='pi_3m',y_h_cond=y_h_cond_MP_only,
                      center=0.5,lower=0.16,upper=0.84,
                      T.start=T.start,T.end=T.end,y_data=y_data)

p_sce[[1]]<-p_sce[[1]]+theme_uniform_text_size(size=18)+ylab('')+xlab('')+
  theme(axis.text.x=element_text(angle=45))+
  coord_cartesian(xlim=as.Date(c('2023-01-01',T.end)))+
  geom_line(data=path_pif,aes(x=period,y=pi,linetype='dotted'),color='cyan',linewidth=2)+
  scale_linetype_manual('',values=c('dashed'='dashed','solid'='solid','dotted'='dotted'),
                        labels=c('dashed'='scenario','solid'='data','dotted'='external forecast'))

print(p_sce[[1]])



ggsave('cond_forc_MP_pi_target_scen.pdf',plot=p_sce[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')
# then plot LRHP
p_sce2<-plot_cond_forc(varbl2plot='LRHP',
                       y_h_cond=y_h_cond_MP_only,
                       center=0.5,lower=0.16,upper=0.84,
                       T.start=T.start,T.end=T.end,y_data=y_data)

p_pas<-plot_cond_forc(varbl2plot='LRHP',
                      y_h_cond=y_h_cond_MP_only_pas,
                      center=0.5,lower=0.16,upper=0.84,
                      T.start=T.start,T.end=T.end,y_data=y_data)

newd<-p_pas[[2]][p_pas[[2]]$hor>=T.start,'LRHP']
p_sce2[[1]]<-p_sce2[[1]]+theme_uniform_text_size(size=18)+ylab('')+xlab('')+
  coord_cartesian(xlim=as.Date(c('2023-01-01',T.end)),ylim=c(0.8,1.2))+
  geom_line(data=newd,aes(x=hor,y=center,linetype='dotted'),linewidth=2,color='cyan')+
  geom_line(data=newd,aes(x=hor,y=upper,linetype='dotted'),linewidth=2,color='cyan')+
  geom_line(data=newd,aes(x=hor,y=lower,linetype='dotted'),linewidth=2,color='cyan')+
  theme(axis.text.x=element_text(angle = 45))+
  scale_linetype_manual('',values=c('dashed'='dashed',
                                    'solid'='solid','dotted'='dotted'),
                        labels=c('dashed'='scenario',
                                 'solid'='data',
                                 'dotted'='implied by external forecast'))


print(p_sce2[[1]])



ggsave('cond_forc_MP_pi_target_LRHP.pdf',plot=p_sce2[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')

# set threshold as x% increase since last obs
dt_t<-specification$get_data_matrices()$Y %>% t()
threshold=last(dt_t[,subvar[varbl2plot]])*(1.01)

p<-plot_cond_histo(variable=subvar[varbl2plot],horizon=1,
                   threshold = threshold,data =y_h_cond_MP_only,
                   above=F,size=5)

print(p)

ggsave('cond_histo_MP_pi_target.pdf',plot=p,device='pdf',path='figures',width=18,height=16,units = 'cm')


q0<-KL(Sigma_eps,mu_eps,h,plot_=T)
q_MP<-q0[[1]]  
p_MP<-q0[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
med_q_MP=mean(q_MP)
print(p_MP)
ggsave('KL_MP_target.pdf',plot=p_MP,device='pdf',path='figures',width=18,height=16,units = 'cm')
# hist(q,main='KL measure (ref value 0.5)')
