## ----value at risk-------------------------------------------------------------------------------------------

tmp_pi_cf<-y_h_cf["pi_3m.4",]
tmp_pi_low_cf<-sum(tmp_pi_cf<0)/length(tmp_pi_cf)

VaR_CPI_cf=quantile(y_h_cf["pi_3m.4",],0.10)-last(dt_t[,'pi_3m'])
VaR_GDP_cf=(quantile(y_h_cf["LRGDP.4",],0.10)-last(dt_t[,'LRGDP']))*100
VaR_HP_cf=(quantile(y_h_cf["LRHP.4",],0.10)-last(dt_t[,'LRHP']))*100
data_VaR_cf <- data.frame(
  "KL" = med_q_cf,
  "GDP" = VaR_GDP_cf,
  "infl" =VaR_CPI_cf,
  "HP"=VaR_HP_cf
)
# #>>>>>>>> conditional forecast one period earlier ----------
# tmp_pi_cf_m1<-y_h_cf_m1["pi_3m.4",]
# tmp_pi_low_cf_m1<-sum(tmp_pi_cf_m1<0)/length(tmp_pi_cf_m1)
# 
# VaR_CPI_cf_m1=quantile(y_h_cf_m1["pi_3m.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'pi_3m'])
# VaR_GDP_cf_m1=(quantile(y_h_cf_m1["LRGDP.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'LRGDP']))*100
# VaR_HP_cf_m1=(quantile(y_h_cf_m1["LRHP.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'LRHP']))*100
# data_VaR_cf_m1 <- data.frame(
#   "KL" = med_q_cf_m1,
#   "GDP" = VaR_GDP_cf_m1,
#   "infl" =VaR_CPI_cf_m1,
#   "HP"=VaR_HP_cf_m1
# )
# Generate the table with kable
# data_VaR_both<-rbind(data_VaR_cf_m1,data_VaR_cf)
# rownames(data_VaR_both)<-c('Previous','Current')
# 
# var_html_update<-knitr::kable(data_VaR_both,
#                               format='latex',digits = 2,
#                               align = "c",row.names =T,
#                               col.names = c("Projection","KL measure","Log Real GDP %",
#                                             "Inflation %",
#                                             "Log House Prices %"),booktabs=T)
# # Save the HTML table to a file
# cat(as.character(var_html_update), file = "figures/var_html_update.tex")
# print(var_html_update)

# VaR STR comparison ------
VaR_CPI_cf_STR=quantile(y_h_cf_STR["pi_3m.4",],0.10)-last(dt_t[,'pi_3m'])
VaR_GDP_cf_STR=(quantile(y_h_cf_STR["LRGDP.4",],0.10)-last(dt_t[,'LRGDP']))*100
VaR_HP_cf_STR=(quantile(y_h_cf_STR["LRHP.4",],0.10)-last(dt_t[,'LRHP']))*100
VaR_MORT_cf_STR=(quantile(y_h_cf_STR["LRMORT.4",],0.10)-last(dt_t[,'LRMORT']))*100
data_VaR_cf_STR <- data.frame(
  "KL" = med_q_cf_STR,
  "GDP" = VaR_GDP_cf_STR,
  "infl" =VaR_CPI_cf_STR,
  "HP"=VaR_HP_cf_STR,
  "MORT"=VaR_MORT_cf_STR
)
#>>>>>>>> conditional forecast Alternative STR ----------


VaR_CPI_cf_STR2=quantile(y_h_cf_STR2["pi_3m.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'pi_3m'])
VaR_GDP_cf_STR2=(quantile(y_h_cf_STR2["LRGDP.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'LRGDP']))*100
VaR_HP_cf_STR2=(quantile(y_h_cf_STR2["LRHP.4",],0.10)-last(dt_t[1:(nrow(dt_t)-1),'LRHP']))*100
VaR_MORT_cf_STR2=(quantile(y_h_cf_STR2["LRMORT.4",],0.10)-last(dt_t[,'LRMORT']))*100

data_VaR_cf_STR2 <- data.frame(
  "KL" = med_q_cf_STR2,
  "GDP" = VaR_GDP_cf_STR2,
  "infl" =VaR_CPI_cf_STR2,
  "HP"=VaR_HP_cf_STR2,
  "MORT"=VaR_MORT_cf_STR2
)
# Generate the table with kable
data_VaR_both<-rbind(data_VaR_cf_STR,data_VaR_cf_STR2)
rownames(data_VaR_both)<-c('PAS Baseline','Alternative')

var_html_STR2<-knitr::kable(data_VaR_both,
                            format='latex',digits = 2,
                            align = "c",row.names =T,
                            col.names = c("Projection","KL measure","Log Real GDP %",
                                          "Inflation %",
                                          "Log House Prices %","Log Real Mortgages"),booktabs=T)
# Save the HTML table to a file
cat(as.character(var_html_STR2), file = "figures/var_html_STR2.tex")
print(var_html_STR2)



### graphical VaR comparison ------
VaR_CPI_STR2_graph=(y_h_cf_STR2["pi_3m.4",]-last(y_data[,'pi_3m']))
VaR_GDP_STR2_graph=(y_h_cf_STR2["LRGDP.4",]-last(y_data[,'LRGDP']))*100
VaR_HP_STR2_graph=(y_h_cf_STR2["LRHP.4",]-last(y_data[,'LRHP']))*100
VaR_MORT_STR2_graph=(y_h_cf_STR2["LRMORT.4",]-last(y_data[,'LRMORT']))*100

p_HP<-dens_var(VaR_HP_STR2_graph,threshold = 0.1)
print(p_HP)

#>>>>>>>>>>>>> MP_pas -------

tmp_pi<-y_h_cond_MP_only_pas["pi_3m.4",]
tmp_pi_low<-sum(tmp_pi<0)/length(tmp_pi)

VaR_CPI=quantile(y_h_cond_MP_only_pas["pi_3m.4",],0.10)-last(dt_t[,'pi_3m'])
VaR_GDP=(quantile(y_h_cond_MP_only["LRGDP.4",],0.10)-last(dt_t[,'LRGDP']))*100
VaR_HP=(quantile(y_h_cond_MP_only["LRHP.4",],0.10)-last(dt_t[,'LRHP']))*100
data_VaR <- data.frame(
  "KL" = med_q_MP,
  "GDP" = VaR_GDP,
  "infl" =VaR_CPI,
  "HP"=VaR_HP
)

# Generate the table with kable
var_html<-knitr::kable(data_VaR,format='latex',digits = 2, align = "c",row.names = F,
                       col.names = c("KL measure","Log-GDP (10th Q.le)%",
                                     "Infl. (10th Q.le)%",
                                     "Log-HP (10th Q.le)%")
)%>% 
  footnote(
    general = "Values relative to latest observation",
    footnote_as_chunk = TRUE,
    general_title = "Note:"
  )




## ------------------------------------------------------------------------------------------------------------
# Save the HTML table to a file
cat(as.character(var_html), file = "figures/var_html.tex")
print(var_html)

