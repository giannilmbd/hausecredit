# HOUSING-CREDIT MODEL
# @SNB-GPA 2024 



# The hash (#) is how you write a comment
# Hash (text) and series of --- is how you write the title of a section that will appear in the table of content (right corner of this window) ----------

# To execute a line place the cursor there and press ctrl+enter
# To execute a more line highlight them and ctrl+enter
# To execute line by line repeatedly press ctrl+enter
# To execute all up to the cursor press ctrl+alt+B
# To execute from cursor to the end press ctrl+alt+E

# Set the working directory (getwd() is how you get where you are... type below in the console window)
# UDJUST AS NEEDED

# setwd('~/Dropbox/ColCarAlb_runs/BVAR/main')
setwd('~/Dropbox/SNB/r-project/BVAR_Housing_and_Credit/main/')
# setwd('~/HousePrices/main')
# NB: In R assignments can be done either with "=" or "<-". Inside functions use =. So might be safer always to use it.


# Load/install packages ---------------------------------------------------------------
source('install_packages_and_functions.r')

## ----Data load and transform--------------------------------------------------------------------------------
source('load_data_and_transform.r')




## ----BVAR RESTRICTIONS, include=FALSE,echo=FALSE-------------------------------------------------------------
source('data_spec_and_sign_restrictions.r')

## ----Run Bvar, IRFs and diagnostics -----------------------------------------------------------------------

source('estimate_and_IRFs_and_diagnostics.r')

# VECM representation and historical decomposition ----------------
source('vecm_and_HD.r')


# FORECAST ----------
source('unconditional_forecast.r')

## ----Conditional Forecast, on inflation and comparison--------------------------------------------------------------------
## must run after unconditional
source('conditional_forecast_on_inflation_and_comparison.r')



# two interest rates scenario ------------
source('two_interest_rates_scenario_pas.r')

## ----Conditional Forecast MP only, include=FALSE-------------------------------------------------------------
source('conditional_forecast_MP_only.r')


## ----Conditional Forecast Inflation at x% MP shocks only, -------------------------------------------------------------
source('conditional_forecast_inflation_at_x.r')

#source('conditional_forecast_ZLB.r')


# other value at risk -------
source('other_VaR.r')
# POLICY RULE
source('policy_rule.r')
