
# Conditional forecast --- TWO SCENARIOS ON INTEREST RATE -------------
# One possible exercise is to compare the conditional (on all shocks) scenario
# based on PAS projections. 
# Then treat the outcome as data and extract all shocks underpinning it.
# Then starting from the first forecast period construct a counterfactual
# scenario constrained by the short term rate following an alternative path
# driven only by the policy shock. 
## >>>>>>>>> FIRST SCENARIO STR ALL SHOCKS ----------------
 # RUN ALL BLOCK

zero_x<-'2024-01-01'
h=4 # horizon
n_sim=500 # number of shock draws
obs=which(subvar%in%c('STR3m','pi_3m','LRGDP','spread')) # position of observable
pos_cond_vars=obs 
# given the path of the observables
TT=nrow(df)
T.start='2025-04-01'
T.end=as.Date(T.start)%m+%months(9)
T.previous<-as.Date(T.start)%m-%months(3)

# fill missing GDP using growth rates and generate the forecast of GDP the same way

df[df$year==T.previous,'LRGDP']<-df[df$year==T.previous%m-%months(3),'LRGDP']+
  (df[df$year==T.previous,'LRGDP_f']-df[df$year==T.previous%m-%months(3),'LRGDP_f'])
df$LRGDP_ff<-df$LRGDP
ggplot(df)+geom_line(aes(x=year,LRGDP_ff),color='blue')+geom_line(aes(x=year,LRGDP),color='red')
remdates<-seq.Date(from=as.Date(T.start),to=as.Date(last(df$year)),by='quarter')
for(cnt in 1:length(remdates) ){
  df[df$year==remdates[cnt],'LRGDP_ff']<-df[df$year==remdates[cnt]%m-%months(3),'LRGDP_ff']+
    (df[df$year==remdates[cnt],'LRGDP_f']-df[df$year==remdates[cnt]%m-%months(3),'LRGDP_f'])
}
path_baseline<-rbind(df[df$year>=T.start,"STR3m_f"][1:h],
 df[df$year>=T.start,"pi_f_3m"][1:h],
 df[df$year>=T.start,"LRGDP_ff"][1:h],
 df[df$year>=T.start,"spread_f"][1:h])
path<-path_baseline 
if(any(is.na(path))){
	 
	 stop("NA PATH")
 }
#uncond.forc[uncond.forc$hor>0&uncond.forc$variable==subvar[pos_cond_vars],'Median']$Median#df[(TT-h+1):TT,obs]
bvarSign_path=df[df$year>=T.start&df$year<=T.end,]
bvarSign_path[,!names(bvarSign_path)%in%subvar[obs]]<-NA
bvarSign_path[,names(bvarSign_path)%in%subvar[obs]]<-path
bvarSign_path<-bvarSign_path[,subvar]

# give the shocks that are not driving the scenario: NA if all driving
shocks=NA
dates_date<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix1[(specification$p+1):nrow(data_matrix1),]))))
y_data<-df[df$year>=dates_date[1]&df$year<T.start,c('year',subvar)]
names(y_data)[names(y_data)=='year']<-'hor'
y_data[y_data$hor==T.previous,'LRGDP']
summary(y_data)

data_0<-df[df$year>=dates_date[1]%m-%months(n_p*3)&df$year<=T.previous,c('year',subvar)]
rownames(data_0)<-as.numeric(as.yearqtr(data_0$year))
data_1<-data_0[,names(data_0)!='year']
newZ<-data_companion_form(t(data_1%>% as.matrix()))[["Z"]]
data_<-newZ[rownames(newZ)!='intercept',]
autoplot(ts(data_1,freq=4),facets = TRUE)
tmp<-scenarios(h = h,
							 path = path,obs = obs,
							 free_shocks=shocks,n_sample = n_draws,
							 data_ = data_,g=NULL,Sigma_g=NULL,
							 posterior=posterior,matrices=matrices)
			# )

# system.time(
# tmp_old<-scenarios_old(h,path,obs,shocks,n_draws,n_sample=n_draws,n_var,n_p,data_=Z)
# )
mu_eps_STR<-tmp[[1]]
Sigma_eps_STR<-tmp[[2]]
mu_y_STR<-tmp[[3]]
Sigma_y_STR<-tmp[[4]]
big_b_STR<-tmp[[5]]
big_M_STR<-tmp[[6]]

# simulate PAS scenario with all uncertainty
y_h_cf_STR <- simulate_conditional_forecasts(mu_y=mu_y_STR,
                                             Sigma_y=Sigma_y_STR, 
                                             varnames = subvar, n_sim = n_sim)

varbl2plot<-which(subvar=="LRGDP")
p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                         y_h_cond=y_h_cf_STR,
                         center=0.5,lower=0.16,upper=0.84,
                         T.start=T.start,
                         T.end=T.end,
                         before = 8,
                         y_data=y_data)
print(p_cf_STR[[1]]+xlab('')+ylab(subvar[varbl2plot])+
        coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )

varbl2plot<-which(subvar=="LRMORT")
p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                          y_h_cond=y_h_cf_STR,
                          center=0.5,lower=0.16,upper=0.84,
                          T.start=T.start,
                         T.end=T.end,
                         before = 8,
                         y_data=y_data)
print(p_cf_STR[[1]]+xlab('')+ylab(subvar[varbl2plot])+
        coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )
# GET THE DATA FROM THE SCENARIO
data.baseline<-p_cf_STR[[2]]
data.baseline$data<-ifelse(is.na(data.baseline$data),data.baseline$center,data.baseline$data)



## ---- Conditional forecast alternative path STR

# Now construct the counterfactual scenario
derivedY<-get_data_from_scenario(scenario_ = y_h_cf_STR,T0=T.start,T1=T.end)
tail(derivedY)
dim(derivedY)
# derivedY<-rbind(data_matrix1[!rownames(data_matrix)%in%rownames(derivedY),],derivedY[,colnames(data_matrix1)])
derivedY<-rbind(t(newZ[1:n_var,]),
derivedY[,-1])
dim(derivedY)
# y_data<-derivedY[(specification$p+1):nrow(derivedY),]
# dim(y_data)
# y_data$hor<-as.Date(as.yearqtr(as.numeric(rownames(y_data))))


# can get the data directly
y_data_STR<-pivot_wider(data.baseline,names_from = 'variable',values_from = 'data',id_cols = 'hor')
y_data_STR<-y_data_STR[,c('hor',subvar)] %>% as.data.frame()
autoplot(ts(y_data_STR,freq=4),facets = TRUE)
autoplot(ts(derivedY,freq=4),facets = TRUE)
# extract new shocks
stsh_cf<-extract_shocks(posterior =posterior,
specification = specification,
data_=t(derivedY %>% as.matrix()))
class(stsh_cf)<-"PosteriorShocks"
graphics.off()
plot(stsh_cf)
# check the path of STR
plotly::ggplotly(ggplot(data=y_data)+geom_line(aes(hor,STR3m)) )
## mean of shocks underpinning PAS projections
stsh_cf_m<-apply(stsh_cf,c(1,2),mean)
# Same shocks except STR for the last h periods
 g<-stsh_cf_m[,(ncol(stsh_cf_m)-h+1):ncol(stsh_cf_m)] %>% .[-c(1),]


##>>>> scenario based on constant STR ---------

# path=rbind(rep(y_data[y_data$hor>=T.previous,"STR3m"][1],h),#c(df[df$year>=T.start&df$year<=T.end,"STR3m_f"][2:3],0,0)  #
# df[df$year>=T.start,"pi_f_3m"][1:h])

# 25 bp
projection<-df[df$year>=T.start&df$year<=T.end,"STR3m_f"]
path=rbind(
  #ifelse(projection>0,projection,rep(0.25,length(projection))),#c(df[df$year>=T.start&df$year<=T.end,"STR3m_f"][2:3],0,0)  #
  rep(projection[1],h), 
          df[df$year>=T.start,"pi_f_3m"][1:h])
# positive rate
# projection<-df[df$year>=T.start&df$year<=T.end,"STR3m_f"]
# path=rbind(ifelse(projection>0,projection,rep(0,length(projection))),#c(df[df$year>=T.start&df$year<=T.end,"STR3m_f"][2:3],0,0)  #
#            df[df$year>=T.start,"pi_f_3m"][1:h])
path<-path[1,]
obs<-obs[1]
tmp_STR2<-scenarios(h = h,
               path = path,
               obs = obs,
               free_shocks=which(!subvar=="STR3m"),
               n_sample = n_draws,
               data_ = data_,g = g,Sigma_g=NULL,
               posterior=posterior,matrices=matrices)


mu_eps_STR2<-tmp_STR2[[1]]
Sigma_eps_STR2<-tmp_STR2[[2]]
mu_y_STR2<-tmp_STR2[[3]]
Sigma_y_STR2<-tmp_STR2[[4]]
big_b_STR2<-tmp_STR2[[5]]
big_M_STR2<-tmp_STR2[[6]]

  # y_h_cf_STR2<-SimScen(mu_eps = mu_eps_STR2,Sigma_eps = Sigma_eps_STR2,mu_y = my_y_STR2,Sigma_y = Sigma_y_STR2,
  #                      big_b = big_b_STR2,big_M = big_M_STR2,n_sim = n_sim,h =h,
  #                      varbls = subvar,idx_sampled = 1:n_draws)

  y_h_cf_STR2<-simulate_conditional_forecasts(mu_y=mu_y_STR2,
                                              Sigma_y=Sigma_y_STR2, 
                                              varnames = subvar, n_sim = n_sim)
  
  p_cf_STR2<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                           y_h_cond=y_h_cf_STR2,
                           center=0.5,lower=0.16,upper=0.84,
                           T.start=T.start,
                           T.end=T.end,
                           before = 8,
                           y_data=y_data)
  print(p_cf_STR2[[1]]+xlab('')+ylab(subvar[varbl2plot])+
          coord_cartesian(xlim=as.Date(c(zero_x,T.end))) )
## >>>>>>> PLOTS ----------------


# BASELINE


for (cnt in 1:length(subvar)){

varbl2plot=cnt #which(subvar=='LRMORT')

p_cf_STR<-plot_cond_forc(varbl2plot=	subvar[varbl2plot],
                         y_h_cond=y_h_cf_STR,
                         center=0.5,lower=0.16,upper=0.84,
                         T.start=T.start,
                         T.end=T.end,before = 8,
                         y_data=y_data)

y_limits1<-p_cf_STR[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'data'] %>% quantile(.,c(0,1),na.rm=T)
y_limits2<-p_cf_STR[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'upper'] %>% quantile(.,c(0,1),na.rm=T)
y_limits3<-p_cf_STR[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'lower'] %>% quantile(.,c(0,1),na.rm=T)

y_limitsA<-quantile(c(y_limits1,y_limits2,y_limits3),c(0,1)) %>% as.numeric() #%>% {.}*c(.8,1.2)

p_cf_STR[[1]]<-p_cf_STR[[1]]+theme_uniform_text_size(size=18)+
  ylab(subvar[varbl2plot])+xlab('')+theme(axis.text.x=element_text(angle=45))+
  coord_cartesian(xlim=as.Date(c(zero_x,T.end)),ylim=y_limitsA)
graphics.off()
print(p_cf_STR[[1]])

ggsave(paste0('cond_forc_pas_',subvar[cnt],'.pdf'),plot=p_cf_STR[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')

## check 
# rbind(p_cf_STR[[2]] %>% .[.$variable=="STR3m",'center'] %>% tail() %>% .[3:(h+2)],
#       p_cf_STR[[2]] %>% .[.$variable=="pi_3m",'center'] %>% tail()%>% .[3:(h+2)])
# path

# ALTERNATIVE



p_cf_STR2<-plot_cond_forc(varbl2plot=subvar[varbl2plot],y_h_cond=y_h_cf_STR2,
                     center=0.5,lower=0.16,upper=0.84,
                     T.start=T.start,T.end=T.end,before = 8,y_data=y_data)


y_limits1<-p_cf_STR2[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'data'] %>% quantile(.,c(0,1),na.rm=T)
y_limits2<-p_cf_STR2[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'upper'] %>% quantile(.,c(0,1),na.rm=T)
y_limits3<-p_cf_STR2[[2]] %>% .[.$variable==subvar[cnt]&.$hor>zero_x,'lower'] %>% quantile(.,c(0,1),na.rm=T)

y_limitsB<-quantile(c(y_limits1,y_limits2,y_limits3),c(0,1)) %>% as.numeric() #%>% {.}*c(.9,1.1)

y_limits<-quantile(c(y_limitsA,y_limitsB),c(0,1))

p_cf_STR2[[1]]<-p_cf_STR2[[1]]+theme_uniform_text_size(size=18)+
  ylab(subvar[varbl2plot])+xlab('')+theme(axis.text.x=element_text(angle=45))+
  coord_cartesian(xlim=as.Date(c(zero_x,T.end)),ylim=y_limitsB)
graphics.off()
print(p_cf_STR2[[1]])


ggsave(paste0('cond_forc_pas_altern_',subvar[cnt],'.pdf'),plot=p_cf_STR2[[1]],device='pdf',path='figures',width=18,height=16,units = 'cm')


## >>>>>>>>> combine both
p_cf_comby<-plot_comby(p_cf_STR2[[1]],p_cf_STR[[1]],T.start = T.start,
                       T.end=T.end,T.previous=T.previous)

saveRDS(p_cf_STR,file=paste0('baseline_',subvar[cnt],'.RDS'))
saveRDS(p_cf_STR2,file=paste0('alternative_',subvar[cnt],'.RDS'))

ggsave(paste0('cond_forc_pas_comby_',subvar[cnt],'.pdf'),plot=p_cf_comby,device='pdf',path='figures',width=18,height=16,units = 'cm')

} # end looping through variables



if(F){# FOLLOWING IS AN ALTERNATIVE WAY
## >>>>>>>> counterfactural -----------------------

T.previous<-as.Date(T.start)%m-%months(3)
true_data<-y_data
names(true_data)[names(true_data)=="hor"]<-"year"
BM<- build_companion_matrices(
	A_array = posterior$posterior$A,
	B_array = posterior$posterior$B,
	p = lags,
	thinning = 1
)

target_var<-which('STR3m'%in%varbls[subset_])
seq_cont<-seq.Date(from=as.Date(T.start),to=T.end,by='quarter')
imposed_path=path # FOR DEBUGGING # true_data[true_data$year>=T.start&true_data$year<=T.end,'STR3m']
dim(stsh_cf)
dim(true_data)
# check counterfactual data ---------

X<-newZ[["X"]]
X<-X[-nrow(X),]
data_matrix2<-derivedY
dim(data_matrix2)
rownames(data_matrix2)<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix2)))) %>% as.character()

dimnames(stsh_cf)[[2]]<-rownames(data_matrix2)[(specification$p+1):nrow(data_matrix2)]
undebug(pure_counterfactual)
Y_counterf<-pure_counterfactual(data_=data_matrix2, p=specification$p,
										Btilde_list=BM$Btilde,
										M_full_list=BM$M_full,
										intercept_list=BM$intercept,
										shocks=stsh_cf,
										target_var=target_var,
										T0=T.start,
										shock_vars = target_var,
										T1=T.end,
										imposed_path=imposed_path)
T0<-which(dimnames(stsh_cf)[[2]]==T.start)
T1<-which(dimnames(stsh_cf)[[2]]==T.end)
shock_imposed_path<-stsh_cf[,T0:T1,]
new_scen<-scenarios(h = h,path=path,obs = target_var,
							 free_shocks=target_var,
							 n_sample = n_draws,
							 data_ = Z,g=shock_imposed_path,Sigma_g=NULL,
							 posterior=posterior,matrices=matrices)



							
Y_counterf<-Y_counterf[[1]]
dimnames(Y_counterf)[[1]]<-varbls[subset_]
dimnames(Y_counterf)[[2]]<-seq.Date(as.Date(T.start),T.end,by='quarter') %>% as.yearqtr() %>% as.numeric()

draw_count<-dim(Y_counterf)[3]

if(F){
# check correctness if the path is the true series
tmp<-sapply(1:draw_count,FUN = function(x){
	chk<-Y_counterf[1,1:length(which(dimnames(stsh_cf)[[2]]==T.start):which(dimnames(stsh_cf)[[2]]==T.end)),x]  
	max(abs(chk-imposed_path))})
graphics.off()
plot(x=1:draw_count,y=tmp)
}

Y_counterf_moms<-get_quantile_df(Y_counterf)

Y_counterf_moms$year<-as.Date(as.yearqtr(as.numeric(Y_counterf_moms$year)))
STR_plot<-p_cf_STR[[1]]
STR_plot$layers <- lapply(STR_plot$layers, function(layer) {
  if (inherits(layer$geom, "GeomLine")) {
    layer$aes_params$size <- 1.2  # or whatever width you want
  }
  layer
})

np<-STR_plot+
geom_point(data=Y_counterf_moms[Y_counterf_moms$variable==varbls[subset_][varbl2plot],],
aes(year,center,color='counter'),size=2)+
geom_ribbon(data=Y_counterf_moms[Y_counterf_moms$variable==varbls[subset_][varbl2plot],],
					 aes(year,ymin=LB,ymax=UB),fill=light_green,alpha=.2)+
	theme_uniform_text_size(size=18)+ylab(subvar[varbl2plot])+xlab('')+
	geom_vline(xintercept=as.Date(T.start),linetype='dotted',color='red')+
	 scale_color_manual('',values = c('counter'=dark_green),labels=c("counter"='Counterfactual'))+
	coord_cartesian(xlim=as.Date(c('2023-01-01',T.end)),ylim=y_limits)+
	theme(legend.position = 'bottom')
graphics.off()
np

ggsave('cond_forc_comby_STR2.pdf',plot=np,device='pdf',path='figures',width=18,height=16,units = 'cm')
}



## >>>>>>>> KL MEASURES ---------

# baseline
graphics.off()
q0_cf_STR<-KL(Sigma_eps_STR,mu_eps_STR,h,plot_=T)
q_cf_STR<-q0_cf_STR[[1]]
p_KL_cf_STR<-q0_cf_STR[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
p_KL_cf_STR
med_q_cf_STR=mean(q_cf_STR)
ggsave('KL_cf_inf_current_STR.pdf',plot=p_KL_cf_STR,device='pdf',path='figures',width=18,height=16,units = 'cm')


# alternatives

# PAS STR


# constant STR


graphics.off()
q0_cf_STR2<-KL(Sigma_eps_STR2,mu_eps_STR2,h,plot_=T)
q_cf_STR2<-q0_cf_STR2[[1]]
p_KL_cf_STR2<-q0_cf_STR2[[2]]+labs(title='')+theme_uniform_text_size(size=18)+ylab('')+xlab('')
p_KL_cf_STR2
med_q_cf_STR2=mean(q_cf_STR2)
ggsave('KL_cf_inf_current_STR2.pdf',plot=p_KL_cf_STR2,device='pdf',path='figures',width=18,height=16,units = 'cm')


# VaR STR comparison ------

data_VaR_cf_STR<-compute_VaR(
  forecast_matrix = y_h_cf_STR,
  variables = c("pi_3m", "LRGDP", "LRHP", "LRMORT"),
  horizon = 4,
  data_frame = y_data,
  scale = c(FALSE, TRUE, TRUE, TRUE)
)
data_VaR_cf_STR['KL']<-med_q_cf_STR
data_VaR_cf_STR<-data_VaR_cf_STR[c(5,1:4)]
print(data_VaR_cf_STR)
tmp<-y_h_cf_STR["LRMORT.4",]-y_data[y_data$hor>=T.previous,"LRMORT"]
pl<-dens_var(tmp,0.1)
print(pl)
ggsave('VaR_LRMORT.pdf',plot=pl,device='pdf',path='figures',width=18,height=16,units = 'cm')


tmp<-y_h_cf_STR["LRHP.4",]-y_data[y_data$hor>=T.previous,"LRHP"]
pl<-dens_var(tmp,0.1)
print(pl)
ggsave('VaR_LRHP.pdf',plot=pl,device='pdf',path='figures',width=18,height=16,units = 'cm')

#>>>>>>>> conditional forecast Alternative STR ----------


data_VaR_cf_STR2<-compute_VaR(
  forecast_matrix = y_h_cf_STR2,
  variables = c("pi_3m", "LRGDP", "LRHP", "LRMORT"),
  horizon = 4,
  data_frame = y_data,
  scale = c(FALSE, TRUE, TRUE, TRUE)
)
data_VaR_cf_STR2['KL']<-med_q_cf_STR2
data_VaR_cf_STR2<-data_VaR_cf_STR2[c(5,1:4)]

print(data_VaR_cf_STR2)
# Generate the table with kable
data_VaR_both<-rbind(data_VaR_cf_STR,data_VaR_cf_STR2)
rownames(data_VaR_both)<-c('PAS Baseline','Alternative')

var_html_STR2<-knitr::kable(data_VaR_both,
                            format='latex',digits = 2,
                            align = "c",row.names =T,
                            col.names = c("Projection","KL","Log-real GDP %",
                                          "Infl. %",
                                          "Log-real HP %","Log-real Mortg."),booktabs=T)
# Save the HTML table to a file
cat(as.character(var_html_STR2), file = "figures/var_html_STR2.tex")
print(var_html_STR2)

# PERCENTAGE AT THE 68%
tmp0<-p_cf_STR2[[2]] %>% .[.$hor==T.previous&.$variable=="LRHP","data"] %>% min()
tmp1<-p_cf_STR2[[2]] %>% .[.$hor>=T.start&.$variable=="LRHP","lower"] %>% min()
(tmp0-tmp1)*100

tmp0<-p_cf_STR2[[2]] %>% .[.$hor==T.previous&.$variable=="LRMORT","data"] %>% min()
tmp1<-p_cf_STR2[[2]] %>% .[.$hor>=T.start&.$variable=="LRMORT","lower"] %>% min()
(tmp0-tmp1)*100

