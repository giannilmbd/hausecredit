## ----Generate Narrative,include=FALSE,echo=FALSE-------------------------------------------------------------
# Generate historical decomposition with identified shocks and pick dates with strongest effect
# Best is a 2 VAR to account for dynamics
# thresh<-30 # percent explained by other factors 
# X<-df %>% dplyr::select(year,MP_snb,STR3m) %>% na.omit() 
# 
# names(X)<-c('year','shock','variable')
# rho=X %>% reframe(cor(shock,variable))
# X$shock<-X$shock*sign(rho[1,1])
# 
# sr<-matrix(NA,nrow=2,ncol = 2)
# 
# sr[2,1]<-0.0
# sr
# # run bvar
# Xmx<-X[,-1] %>% as.matrix()
# specification_nar  = bsvarSIGNs::specify_bsvarSIGN$new(data=Xmx[,c(2,1)],
#                                        p        = 1,
#                                       max_tries = 100,
#                                       sign_irf = sr
#                                           )
# 
# 
# # estimate the model
# posterior_nar      = bsvars::estimate(specification_nar, S = 1000)
# 
# posterior_nar$posterior$B[,,1] %>% solve()
# 
# irf            = compute_impulse_responses(posterior_nar, horizon = 40)
# 
# plot(x=irf, probability = 0.68,shock_names=colnames(Xmx))
# 
# 
# 
# 
# library(vars)
# 
# fit.var<-vars::VAR(y=as.ts(Xmx,freq=4),p=1,type='const',season=NULL)
# fit.var.irf<-irf(fit.var,runs = 1500,orthogonal=T,impulse='shock',response='variable')
# plot(fit.var.irf)
# 
# fit.1<-lm(data=X,formula=variable~(shock))
# summary(fit.1)
# 
# rate_resp<-data.frame(year=X$year,y=fit.1$model$variable,yhat=fit.1$model$variable-fit.1$residuals)
# 
# ggplot(rate_resp)+geom_col(aes(x=year,y=yhat))+
#   geom_point(aes(x=year,y=y))
# 
# rate_resp %<>% mutate(share=abs(yhat/y-1)*100,
#                       narr=share<thresh)
# narrative_gen<-rate_resp$year[rate_resp$narr]
# 
# #**** save plot -
# p<-ggplot(rate_resp)+geom_col(aes(x=year,y=yhat,fill=narr))+
#   geom_point(aes(x=year,y=y))+labs(title="Actual vs predicted short-term rates")+ylab('')+xlab('')+
#   
#   scale_fill_manual('',values=c('TRUE'='blue','FALSE'='red'),labels=c('TRUE'='Explained','FALSE'='Unexplained'))
# 
# ggsave(filename = 'corr_shock_rate.pdf',plot=p,device='pdf',path='figures',units = 'cm',width=18,height = 16)
# 
# ## try LP
# {X<-df %>% summarize(year=year[-1],
#                      MP_snb=MP_snb[-1],
#                      DLNEER=diff(usdch)) %>% na.omit() 
# results_lin <- lpirfs::lp_lin(X[,-1],lags_endog_lin =NaN ,lags_criterion='AICc',max_lags =4,trend= 1,shock_type = 0,confint= 1.96,hor = 12)
# 
# plot(results_lin)
# }
# 
# 
# #### US shocks
# #FED shocks series
# # install.packages("readxl") #
# # install.packages("openxlsx", dependencies = TRUE)
# Xfed<-openxlsx::read.xlsx(xlsxFile = '../data/monetary-policy-surprises-data.xlsx',sheet=3)
# Xfed$year<-as.Date(paste(Xfed$Year,sprintf("%02d",Xfed$Month),"01",sep="-"),'%Y-%m-%d')
# Xfed<-Xfed[,names(Xfed)!='Year']
# 
# 
# Xfed$quarter<-as.yearqtr(Xfed$year)
# Xfed.q<-Xfed %>% group_by(quarter) %>% 
#   summarise(across(where(is.numeric), \(x) sum(x, na.rm = TRUE)), .groups = "drop")
# Xfed.q$year<-as.Date(Xfed.q$quarter)
# Xfed.q<-data.frame(year=Xfed.q$year,MPS=Xfed.q$MPS,MPS_ORTH=Xfed.q$MPS_ORTH)
# X<-df 
# X<-left_join(X,Xfed.q,by='year')
# 
# ggplot(X)+geom_point(aes(year,MPS_ORTH*4,color='MPS'))+
#   geom_point(aes(year,MP_fed,color='MP_fed'))
# 
# X %>% summarize(coMPS=cor(MPS,MP_fed,use="na.or.complete"),
#                 coORTH=cor(MPS_ORTH,MP_fed,use= "na.or.complete"),
#                 coRfed=cor(MPS_ORTH,ois1yFed,use= "na.or.complete"),
#                 coRfed2=cor(MPS,ois1yFed,use= "na.or.complete"))
# 
# {X2<-X[,c('year','MPS','ois1yFed')]
# names(X2)<-c('year','shock','variable')
# rho=X2 %>% reframe(cor(shock,variable,use= "na.or.complete"))
# X2$shock<-X2$shock*sign(rho[1,1])
# Xmx<-X2[,-1] %>% na.omit() %>% as.matrix()
# 
# fit.var_US<-vars::VAR(y=as.ts(Xmx,freq=4),p=4,type='both',season=NULL)
# # summary(fit.var)
# fit.var.irf_US<-irf(fit.var_US,runs = 1500,orthogonal=T,impulse='shock',response='variable')
# }
# plot(fit.var.irf_US,plot.type='multiple',nc=1,ylim = c(-0.5,0.5))
# 
# results_lin <- lpirfs::lp_lin(Xmx %>% as.data.frame(),lags_endog_lin =NaN ,lags_criterion='AIC',max_lags =4,trend= 0,shock_type = 1,confint= 1.96,hor = 12)
# 
# plot(results_lin)
# 
# 
# #################################################################
# # monthly data SNB ---------------
# Xfed<-openxlsx::read.xlsx(xlsxFile = '../data/monetary-policy-surprises-data.xlsx',sheet=3)
# Xfed$year<-as.Date(paste(Xfed$Year,sprintf("%02d",Xfed$Month),"01",sep="-"),'%Y-%m-%d')
# Xfed<-Xfed[,names(Xfed)!='Year']
# load('../data/dataMP_m.rds')
# head(dataMP_m)
# head(Xfed)
# 
# MP_mrg_m<-dplyr::left_join(Xfed,dataMP_m,by='year')
# 
# MP_mrg_m %>% summarize(cor(MPS,MP_fed,use="na.or.complete"))
# ## try LP
# {X<-MP_mrg_m[,c("year","MP_snb","usdch")] %>% summarize(year=year[-1],
#                      MP_snb=MP_snb[-1],
#                      DLUSD=diff(log(usdch)),
#                      LUSD=log(usdch[-1])) %>% na.omit() 
# results_lin_m <- lpirfs::lp_lin(X[,c("MP_snb","DLUSD")],lags_endog_lin =NaN ,lags_criterion='AICc',max_lags =4,trend= 1,shock_type = 0,confint= 1.96,hor = 12)
# 
# plot(results_lin_m)
# }
# 
# # TRY WITH VAR
# X$DLUSD<-X$DLUSD*100
# MP_mrg_m %<>% mutate(dlusdch=log(usdch)-dplyr::lag(log(usdch)))
# variable<-"dlusdch"
# shock<-'MPS'
# fit.var<-vars::VAR(y=as.ts(MP_mrg_m[,c(shock,variable)] %>% na.omit(),freq=12),p=12,type='const',season=NULL)
# summary(fit.var)
# fit.var.irf<-irf(fit.var,runs = 500,orthogonal=T,impulse=shock,response=variable,ci=.68)
# 
# plot(fit.var.irf)
########################################################################
