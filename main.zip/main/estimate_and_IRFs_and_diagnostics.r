new_run=F # If T(rue) re-estimate everything; if F(alse) use existing estimation
n_draws=500 # increase for final estimation
lags=4 # lags
data_matrix1<-data_matrix[,subset_]


specification  = bsvarSIGNs::specify_bsvarSIGN$new(data=data_matrix1,
                                                   p        = lags,
                                                   sign_irf = sr1,
                                                   sign_structural=sr_c,
                                                   max_tries = 100
                                                   ,sign_narrative =narratives
)
before_prior<-specification$get_prior()


specification$prior$estimate_hyper(
  S = 150000,
  burn_in = 10000,
  mu = TRUE,
  delta = TRUE,
  lambda = TRUE,
  psi = TRUE)
graphics.off()
hyper_draws<-t(specification$prior$hyper)
colnames(hyper_draws)<-c("mu", "delta", "lambda", paste0("psi", 1:ncol(data_matrix1)))
plot.ts(hyper_draws[,1:5], col = "#F500BD", bty = "n", xlab = "iterations")
plot.ts(hyper_draws[,6:ncol(hyper_draws)], col = "#F500BD", bty = "n", xlab = "iterations")




after_prior<-specification$get_prior()

print('Difference in priors after estimation')

t(before_prior$hyper-apply(after_prior$hyper,MARGIN=1,FUN=mean))

saveRDS(specification,file="specification_NEER.rds")

variable_names<-varbls[subset_]
shock_names<-variable_names
true_data=specification$get_data_matrices()$Y

n_p = lags
Y = true_data
# Z = rbind(Y, matrix(NA, nrow = n_var, ncol = 4))
estimate_file='bvars_estimate.rds'
# If the file is very large, loading it during a full script run (especially via source()) can cause R to crash due to memory or timeout issues.
# Try loading it interactively, or increase memory limits if possible.
# You can also try loading only when needed, or splitting the file if feasible.
# Example: load only if needed, and print file size
if (file.exists(estimate_file)) {
  cat("File size (MB):", file.info(estimate_file)$size / 1024^2, "\n")
  flush.console() # Ensure output is shown before loading
  Sys.sleep(2)    # Pause for 2 seconds to allow R to "catch up"
  posterior_list <- readRDS(estimate_file)
}
# system('rm bvars_estimate.rds')
if(new_run==T){
  system(paste("rm -rf ",estimate_file,sep=''))
}
if(file.exists(estimate_file)){
  posterior_list<-readRDS(estimate_file)
  
  posterior<-structure(posterior_list,class="PosteriorBSVARSIGN")
  n_draws<-posterior$posterior$A %>% dim(.) %>% .[3]
}else{
  
  
  # estimate the model
  # burn_in        = bsvars::estimate(specification, 10)
  posterior      = estimate(specification, S = n_draws,n_draws = 30,draw_strategy = 3)
  posterior_list<-as.list(posterior)
  saveRDS(posterior_list,estimate_file)
}

# Get Matrices of BSVAR ---------------

B<-NA # conflict with some silly function name in VARS
matrices <- gen_mats(posterior = posterior, specification = specification)
# Unpack the matrices from the returned list
M <- matrices$M
M_inv <- matrices$M_inv
M_list <- matrices$M_list
B <- matrices$B
B_list <- matrices$B_list
intercept <- matrices$intercept
n_var <- matrices$n_var
n_p <- matrices$n_p
Y <- matrices$Y
XX <- matrices$X
Z <- matrices$Z
# >>>>> POSTERIOR PREDICTIVE DENSITIES -------------

fitted_values <- bsvars::compute_fitted_values(posterior)
fitted_l<-apply(fitted_values,MARGIN=c(1,2),FUN=function(x)quantile(x,p=.05)) %>% t()%>% as.data.frame()
names(fitted_l)<-varbls[subset_]
fitted_l$year<-1:dim(fitted_l)[1]
fitted_l<-pivot_longer(fitted_l,cols=!year,names_to = 'variable',values_to = 'lower')
fitted_c<-apply(fitted_values,MARGIN=c(1,2),FUN=function(x)quantile(x,p=.5))%>% t()%>% as.data.frame()
names(fitted_c)<-varbls[subset_]
fitted_c$year<-1:dim(fitted_c)[1]
fitted_c<-pivot_longer(fitted_c,cols=!year,names_to = 'variable',values_to = 'center')

fitted_u<-apply(fitted_values,MARGIN=c(1,2),FUN=function(x)quantile(x,p=.95))%>% t()%>% as.data.frame()
names(fitted_u)<-varbls[subset_]
fitted_u$year<-1:dim(fitted_u)[1]
fitted_u<-pivot_longer(fitted_u,cols=!year,names_to = 'variable',values_to = 'upper')

fitted_all<-full_join(fitted_l,fitted_c,by=c('variable','year'))
fitted_all<-full_join(fitted_all,fitted_u,by=c('variable','year'))
# Plot or analyze the fitted values against actual data
T.start<-as.Date(as.yearqtr(as.numeric(rownames(data_matrix1)[specification$p+1]))
                 ,frac=0)
dates_date<-seq.Date(T.start,length.out = length(unique(fitted_all$year)),by='quarter')
p<-ggplot(data=fitted_all,aes(x=year))+
  geom_line(aes(y=center),color='red')+
  geom_ribbon(aes(ymin=lower,ymax=upper),fill='blue',alpha=0.2)+theme_minimal()+
  facet_grid(rows=vars(variable),scales='free_y')+ylab('')+xlab('')+labs(title='')+
  scale_x_continuous(
    breaks = unique(fitted_all$year)[seq(1,length(unique(fitted_all$year)),by=4)],
    labels = format(dates_date[seq(1,length(unique(fitted_all$year)),by=4)], "%b %Y") # e.g., "Jan 2024"
  )+theme(axis.text.x=element_text(angle=90))
print(p)
ggsave(filename='PPD.pdf',plot=p,device='pdf',path='figures',units='cm',width=18,height=16)
# IRFs -------------
irf            = bsvars::compute_impulse_responses(posterior, horizon = 20)
act_var<-dim(data_matrix1)[2]

nfig<-act_var #  floor(act_var^2/(m*n))
m<-2
n<-4
tfig<-act_var # shocks per figure
p<-plot_bvars(irf, significance_level = 0.32,
              central_tendency = 'median', variable_names = varbls[subset_], shock_names = varbls[subset_])#c("STR3m"    ,"pi_"    ,  "LRGDP"))

# Modify plots to remove titles/subtitles and set proper y-axis labels
# The plots are arranged as a matrix with variables as responses (rows) and shocks (columns)
n_vars <- length(varbls[subset_])
for(i in 1:length(p)) {
  # Calculate which variable this plot represents (response variable)
  var_idx <- ((i - 1) %% n_vars) + 1
  var_name <- varbls[subset_][var_idx]
  
  # Remove titles/subtitles and set y-axis label to variable name
  p[[i]] <- p[[i]] + 
    labs(title = "", subtitle = "", y = var_name) +
    theme(plot.title = element_blank(), plot.subtitle = element_blank()) +
    theme_uniform_text_size(size = 18)
}

for(cnt in 1:nfig){
  # dev.new()
  # grid::grid.newpage()
  pgr<-arrangeGrob(grobs=p[(1+tfig*(cnt-1)):(tfig*cnt)],nrow = m,ncol = n)
  # grid.arrange(pgr) 
  ggsave(paste0('irf_bvars_',cnt,'.pdf'),plot=pgr,device='pdf',path='figures',width=25,height=16,units = 'cm')
  
}
# if((nfig*n*m)<act_var^2){
#    # grid::grid.newpage()
#   cnt=nfig+1
# pgr<-arrangeGrob(grobs=p[(1+nfig*tfig):length(p)])
# # grid.arrange(pgr)
# ggsave(paste0('irf_bvars_',cnt,'.pdf'),plot=pgr,device='pdf',path='figures',width=18,height=16,units = 'cm')
# }



## ----include-images, echo=FALSE, results="asis"--------------------------------------------------------------
# Assume variable_count is the number of variables
variable_count <- cnt

# Generate file names dynamically based on variable count
image_files <- paste0("figures/irf_bvars_", 1:variable_count, ".pdf")

# Generate the Markdown for including the images
image_markdown <- paste0("\\includegraphics[width=\\linewidth]{", image_files, "}", collapse = " ")
cat(image_markdown)#,file = 'figures/irfs.tex')
# Structural IRFs

# Compute Structural Shocks -----------------
stsh<-extract_shocks(posterior,specification)
class(stsh)<-"PosteriorShocks"

# stsh<-compute_structural_shocks(posterior)
graphics.off()
plot(stsh)
stsh_m<-apply(stsh,MARGIN = c(1,2),FUN=mean) %>% t() %>% as.data.frame()


names(stsh_m)<-varbls[subset_]



#>>> Check autocorrelation ------
# Compute IID test results
iid_results <- check_iid_shocks(stsh_m)

# Print results
print(iid_results)


#>>> Cross correlation -------

cormap<-round(cor(stsh_m),2)
lt<-upper.tri(cormap)
cormap[lt]<-NA
melted_cormat<-reshape2::melt(cormap,na.rm = T)
ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile() +scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                                    midpoint = 0, limit = c(-1,1), space = "Lab", 
                                    name="Pearson\nCorrelation")
graphics.off()