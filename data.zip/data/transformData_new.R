# packages
library(data.table)

# clean up
rm(list=ls())

# specify paths
path <- "X:/xgilo/VGP2025Q2/"
out.path <- "//snb.ch/daten/appsdata/vwgpa/GalleryPortalChartsDataFromProjects/House_price_model_graphs/"

dt <- as.data.table(readRDS(paste0(path,"data_cond_forc.RDS")))

dt_lrhp <- dt[variable=="LRHP"]
dt_lrmort <- dt[variable=="LRMORT"]

dtl_lrhp <- melt(dt_lrhp,id.vars=c("hor","variable","forc"),variable.name="valtype")
dtl_lrmort <- melt(dt_lrmort,id.vars=c("hor","variable","forc"),variable.name="valtype")



# scale
# scale.lrhp <- dtl_lrhp[valtype=="data" & forc=="d",tail(value,1)]
# scale.lrmort <- dtl_lrmort[valtype=="data" & forc=="d",tail(value,1)]
# lrhp[,value := value / scale.lrhp * 100]
# lrmort[,value := value / scale.lrmort * 100]

# export to csv
fwrite(dtl_lrhp,paste0(out.path,"LRHP.csv"),sep=";")
fwrite(dtl_lrmort,paste0(out.path,"LRMORT.csv"),sep=";")



